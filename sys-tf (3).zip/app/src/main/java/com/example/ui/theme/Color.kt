package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val BrandBlue = Color(0xFF2563EB)
val BrandBlueLight = Color(0xFF3B82F6)
val BrandBlueContainer = Color(0xFFDBEAFE)

val EmeraldSuccess = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFD1FAE5)

val RoseDanger = Color(0xFFEF4444)
val RoseContainer = Color(0xFFFEE2E2)

val AmberAccent = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFEF3C7)

val PurplePrimary = Color(0xFF8B5CF6)
val PurpleContainer = Color(0xFFEDE9FE)
