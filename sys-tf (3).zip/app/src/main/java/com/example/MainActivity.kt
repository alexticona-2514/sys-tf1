package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.omnigestion.ui.screens.customers.CustomersScreen
import com.example.omnigestion.ui.screens.finances.FinancesScreen
import com.example.omnigestion.ui.screens.inventory.InventoryScreen
import com.example.omnigestion.ui.screens.pos.PosScreen
import com.example.omnigestion.ui.screens.purchases.PurchasesScreen
import com.example.omnigestion.ui.screens.settings.SettingsScreen
import com.example.omnigestion.ui.viewmodel.MainViewModel
import com.example.ui.theme.AppTheme

enum class Screen(val title: String, val icon: ImageVector, val selectedIcon: ImageVector) {
    POS("Ventas POS", Icons.Outlined.PointOfSale, Icons.Default.PointOfSale),
    INVENTORY("Inventario", Icons.Outlined.Inventory2, Icons.Default.Inventory2),
    FINANCES("Finanzas", Icons.Outlined.AccountBalanceWallet, Icons.Default.AccountBalanceWallet),
    PURCHASES("Compras", Icons.Outlined.LocalShipping, Icons.Default.LocalShipping),
    CUSTOMERS("Clientes", Icons.Outlined.People, Icons.Default.People),
    SETTINGS("Ajustes", Icons.Outlined.Settings, Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                val viewModel: MainViewModel = viewModel()
                var currentScreen by remember { mutableStateOf(Screen.FINANCES) }

                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.testTag("main_bottom_nav"),
                            tonalElevation = 4.dp
                        ) {
                            Screen.values().forEach { screen ->
                                val isSelected = currentScreen == screen
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentScreen = screen },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) screen.selectedIcon else screen.icon,
                                            contentDescription = screen.title
                                        )
                                    },
                                    label = { Text(screen.title) },
                                    modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            Screen.POS -> PosScreen(viewModel = viewModel)
                            Screen.INVENTORY -> InventoryScreen(viewModel = viewModel)
                            Screen.FINANCES -> FinancesScreen(viewModel = viewModel)
                            Screen.PURCHASES -> PurchasesScreen(viewModel = viewModel)
                            Screen.CUSTOMERS -> CustomersScreen(viewModel = viewModel)
                            Screen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
