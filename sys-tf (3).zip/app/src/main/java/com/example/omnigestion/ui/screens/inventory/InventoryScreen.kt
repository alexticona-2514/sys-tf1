package com.example.omnigestion.ui.screens.inventory

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.omnigestion.data.model.Product
import com.example.omnigestion.ui.components.ProductPurchaseRegistrationDialog
import com.example.omnigestion.ui.viewmodel.MainViewModel
import com.example.ui.theme.*
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InventoryScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Todas") }
    var filterLowStockOnly by remember { mutableStateOf(false) }

    var productToEdit by remember { mutableStateOf<Product?>(null) }
    var showAddProductDialog by remember { mutableStateOf(false) }
    var showPurchaseDialog by remember { mutableStateOf(false) }

    val categories = remember(products) {
        listOf("Todas") + products.map { it.category }.distinct()
    }

    val lowStockCount = remember(products) {
        products.count { it.stockQuantity <= it.minStock }
    }

    val filteredProducts = remember(products, searchQuery, selectedCategory, filterLowStockOnly) {
        products.filter { p ->
            val matchSearch = searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.sku.contains(searchQuery, ignoreCase = true)
            val matchCategory = selectedCategory == "Todas" || p.category == selectedCategory
            val matchStock = !filterLowStockOnly || p.stockQuantity <= p.minStock
            matchSearch && matchCategory && matchStock
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Inventario de Productos", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = { showPurchaseDialog = true },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("inventory_register_purchase_btn"),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    ) {
                        Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Comprar Stock", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddProductDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Nuevo Producto") },
                modifier = Modifier.testTag("add_new_product_fab")
            )
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Search and filters
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Buscar por producto o código SKU...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("inventory_search_field"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                // Category chips + Low stock toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    ScrollableTabRow(
                        selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
                        edgePadding = 0.dp,
                        modifier = Modifier.weight(1f)
                    ) {
                        categories.forEach { cat ->
                            Tab(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                text = { Text(cat, fontSize = 12.sp) }
                            )
                        }
                    }

                    Spacer(Modifier.width(8.dp))

                    FilterChip(
                        selected = filterLowStockOnly,
                        onClick = { filterLowStockOnly = !filterLowStockOnly },
                        label = { Text("Bajo stock ($lowStockCount)", fontSize = 11.sp) },
                        leadingIcon = {
                            if (lowStockCount > 0) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = RoseDanger,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    )
                }
            }

            // Products list
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredProducts, key = { it.id }) { product ->
                    ProductCatalogCard(
                        product = product,
                        currency = settings.currencySymbol,
                        onEdit = { productToEdit = product },
                        onStockDelta = { delta -> viewModel.adjustStock(product, delta) },
                        onDelete = { viewModel.deleteProduct(product) }
                    )
                }
            }
        }
    }

    // Modal de Registro de Compra de Productos
    if (showPurchaseDialog) {
        ProductPurchaseRegistrationDialog(
            allCatalogProducts = products,
            currencySymbol = settings.currencySymbol,
            onDismissRequest = { showPurchaseDialog = false },
            onConfirmPurchase = { supplier, voucher, method, notes, items, updatePrices ->
                viewModel.registerProductPurchase(
                    supplierName = supplier,
                    receiptVoucher = voucher,
                    paymentMethod = method,
                    notes = notes,
                    items = items,
                    updateCatalogPrices = updatePrices,
                    onSuccess = {
                        showPurchaseDialog = false
                    }
                )
            }
        )
    }

    // Modal Crear / Editar Producto
    if (showAddProductDialog || productToEdit != null) {
        ProductEditDialog(
            product = productToEdit,
            currency = settings.currencySymbol,
            onDismiss = {
                showAddProductDialog = false
                productToEdit = null
            },
            onSave = { savedProduct ->
                viewModel.saveProduct(savedProduct)
                showAddProductDialog = false
                productToEdit = null
            }
        )
    }
}

@Composable
fun ProductCatalogCard(
    product: Product,
    currency: String,
    onEdit: () -> Unit,
    onStockDelta: (Int) -> Unit,
    onDelete: () -> Unit
) {
    val isLowStock = product.stockQuantity <= product.minStock
    val profit = product.salePrice - product.costPrice
    val margin = if (product.costPrice > 0) (profit / product.costPrice * 100.0) else 0.0

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "SKU: ${product.sku} • ${product.category}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Editar", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Eliminar", tint = RoseDanger, modifier = Modifier.size(18.dp))
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Precios y Margen
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column {
                            Text("Costo:", style = MaterialTheme.typography.labelSmall)
                            Text(
                                "$currency ${String.format(Locale.US, "%.2f", product.costPrice)}",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                        Column {
                            Text("Venta:", style = MaterialTheme.typography.labelSmall)
                            Text(
                                "$currency ${String.format(Locale.US, "%.2f", product.salePrice)}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp
                            )
                        }
                        Column {
                            Text("Margen:", style = MaterialTheme.typography.labelSmall)
                            Text(
                                "${String.format(Locale.US, "%.1f", margin)}%",
                                fontWeight = FontWeight.Bold,
                                color = if (profit >= 0) EmeraldSuccess else RoseDanger,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                // Stock Controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalIconButton(
                        onClick = { onStockDelta(-1) },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Restar stock", modifier = Modifier.size(16.dp))
                    }

                    Surface(
                        color = if (isLowStock) RoseContainer else EmeraldContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        Text(
                            text = "${product.stockQuantity} un.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (isLowStock) RoseDanger else EmeraldSuccess,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    FilledTonalIconButton(
                        onClick = { onStockDelta(1) },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Sumar stock", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ProductEditDialog(
    product: Product?,
    currency: String,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var sku by remember { mutableStateOf(product?.sku ?: ("SKU-" + (1000..9999).random())) }
    var category by remember { mutableStateOf(product?.category ?: "Herramientas") }
    var costPriceText by remember { mutableStateOf(product?.costPrice?.toString() ?: "0.0") }
    var salePriceText by remember { mutableStateOf(product?.salePrice?.toString() ?: "0.0") }
    var stockText by remember { mutableStateOf(product?.stockQuantity?.toString() ?: "10") }
    var minStockText by remember { mutableStateOf(product?.minStock?.toString() ?: "5") }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier.fillMaxWidth(0.92f),
        title = {
            Text(if (product != null) "Editar Producto" else "Nuevo Producto")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre del Producto") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = sku,
                        onValueChange = { sku = it },
                        label = { Text("SKU / Código") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Categoría") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = costPriceText,
                        onValueChange = { costPriceText = it.replace(',', '.') },
                        label = { Text("P. Costo ($currency)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = salePriceText,
                        onValueChange = { salePriceText = it.replace(',', '.') },
                        label = { Text("P. Venta ($currency)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = stockText,
                        onValueChange = { stockText = it.filter { c -> c.isDigit() } },
                        label = { Text("Stock Actual") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = minStockText,
                        onValueChange = { minStockText = it.filter { c -> c.isDigit() } },
                        label = { Text("Stock Mínimo") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cost = costPriceText.toDoubleOrNull() ?: 0.0
                    val sale = salePriceText.toDoubleOrNull() ?: 0.0
                    val stock = stockText.toIntOrNull() ?: 0
                    val minStock = minStockText.toIntOrNull() ?: 5

                    val resultProduct = Product(
                        id = product?.id ?: ("PROD-" + UUID.randomUUID().toString().take(6)),
                        name = name,
                        sku = sku,
                        category = category,
                        costPrice = cost,
                        salePrice = sale,
                        stockQuantity = stock,
                        minStock = minStock,
                        imageUrl = null
                    )
                    onSave(resultProduct)
                },
                enabled = name.isNotBlank()
            ) {
                Text("Guardar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
