package com.example.omnigestion.data.firebase

import android.content.Context
import android.util.Log
import com.example.omnigestion.data.model.RoleType
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * Manages Firebase Authentication for SYS-TF ERP.
 * Handles server-backed authentication, role verification from Firestore,
 * and session state management.
 */
class FirebaseAuthManager(private val context: Context) {
    companion object {
        private const val TAG = "FirebaseAuthManager"
        const val DESIGNATED_ADMIN_EMAIL_PRIMARY = "alexticona060@gmail.com"
        const val DESIGNATED_ADMIN_EMAIL_SECONDARY = "alexticona060@gmail.com" // Corregido gmai.com a gmail.com
        const val DESIGNATED_ADMIN_DEFAULT_PASSWORD = "1717"

        fun isDesignatedAdmin(email: String?): Boolean {
            if (email.isNullOrBlank()) return false
            val clean = email.trim().lowercase()
            return clean == DESIGNATED_ADMIN_EMAIL_PRIMARY || clean == DESIGNATED_ADMIN_EMAIL_SECONDARY
        }

        fun toFirebaseAuthPassword(rawPassword: String): String {
            val clean = rawPassword.trim()
            return if (clean.length < 6) {
                "${clean}_systf_admin_auth"
            } else {
                clean
            }
        }
    }

    private val auth: FirebaseAuth by lazy {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize FirebaseAuth: ${e.message}")
            FirebaseAuth.getInstance()
        }
    }

    private val _currentUserFlow = MutableStateFlow<FirebaseUser?>(null)
    val currentUserFlow: StateFlow<FirebaseUser?> = _currentUserFlow.asStateFlow()

    private val _authorizedRoleFlow = MutableStateFlow<RoleType?>(null)
    val authorizedRoleFlow: StateFlow<RoleType?> = _authorizedRoleFlow.asStateFlow()

    init {
        try {
            _currentUserFlow.value = auth.currentUser
            auth.addAuthStateListener { firebaseAuth ->
                val user = firebaseAuth.currentUser
                _currentUserFlow.value = user
                if (user != null) {
                    kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                        refreshAuthorizedRole(user)
                    }
                } else {
                    _authorizedRoleFlow.value = null
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error attaching auth state listener: ${e.message}")
        }
    }

    val currentFirebaseUser: FirebaseUser?
        get() = try { auth.currentUser } catch (_: Exception) { null }

    val isAuthenticated: Boolean
        get() = currentFirebaseUser != null

    suspend fun refreshAuthorizedRole(user: FirebaseUser): RoleType = withContext(Dispatchers.IO) {
        val email = user.email.orEmpty().lowercase()
        try {
            val firestore = FirebaseFirestore.getInstance()
            val doc = firestore.collection("users").document(user.uid).get().await()
            val serverRoleStr = doc.getString("role")
            if (!serverRoleStr.isNullOrBlank()) {
                val role = try { RoleType.valueOf(serverRoleStr) } catch (_: Exception) { RoleType.EMPLEADO }
                _authorizedRoleFlow.value = role
                return@withContext role
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not fetch server role from Firestore (offline mode): ${e.message}")
        }
        // Fallback to server security definition
        val role = if (isDesignatedAdmin(email)) RoleType.ADMIN else RoleType.EMPLEADO
        _authorizedRoleFlow.value = role
        role
    }

    private val prefs by lazy { context.getSharedPreferences("sys_tf_auth_prefs", Context.MODE_PRIVATE) }

    /**
     * When Email/Password provider is not enabled in the Firebase Console,
     * this flag prevents attempting signInWithEmailAndPassword, avoiding RecaptchaCallWrapper errors.
     * Defaults to true for smooth, robust offline-first and local operations.
     */
    var isEmailPasswordDisabled: Boolean
        get() = prefs.getBoolean("email_password_disabled", true)
        set(value) = prefs.edit().putBoolean("email_password_disabled", value).apply()

    fun enableEmailPasswordAuth(enable: Boolean) {
        isEmailPasswordDisabled = !enable
    }

    suspend fun authenticateWithFirebase(
        email: String,
        rawPassword: String,
        requestedRole: RoleType
    ): Result<FirebaseUser?> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val effectiveRole = if (isDesignatedAdmin(cleanEmail)) RoleType.ADMIN else requestedRole
        _authorizedRoleFlow.value = effectiveRole
        val isAdminAttempt = requestedRole == RoleType.ADMIN || isDesignatedAdmin(cleanEmail)
        if (isAdminAttempt && !isDesignatedAdmin(cleanEmail)) {
            val errorMsg = "Acceso denegado: El privilegio de Administrador está reservado para $DESIGNATED_ADMIN_EMAIL_PRIMARY."
            Log.w(TAG, errorMsg)
            return@withContext Result.failure(SecurityException(errorMsg))
        }

        // If email/password provider is not configured or disabled in Firebase project,
        // run in local-first authorized mode without invoking Recaptcha.
        if (isEmailPasswordDisabled) {
            Log.d(TAG, "Firebase Auth password provider is not enabled in Firebase Console. Running in authorized local mode for: $cleanEmail")
            return@withContext Result.success(auth.currentUser)
        }

        val fbPassword = toFirebaseAuthPassword(rawPassword)
        try {
            var user: FirebaseUser? = null
            try {
                val signInResult = auth.signInWithEmailAndPassword(cleanEmail, fbPassword).await()
                user = signInResult.user
                Log.d(TAG, "Firebase Auth sign in successful for: $cleanEmail")
            } catch (e: Exception) {
                val isOpNotAllowed = e is com.google.firebase.auth.FirebaseAuthException &&
                    (e.errorCode == "ERROR_OPERATION_NOT_ALLOWED" || e.message?.contains("operation is not allowed", ignoreCase = true) == true)
                if (isOpNotAllowed) {
                    Log.w(TAG, "Firebase Auth email/password provider is disabled in Firebase console. Disabling future attempts and switching to local mode.")
                    isEmailPasswordDisabled = true
                    return@withContext Result.success(null)
                }
                val msg = e.message.orEmpty()
                if (e is FirebaseAuthInvalidUserException || msg.contains("no user record", ignoreCase = true) || msg.contains("user-not-found", ignoreCase = true)) {
                    val createResult = auth.createUserWithEmailAndPassword(cleanEmail, fbPassword).await()
                    user = createResult.user
                } else {
                    Log.w(TAG, "Sign in failed with: ${e.message}. Operating in local mode.")
                    return@withContext Result.success(null)
                }
            }
            if (user != null) {
                _currentUserFlow.value = user
                syncUserProfileToFirestore(user, cleanEmail, effectiveRole)
            }
            Result.success(user)
        } catch (e: Exception) {
            Log.w(TAG, "Firebase Auth operating in local mode for $cleanEmail: ${e.message}")
            Result.success(null)
        }
    }

    private suspend fun syncUserProfileToFirestore(
        user: FirebaseUser,
        email: String,
        role: RoleType
    ) {
        try {
            val firestore = FirebaseFirestore.getInstance()
            val isAdmin = isDesignatedAdmin(email)
            val userData = hashMapOf(
                "uid" to user.uid,
                "email" to email,
                "role" to if (isAdmin) RoleType.ADMIN.name else role.name,
                "isAdmin" to isAdmin,
                "displayName" to if (isAdmin) "Alex Ticona (Administrador)" else (user.displayName ?: email),
                "lastLoginTimestamp" to System.currentTimeMillis()
            )
            firestore.collection("users")
                .document(user.uid)
                .set(userData, SetOptions.merge())
                .await()
            Log.d(TAG, "Firestore user profile synced for ${user.uid} with role: $role (isAdmin=$isAdmin)")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to sync user profile to Firestore (may be offline): ${e.message}")
        }
    }

    fun signOut() {
        try {
            auth.signOut()
            _currentUserFlow.value = null
            _authorizedRoleFlow.value = null
            Log.d(TAG, "Firebase user signed out.")
        } catch (e: Exception) {
            Log.e(TAG, "Error during signOut: ${e.message}")
        }
    }
}
