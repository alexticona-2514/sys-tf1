package com.example.omnigestion.ui.screens.finances

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.omnigestion.data.model.Expense
import com.example.omnigestion.data.model.ExpenseCategory
import com.example.omnigestion.data.model.Product
import com.example.omnigestion.data.model.PurchaseOrderItemInput
import com.example.omnigestion.data.pdf.PdfReportGenerator
import com.example.omnigestion.ui.components.OmniDatePickerDialog
import com.example.omnigestion.ui.components.ProductImageView
import com.example.omnigestion.ui.components.omniTextFieldColors
import com.example.omnigestion.ui.viewmodel.OmniViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinancesScreen(viewModel: OmniViewModel) {
    val context = LocalContext.current
    val expenses by viewModel.expenses.collectAsState()
    val sales by viewModel.sales.collectAsState()
    val products by viewModel.products.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var expenseToEdit by remember { mutableStateOf<Expense?>(null) }
    var expenseToDelete by remember { mutableStateOf<Expense?>(null) }
    var selectedCategoryFilter by remember { mutableStateOf("Todos") }
    var selectedTimePeriod by remember { mutableStateOf("Mes") } // "Día", "Mes", "Año", "Todo"

    BackHandler(enabled = showAddExpenseDialog || expenseToEdit != null || expenseToDelete != null) {
        if (showAddExpenseDialog) showAddExpenseDialog = false
        else if (expenseToEdit != null) expenseToEdit = null
        else if (expenseToDelete != null) expenseToDelete = null
    }

    val categoryFilterList = listOf(
        "Todos",
        ExpenseCategory.COMPRAS_PRODUCTOS.title,
        ExpenseCategory.GASTOS_PERSONALES.title,
        ExpenseCategory.GASTOS_LOGISTICOS.title,
        ExpenseCategory.OTROS_GASTOS.title
    )

    val timePeriods = listOf("Día", "Mes", "Año", "Todo")

    val periodFilteredSales = remember(sales, selectedTimePeriod) {
        val nonVoided = sales.filter { it.paymentStatus != "ANULADO" }
        val now = Calendar.getInstance()
        when (selectedTimePeriod) {
            "Día" -> {
                val calItem = Calendar.getInstance()
                nonVoided.filter {
                    calItem.timeInMillis = it.timestamp
                    calItem.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
                            calItem.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
                }
            }
            "Mes" -> {
                val calItem = Calendar.getInstance()
                nonVoided.filter {
                    calItem.timeInMillis = it.timestamp
                    calItem.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
                            calItem.get(Calendar.MONTH) == now.get(Calendar.MONTH)
                }
            }
            "Año" -> {
                val calItem = Calendar.getInstance()
                nonVoided.filter {
                    calItem.timeInMillis = it.timestamp
                    calItem.get(Calendar.YEAR) == now.get(Calendar.YEAR)
                }
            }
            else -> nonVoided
        }
    }

    val periodFilteredExpenses = remember(expenses, selectedTimePeriod) {
        val now = Calendar.getInstance()
        when (selectedTimePeriod) {
            "Día" -> {
                val calItem = Calendar.getInstance()
                expenses.filter {
                    calItem.timeInMillis = it.timestamp
                    calItem.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
                            calItem.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
                }
            }
            "Mes" -> {
                val calItem = Calendar.getInstance()
                expenses.filter {
                    calItem.timeInMillis = it.timestamp
                    calItem.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
                            calItem.get(Calendar.MONTH) == now.get(Calendar.MONTH)
                }
            }
            "Año" -> {
                val calItem = Calendar.getInstance()
                expenses.filter {
                    calItem.timeInMillis = it.timestamp
                    calItem.get(Calendar.YEAR) == now.get(Calendar.YEAR)
                }
            }
            else -> expenses
        }
    }

    val filteredExpenses = remember(periodFilteredExpenses, selectedCategoryFilter) {
        if (selectedCategoryFilter == "Todos") periodFilteredExpenses else periodFilteredExpenses.filter {
            it.category.equals(selectedCategoryFilter, ignoreCase = true) ||
                    (selectedCategoryFilter == ExpenseCategory.COMPRAS_PRODUCTOS.title && it.isProductPurchase)
        }
    }

    val totalVentas = remember(periodFilteredSales) {
        periodFilteredSales.sumOf { it.totalAmount }
    }
    val totalGastos = remember(periodFilteredExpenses) {
        periodFilteredExpenses.sumOf { it.amount }
    }
    val balanceNeto = totalVentas - totalGastos
    val margenNeto = if (totalVentas > 0) (balanceNeto / totalVentas) * 100.0 else 0.0

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddExpenseDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("finances_add_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Registrar Gasto o Compra")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(14.dp)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    timePeriods.forEach { period ->
                        val isSel = selectedTimePeriod == period
                        Surface(
                            onClick = { selectedTimePeriod = period },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent,
                            modifier = Modifier.weight(1f).height(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = when(period) {
                                        "Día" -> "Hoy (Día)"
                                        "Mes" -> "Este Mes"
                                        "Año" -> "Este Año"
                                        else -> "Histórico"
                                    },
                                    fontSize = 11.5.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))

            // Executive Balance Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Ganancia y Balance (${selectedTimePeriod})", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${currency.symbol} ${String.format(Locale.US, "%,.2f", balanceNeto)}",
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (balanceNeto >= 0) EmeraldSuccess else RoseDanger
                            )
                            Text(
                                text = if (balanceNeto >= 0) "Ganancia Neta • Margen: ${String.format(Locale.US, "%.1f", margenNeto)}%" else "Pérdida / Déficit (${String.format(Locale.US, "%.1f", margenNeto)}%)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (balanceNeto >= 0) EmeraldSuccess else RoseDanger
                            )
                        }
                        IconButton(onClick = {
                            val pdf = PdfReportGenerator.generateFinancialReportPdf(
                                context = context,
                                settings = settings,
                                sales = periodFilteredSales,
                                expenses = periodFilteredExpenses,
                                currency = currency
                            )
                            PdfReportGenerator.openOrSharePdf(context, pdf, "Reporte Financiero ($selectedTimePeriod)")
                        }) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = "Descargar Reporte PDF", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(EmeraldSuccess))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Ventas Cobradas:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                text = "${currency.symbol} ${String.format(Locale.US, "%,.2f", totalVentas)}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldSuccess
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(RoseDanger))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Gastos y Compras:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                text = "${currency.symbol} ${String.format(Locale.US, "%,.2f", totalGastos)}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoseDanger
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))

            Text("Historial de Compras de Mercadería y Gastos:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(categoryFilterList) { cat ->
                    val isSel = selectedCategoryFilter == cat
                    Surface(
                        onClick = { selectedCategoryFilter = cat },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (!isSel) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline) else null,
                        modifier = Modifier.height(32.dp)
                    ) {
                        Box(modifier = Modifier.padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
                            Text(
                                text = cat,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))

            if (filteredExpenses.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay gastos registrados en esta categoría.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredExpenses, key = { it.id }) { exp ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = when (exp.category) {
                                                ExpenseCategory.COMPRAS_PRODUCTOS.title -> NavyContainer
                                                ExpenseCategory.GASTOS_LOGISTICOS.title -> AmberContainer
                                                ExpenseCategory.GASTOS_PERSONALES.title -> Color(0xFFF3E8FF)
                                                else -> MaterialTheme.colorScheme.surfaceVariant
                                            }
                                        ) {
                                            Text(
                                                text = exp.category.uppercase(),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when (exp.category) {
                                                    ExpenseCategory.COMPRAS_PRODUCTOS.title -> MaterialTheme.colorScheme.primary
                                                    ExpenseCategory.GASTOS_LOGISTICOS.title -> AmberAccent
                                                    ExpenseCategory.GASTOS_PERSONALES.title -> Color(0xFF6B21A8)
                                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                },
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                            border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.CalendarMonth,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(11.dp)
                                                )
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text(
                                                    text = exp.date,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(exp.description, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                    if (exp.purchaseItemsDetails.isNotBlank()) {
                                        Text("Artículos: ${exp.purchaseItemsDetails}", fontSize = 11.sp, color = EmeraldSuccess, fontWeight = FontWeight.Medium)
                                    }
                                    Text("Por: ${exp.employeeName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "-${currency.symbol} ${String.format(Locale.US, "%.2f", exp.amount)}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = RoseDanger
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row {
                                        IconButton(
                                            onClick = { expenseToEdit = exp },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Editar", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(
                                            onClick = { expenseToDelete = exp },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = RoseDanger, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddExpenseDialog) {
        var selectedCat by remember { mutableStateOf(ExpenseCategory.COMPRAS_PRODUCTOS) }
        var description by remember { mutableStateOf("") }
        var supplierName by remember { mutableStateOf("") }
        var paymentMethod by remember { mutableStateOf("Efectivo") }
        var voucherNumber by remember { mutableStateOf("") }
        var amountText by remember { mutableStateOf("") }
        var customExpenseTimestamp by remember { mutableStateOf<Long?>(null) }
        var showExpenseDatePicker by remember { mutableStateOf(false) }

        var selectedProductIds by remember { mutableStateOf<Set<String>>(emptySet()) }
        var itemQtyTextMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
        var itemCostTextMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
        var itemSaleTextMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
        var showProductSelector by remember { mutableStateOf(false) }
        var purchaseSearchQuery by remember { mutableStateOf("") }
        var showBulkToolsInExpense by remember { mutableStateOf(false) }

        val paymentMethods = listOf("Efectivo", "QR / Transferencia", "Tarjeta de Débito/Crédito", "Crédito a Proveedor")

        fun addOrUpdateProductInExpense(prod: Product, defaultQty: Int = 5) {
            selectedProductIds = selectedProductIds + prod.id
            val curQ = itemQtyTextMap[prod.id]?.toIntOrNull() ?: 0
            val targetQ = if (curQ > 0) curQ + defaultQty else defaultQty
            itemQtyTextMap = itemQtyTextMap + (prod.id to targetQ.toString())
            if (!itemCostTextMap.containsKey(prod.id)) {
                itemCostTextMap = itemCostTextMap + (prod.id to if (prod.costPrice > 0) String.format(Locale.US, "%.2f", prod.costPrice) else "0.00")
            }
            if (!itemSaleTextMap.containsKey(prod.id)) {
                itemSaleTextMap = itemSaleTextMap + (prod.id to if (prod.salePrice > 0) String.format(Locale.US, "%.2f", prod.salePrice) else "0.00")
            }
        }

        fun removeProductFromExpense(prodId: String) {
            selectedProductIds = selectedProductIds - prodId
            itemQtyTextMap = itemQtyTextMap - prodId
            itemCostTextMap = itemCostTextMap - prodId
            itemSaleTextMap = itemSaleTextMap - prodId
        }

        fun adjustQtyInExpense(prodId: String, delta: Int) {
            val curQ = itemQtyTextMap[prodId]?.toIntOrNull() ?: 1
            val newQ = max(1, curQ + delta)
            itemQtyTextMap = itemQtyTextMap + (prodId to newQ.toString())
        }

        fun applyMarginToAllInExpense(marginPercent: Double) {
            val sMap = itemSaleTextMap.toMutableMap()
            for (id in selectedProductIds) {
                val prod = products.firstOrNull { it.id == id }
                val c = itemCostTextMap[id]?.replace(',', '.')?.toDoubleOrNull() ?: (prod?.costPrice ?: 0.0)
                if (c > 0) {
                    val newSale = c * (1.0 + marginPercent / 100.0)
                    sMap[id] = String.format(Locale.US, "%.2f", newSale)
                }
            }
            itemSaleTextMap = sMap
        }

        fun addQuantityToAllInExpense(delta: Int) {
            val qMap = itemQtyTextMap.toMutableMap()
            for (id in selectedProductIds) {
                val cur = qMap[id]?.toIntOrNull() ?: 1
                qMap[id] = max(1, cur + delta).toString()
            }
            itemQtyTextMap = qMap
        }

        fun applyQuantityToAllInExpense(fixedQty: Int) {
            val qMap = itemQtyTextMap.toMutableMap()
            for (id in selectedProductIds) {
                qMap[id] = fixedQty.toString()
            }
            itemQtyTextMap = qMap
        }

        val multiProductItems = remember(selectedProductIds, itemQtyTextMap, itemCostTextMap, itemSaleTextMap, products) {
            selectedProductIds.mapNotNull { prodId ->
                products.firstOrNull { it.id == prodId }?.let { prod ->
                    val qty = itemQtyTextMap[prodId]?.toIntOrNull() ?: 1
                    val unitCost = itemCostTextMap[prodId]?.replace(',', '.')?.toDoubleOrNull() ?: prod.costPrice
                    val unitSale = itemSaleTextMap[prodId]?.replace(',', '.')?.toDoubleOrNull() ?: prod.salePrice
                    PurchaseOrderItemInput(prod, qty, unitCost, unitSale)
                }
            }
        }

        val totalCalculatedPurchaseCost = remember(multiProductItems) {
            multiProductItems.sumOf { it.purchasePrice * it.quantity }
        }

        LaunchedEffect(totalCalculatedPurchaseCost, selectedCat) {
            if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS && multiProductItems.isNotEmpty()) {
                amountText = String.format(Locale.US, "%.2f", totalCalculatedPurchaseCost)
            }
        }

        Dialog(
            onDismissRequest = { showAddExpenseDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .fillMaxHeight(0.92f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    // Cabecera superior fija
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS) Icons.Default.ShoppingCart else Icons.Default.ReceiptLong,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS) "Registrar Compra de Mercadería" else "Registrar Gasto u Operación",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { showAddExpenseDialog = false },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val expenseScrollState = rememberScrollState()
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(expenseScrollState),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Tipo / Categoría de Egreso:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(ExpenseCategory.COMPRAS_PRODUCTOS, ExpenseCategory.GASTOS_LOGISTICOS).forEach { cat ->
                                val isSel = selectedCat == cat
                                Surface(
                                    onClick = { selectedCat = cat },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                                    modifier = Modifier.weight(1f).height(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp)) {
                                        Text(
                                            text = cat.title,
                                            color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(ExpenseCategory.GASTOS_PERSONALES, ExpenseCategory.OTROS_GASTOS).forEach { cat ->
                                val isSel = selectedCat == cat
                                Surface(
                                    onClick = { selectedCat = cat },
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                                    modifier = Modifier.weight(1f).height(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp)) {
                                        Text(
                                            text = cat.title,
                                            color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Card destacada de Fecha de Registro / Compra
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.CalendarMonth,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS) "FECHA DE LA COMPRA:" else "FECHA DEL REGISTRO:",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            if (customExpenseTimestamp != null) "Fecha retroactiva / personalizada" else "Fecha actual en vivo (Hoy)",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (customExpenseTimestamp != null) AmberContainer else EmeraldContainer
                                ) {
                                    Text(
                                        text = if (customExpenseTimestamp != null) "Personalizada" else "Hoy",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (customExpenseTimestamp != null) AmberAccent else EmeraldSuccess,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        val displayTime = customExpenseTimestamp ?: System.currentTimeMillis()
                                        Text(
                                            text = SimpleDateFormat("EEEE, dd 'de' MMMM 'de' yyyy", Locale("es", "ES")).format(Date(displayTime)).replaceFirstChar { it.uppercase() },
                                            fontSize = 12.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Hora: " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(displayTime)),
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        if (customExpenseTimestamp != null) {
                                            OutlinedButton(
                                                onClick = { customExpenseTimestamp = null },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.height(34.dp)
                                            ) {
                                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.error)
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Hoy", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                        Button(
                                            onClick = { showExpenseDatePicker = true },
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            modifier = Modifier.height(34.dp)
                                        ) {
                                            Icon(Icons.Default.EditCalendar, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Cambiar", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Productos elegidos (${multiProductItems.size})",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Button(
                                        onClick = { showProductSelector = true },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                    ) {
                                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Buscar / Elegir Varios", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                if (multiProductItems.isEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                            .padding(vertical = 12.dp, horizontal = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.AddShoppingCart, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                "Presiona 'Buscar / Elegir Varios' para agregar artículos a la compra",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                } else {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                                            shape = RoundedCornerShape(10.dp),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Modificar Datos de los ${multiProductItems.size} Productos", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                                    }
                                                    TextButton(
                                                        onClick = { showBulkToolsInExpense = !showBulkToolsInExpense },
                                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text(if (showBulkToolsInExpense) "Ocultar" else "Ajustar en Lote", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                                if (showBulkToolsInExpense) {
                                                    HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                                                    Text("Margen de Venta para todos (sobre Costo):", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                        listOf(20.0, 30.0, 40.0, 50.0).forEach { pct ->
                                                            Surface(
                                                                onClick = { applyMarginToAllInExpense(pct) },
                                                                shape = RoundedCornerShape(6.dp),
                                                                color = EmeraldContainer,
                                                                border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f))
                                                            ) {
                                                                Text("+${pct.toInt()}% margen", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                                                            }
                                                        }
                                                    }
                                                    Text("Cantidad para todos:", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                        Surface(
                                                            onClick = { addQuantityToAllInExpense(5) },
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = MaterialTheme.colorScheme.surface,
                                                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                                        ) {
                                                            Text("+5 a todos", fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                                                        }
                                                        Surface(
                                                            onClick = { addQuantityToAllInExpense(10) },
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = MaterialTheme.colorScheme.surface,
                                                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                                        ) {
                                                            Text("+10 a todos", fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                                                        }
                                                        Surface(
                                                            onClick = { applyQuantityToAllInExpense(10) },
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = MaterialTheme.colorScheme.surface,
                                                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                                        ) {
                                                            Text("Fijar 10", fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        multiProductItems.forEachIndexed { index, item ->
                                            val p = item.product
                                            val pId = p.id
                                            val qty = item.quantity
                                            val pCost = item.purchasePrice
                                            val pSale = item.salePrice
                                            val rawQtyStr = itemQtyTextMap[pId] ?: qty.toString()
                                            val rawCostStr = itemCostTextMap[pId] ?: String.format(Locale.US, "%.2f", pCost)
                                            val rawSaleStr = itemSaleTextMap[pId] ?: String.format(Locale.US, "%.2f", pSale)

                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    // Fila 1: Cabecera del producto (Imagen, Nombre, Código, Stock y botón Quitar)
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        ProductImageView(
                                                            imageUrl = p.imageUrl,
                                                            contentDescription = p.name,
                                                            modifier = Modifier
                                                                .size(46.dp)
                                                                .clip(RoundedCornerShape(8.dp))
                                                        )
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                                Surface(
                                                                    shape = RoundedCornerShape(4.dp),
                                                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                                                ) {
                                                                    Text("#${index + 1}", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                                }
                                                                Spacer(modifier = Modifier.width(4.dp))
                                                                Text(p.name, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                            }
                                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                                                Surface(
                                                                    shape = RoundedCornerShape(4.dp),
                                                                    color = MaterialTheme.colorScheme.surfaceVariant
                                                                ) {
                                                                    Text("SKU: ${p.sku}", fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                                }
                                                                Text("• Stock: ${p.stockQuantity}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                            }
                                                        }
                                                        IconButton(
                                                            onClick = { removeProductFromExpense(pId) },
                                                            modifier = Modifier.size(32.dp)
                                                        ) {
                                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Quitar producto", tint = RoseDanger, modifier = Modifier.size(20.dp))
                                                        }
                                                    }

                                                    // Fila 2: Control de Cantidad con Stepper y Subtotal
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                                                        ) {
                                                            IconButton(
                                                                onClick = { adjustQtyInExpense(pId, -1) },
                                                                modifier = Modifier.size(30.dp)
                                                            ) {
                                                                Icon(Icons.Default.Remove, contentDescription = "Menos", modifier = Modifier.size(16.dp))
                                                            }
                                                            OutlinedTextField(
                                                                value = rawQtyStr,
                                                                onValueChange = { newQ ->
                                                                    if (newQ.isEmpty() || newQ.all { it.isDigit() }) {
                                                                        itemQtyTextMap = itemQtyTextMap + (pId to newQ)
                                                                    }
                                                                },
                                                                label = { Text("Cant.", fontSize = 9.sp) },
                                                                singleLine = true,
                                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                                modifier = Modifier.width(72.dp),
                                                                colors = omniTextFieldColors()
                                                            )
                                                            IconButton(
                                                                onClick = { adjustQtyInExpense(pId, 1) },
                                                                modifier = Modifier.size(30.dp)
                                                            ) {
                                                                Icon(Icons.Default.Add, contentDescription = "Más", modifier = Modifier.size(16.dp))
                                                            }
                                                            Surface(
                                                                onClick = { adjustQtyInExpense(pId, 5) },
                                                                shape = RoundedCornerShape(4.dp),
                                                                color = MaterialTheme.colorScheme.surfaceVariant
                                                            ) {
                                                                Text("+5", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 5.dp, vertical = 4.dp))
                                                            }
                                                        }

                                                        Column(horizontalAlignment = Alignment.End) {
                                                            Text("Subtotal Línea", fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                            Text(
                                                                text = "${currency.symbol} ${String.format(Locale.US, "%.2f", pCost * qty)}",
                                                                fontSize = 12.sp,
                                                                fontWeight = FontWeight.ExtraBold,
                                                                color = MaterialTheme.colorScheme.primary
                                                            )
                                                        }
                                                    }

                                                    // Fila 3: Precio de Compra (Costo) y Precio de Venta al Público
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        OutlinedTextField(
                                                            value = rawCostStr,
                                                            onValueChange = { newC ->
                                                                val sanitized = newC.replace(',', '.')
                                                                if (sanitized.isEmpty() || (sanitized.count { it == '.' } <= 1 && sanitized.all { it.isDigit() || it == '.' })) {
                                                                    itemCostTextMap = itemCostTextMap + (pId to newC)
                                                                }
                                                            },
                                                            label = { Text("P. Compra (Costo)", fontSize = 9.5.sp) },
                                                            singleLine = true,
                                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                                            modifier = Modifier.weight(1f),
                                                            colors = omniTextFieldColors()
                                                        )

                                                        OutlinedTextField(
                                                            value = rawSaleStr,
                                                            onValueChange = { newS ->
                                                                val sanitized = newS.replace(',', '.')
                                                                if (sanitized.isEmpty() || (sanitized.count { it == '.' } <= 1 && sanitized.all { it.isDigit() || it == '.' })) {
                                                                    itemSaleTextMap = itemSaleTextMap + (pId to newS)
                                                                }
                                                            },
                                                            label = { Text("P. Venta Público", fontSize = 9.5.sp) },
                                                            singleLine = true,
                                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                                            modifier = Modifier.weight(1f),
                                                            colors = omniTextFieldColors()
                                                        )
                                                    }

                                                    // Fila 4: Ajuste rápido de margen y ganancia estimada
                                                    val margin = if (pSale > 0 && pCost > 0) ((pSale - pCost) / pSale) * 100.0 else 0.0
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                                            Text("Ajustar Venta:", fontSize = 9.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                            Surface(
                                                                onClick = {
                                                                    val c = rawCostStr.replace(',', '.').toDoubleOrNull() ?: pCost
                                                                    if (c > 0) {
                                                                        itemSaleTextMap = itemSaleTextMap + (pId to String.format(Locale.US, "%.2f", c * 1.30))
                                                                    }
                                                                },
                                                                shape = RoundedCornerShape(4.dp),
                                                                color = EmeraldContainer
                                                            ) {
                                                                Text("+30%", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                                                            }
                                                            Surface(
                                                                onClick = {
                                                                    val c = rawCostStr.replace(',', '.').toDoubleOrNull() ?: pCost
                                                                    if (c > 0) {
                                                                        itemSaleTextMap = itemSaleTextMap + (pId to String.format(Locale.US, "%.2f", c * 1.50))
                                                                    }
                                                                },
                                                                shape = RoundedCornerShape(4.dp),
                                                                color = EmeraldContainer
                                                            ) {
                                                                Text("+50%", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                                                            }
                                                        }
                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = if (margin > 0) EmeraldContainer else MaterialTheme.colorScheme.surfaceVariant
                                                        ) {
                                                            Text(
                                                                text = "Margen: ${String.format(Locale.US, "%.1f", margin)}%",
                                                                fontSize = 10.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = if (margin > 0) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                "Total Unidades: ${multiProductItems.sumOf { it.quantity }}",
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                "Total Compra: ${currency.symbol} ${String.format(Locale.US, "%.2f", totalCalculatedPurchaseCost)}",
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = EmeraldSuccess
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = supplierName,
                        onValueChange = { supplierName = it },
                        label = { Text("Proveedor o Beneficiario") },
                        placeholder = { Text("ej. Importadora Mayorista Los Andes / Distribuidora") },
                        singleLine = true,
                        colors = omniTextFieldColors()
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Concepto o Descripción del Egreso") },
                        placeholder = { Text("ej. Lote de filtros y aceites para stock / Flete interdepartamental") },
                        singleLine = true,
                        colors = omniTextFieldColors()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = amountText,
                            onValueChange = { amountText = it },
                            label = { Text("Monto Total (${currency.symbol})") },
                            singleLine = true,
                            modifier = Modifier.weight(1.2f),
                            colors = omniTextFieldColors()
                        )
                        OutlinedTextField(
                            value = voucherNumber,
                            onValueChange = { voucherNumber = it },
                            label = { Text("Nº Comprobante") },
                            placeholder = { Text("Factura / Recibo") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            colors = omniTextFieldColors()
                        )
                    }

                    Text("Método de Pago:", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(paymentMethods) { m ->
                            FilterChip(
                                selected = paymentMethod == m,
                                onClick = { paymentMethod = m },
                                label = { Text(m, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                } // Cierre del Column scrolleable (weight 1f)

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(6.dp))

                    // Botones fijos inferiores
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showAddExpenseDialog = false }) {
                            Text("Cancelar")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val amount = amountText.toDoubleOrNull() ?: 0.0
                                val desc = description.ifBlank {
                                    if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS && multiProductItems.isNotEmpty()) {
                                        "Compra de ${multiProductItems.size} productos (${multiProductItems.joinToString(", ") { "${it.product.name} x${it.quantity}" }})"
                                    } else "Gasto Operativo"
                                }
                                if (amount > 0) {
                                    viewModel.recordEnhancedExpense(
                                        category = selectedCat,
                                        description = desc,
                                        amount = amount,
                                        supplierName = supplierName.trim(),
                                        receiptVoucher = voucherNumber.trim(),
                                        paymentMethod = paymentMethod,
                                        customTimestamp = customExpenseTimestamp,
                                        multiProductItems = if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS) multiProductItems else emptyList()
                                    )
                                    showAddExpenseDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS) Icons.Default.ShoppingCartCheckout else Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (selectedCat == ExpenseCategory.COMPRAS_PRODUCTOS) "Registrar Compra" else "Registrar Egreso",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        if (showExpenseDatePicker) {
            OmniDatePickerDialog(
                initialDateMillis = customExpenseTimestamp ?: System.currentTimeMillis(),
                onDateSelected = { selectedTime ->
                    customExpenseTimestamp = selectedTime
                },
                onDismiss = { showExpenseDatePicker = false }
            )
        }

        if (showProductSelector) {
            var pickerCategoryFilter by remember { mutableStateOf("Todos") }
            val availableCategories = remember(products) {
                listOf("Todos", "Stock Bajo / Agotado") + products.map { it.category }.filter { it.isNotBlank() }.distinct().sorted()
            }
            val filteredProductsList = remember(purchaseSearchQuery, pickerCategoryFilter, products) {
                products.filter { prod ->
                    val matchesQuery = if (purchaseSearchQuery.isBlank()) true else {
                        prod.name.contains(purchaseSearchQuery, ignoreCase = true) ||
                        prod.sku.contains(purchaseSearchQuery, ignoreCase = true) ||
                        prod.category.contains(purchaseSearchQuery, ignoreCase = true) ||
                        prod.description.contains(purchaseSearchQuery, ignoreCase = true)
                    }
                    val matchesCategory = when (pickerCategoryFilter) {
                        "Todos" -> true
                        "Stock Bajo / Agotado" -> prod.stockQuantity <= prod.minStock
                        else -> prod.category.equals(pickerCategoryFilter, ignoreCase = true)
                    }
                    matchesQuery && matchesCategory
                }
            }

            Dialog(
                onDismissRequest = { showProductSelector = false },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    modifier = Modifier
                        .fillMaxWidth(0.96f)
                        .fillMaxHeight(0.92f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Inventory2,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        "Catálogo: Selección de Productos",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        "Escoge múltiples artículos y define las unidades a comprar",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            IconButton(onClick = { showProductSelector = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Cerrar")
                            }
                        }

                        OutlinedTextField(
                            value = purchaseSearchQuery,
                            onValueChange = { purchaseSearchQuery = it },
                            placeholder = { Text("Buscar por nombre, código de barras o categoría...") },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            },
                            trailingIcon = {
                                if (purchaseSearchQuery.isNotBlank()) {
                                    IconButton(onClick = { purchaseSearchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Limpiar", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = omniTextFieldColors()
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(availableCategories) { cat ->
                                val isSelected = pickerCategoryFilter == cat
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { pickerCategoryFilter = cat },
                                    label = {
                                        Text(
                                            text = if (cat == "Stock Bajo / Agotado") "⚠️ $cat" else cat,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Mostrando ${filteredProductsList.size} artículos",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (selectedProductIds.isNotEmpty()) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "${selectedProductIds.size} seleccionados",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedProductIds.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        if (filteredProductsList.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Default.SearchOff,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "No se encontraron productos coincidentes.",
                                        fontSize = 12.5.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(filteredProductsList, key = { it.id }) { prod ->
                                    val isSelected = selectedProductIds.contains(prod.id)
                                    val curQty = itemQtyTextMap[prod.id]?.toIntOrNull() ?: 0

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                        border = androidx.compose.foundation.BorderStroke(
                                            width = if (isSelected) 1.5.dp else 1.dp,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            ProductImageView(
                                                imageUrl = prod.imageUrl,
                                                contentDescription = prod.name,
                                                modifier = Modifier
                                                    .size(62.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                            )
                                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(
                                                    text = prod.name,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.surfaceVariant
                                                    ) {
                                                        Text(
                                                            text = "SKU: ${prod.sku}",
                                                            fontSize = 9.5.sp,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                    ) {
                                                        Text(
                                                            text = prod.category,
                                                            fontSize = 9.5.sp,
                                                            color = MaterialTheme.colorScheme.primary,
                                                            fontWeight = FontWeight.SemiBold,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                        )
                                                    }
                                                }
                                                Text("Stock actual: ${prod.stockQuantity} unid.", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text(
                                                    text = "Costo: ${currency.symbol} ${String.format(Locale.US, "%.2f", prod.costPrice)} • Venta: ${currency.symbol} ${String.format(Locale.US, "%.2f", prod.salePrice)}",
                                                    fontSize = 10.5.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }

                                            if (!isSelected) {
                                                Button(
                                                    onClick = {
                                                        addOrUpdateProductInExpense(prod, 5)
                                                    },
                                                    shape = RoundedCornerShape(8.dp),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                                ) {
                                                    Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Elegir", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                                }
                                            } else {
                                                Column(
                                                    horizontalAlignment = Alignment.End,
                                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        IconButton(
                                                            onClick = {
                                                                if (curQty <= 1) {
                                                                    removeProductFromExpense(prod.id)
                                                                } else {
                                                                    adjustQtyInExpense(prod.id, -1)
                                                                }
                                                            },
                                                            modifier = Modifier.size(28.dp)
                                                        ) {
                                                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Menos", tint = RoseDanger, modifier = Modifier.size(18.dp))
                                                        }
                                                        Text(
                                                            text = "$curQty",
                                                            fontWeight = FontWeight.ExtraBold,
                                                            fontSize = 13.5.sp,
                                                            color = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.padding(horizontal = 4.dp)
                                                        )
                                                        IconButton(
                                                            onClick = {
                                                                adjustQtyInExpense(prod.id, 1)
                                                            },
                                                            modifier = Modifier.size(28.dp)
                                                        ) {
                                                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Más", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${selectedProductIds.size} seleccionados",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Button(
                                onClick = { showProductSelector = false },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Listo (${selectedProductIds.size})", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    expenseToEdit?.let { exp ->
        val isPurchase = exp.isProductPurchase || exp.category == ExpenseCategory.COMPRAS_PRODUCTOS.title
        var editDescription by remember(exp) { mutableStateOf(exp.description) }
        var editAmount by remember(exp) { mutableStateOf(exp.amount.toString()) }
        var editCategory by remember(exp) { mutableStateOf(exp.category) }
        var editExpenseTimestamp by remember(exp) { mutableStateOf(exp.timestamp) }
        var showEditExpenseDatePicker by remember { mutableStateOf(false) }
        var editSupplier by remember(exp) {
            val supp = if (exp.purchaseItemsDetails.contains("Proveedor: ")) {
                exp.purchaseItemsDetails.substringAfter("Proveedor: ").substringBefore(" | ")
            } else ""
            mutableStateOf(supp)
        }
        var editQuantity by remember(exp) {
            val q = if (exp.purchaseItemsDetails.contains(" x")) {
                exp.purchaseItemsDetails.substringAfter(" x").takeWhile { it.isDigit() }.toIntOrNull() ?: 1
            } else 1
            mutableStateOf(q.toString())
        }
        var editPurchasePrice by remember(exp) {
            val q = editQuantity.toIntOrNull() ?: 1
            val unitPrice = if (q > 0) exp.amount / q else exp.amount
            mutableStateOf(String.format(Locale.US, "%.2f", unitPrice))
        }
        var editSalePrice by remember(exp) {
            val matched = products.firstOrNull { exp.purchaseItemsDetails.contains(it.name, ignoreCase = true) || exp.description.contains(it.name, ignoreCase = true) }
            mutableStateOf(matched?.salePrice?.toString() ?: "")
        }

        Dialog(
            onDismissRequest = { expenseToEdit = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .fillMaxHeight(0.92f)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (isPurchase) "Modificar Compra de Producto" else "Editar Registro de Gasto",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { expenseToEdit = null },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Cerrar")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val editExpenseScrollState = rememberScrollState()
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(editExpenseScrollState),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                    if (isPurchase) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Modificando compra: ${exp.description}",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                        OutlinedTextField(
                            value = editSupplier,
                            onValueChange = { editSupplier = it },
                            label = { Text("Proveedor") },
                            placeholder = { Text("Nombre del proveedor / distribuidor") },
                            singleLine = true,
                            colors = omniTextFieldColors()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = editQuantity,
                                onValueChange = {
                                    if (it.all { char -> char.isDigit() }) {
                                        editQuantity = it
                                        val q = it.toIntOrNull() ?: 0
                                        val p = editPurchasePrice.toDoubleOrNull() ?: 0.0
                                        if (q > 0 && p > 0) editAmount = String.format(Locale.US, "%.2f", q * p)
                                    }
                                },
                                label = { Text("Cantidad comprada") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = omniTextFieldColors()
                            )
                            OutlinedTextField(
                                value = editPurchasePrice,
                                onValueChange = {
                                    editPurchasePrice = it
                                    val q = editQuantity.toIntOrNull() ?: 0
                                    val p = it.toDoubleOrNull() ?: 0.0
                                    if (q > 0 && p > 0) editAmount = String.format(Locale.US, "%.2f", q * p)
                                },
                                label = { Text("P. Compra Unit.") },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = omniTextFieldColors()
                            )
                        }
                        OutlinedTextField(
                            value = editSalePrice,
                            onValueChange = { editSalePrice = it },
                            label = { Text("Precio de Venta al Público (${currency.symbol})") },
                            placeholder = { Text("Actualizar precio en catálogo") },
                            singleLine = true,
                            colors = omniTextFieldColors()
                        )
                    } else {
                        OutlinedTextField(
                            value = editDescription,
                            onValueChange = { editDescription = it },
                            label = { Text("Descripción") },
                            singleLine = true,
                            colors = omniTextFieldColors()
                        )
                        OutlinedTextField(
                            value = editSupplier,
                            onValueChange = { editSupplier = it },
                            label = { Text("Proveedor / Beneficiario") },
                            singleLine = true,
                            colors = omniTextFieldColors()
                        )
                    }

                    OutlinedTextField(
                        value = editAmount,
                        onValueChange = { editAmount = it },
                        label = { Text("Monto Total (${currency.symbol})") },
                        singleLine = true,
                        colors = omniTextFieldColors()
                    )

                    // Modificación de la Fecha de Registro
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.primary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.CalendarMonth,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            if (isPurchase) "FECHA DE LA COMPRA:" else "FECHA DEL REGISTRO:",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            if (editExpenseTimestamp != exp.timestamp) "Fecha modificada manualmente" else "Fecha original del registro",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                if (editExpenseTimestamp != exp.timestamp) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = AmberContainer
                                    ) {
                                        Text(
                                            "Fecha Modificada",
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AmberAccent,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        val formattedDate = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(editExpenseTimestamp))
                                        Text(
                                            text = formattedDate,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = SimpleDateFormat("EEEE, dd 'de' MMMM", Locale("es", "ES")).format(Date(editExpenseTimestamp)).replaceFirstChar { it.uppercase() },
                                            fontSize = 10.5.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        if (editExpenseTimestamp != exp.timestamp) {
                                            OutlinedButton(
                                                onClick = { editExpenseTimestamp = exp.timestamp },
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.height(34.dp)
                                            ) {
                                                Text("Restablecer", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                        Button(
                                            onClick = { showEditExpenseDatePicker = true },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            modifier = Modifier.height(34.dp)
                                        ) {
                                            Icon(Icons.Default.EditCalendar, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Cambiar Fecha", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { expenseToEdit = null }) {
                            Text("Cancelar")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val parsed = editAmount.toDoubleOrNull() ?: exp.amount
                                if (isPurchase) {
                                    val matchedProd = products.firstOrNull { exp.purchaseItemsDetails.contains(it.name, ignoreCase = true) || exp.description.contains(it.name, ignoreCase = true) }
                                    viewModel.modifyProductPurchase(
                                        expenseId = exp.id,
                                        productId = matchedProd?.id,
                                        newQuantity = editQuantity.toIntOrNull() ?: 1,
                                        newPurchasePrice = editPurchasePrice.toDoubleOrNull() ?: (parsed / maxOf(1, editQuantity.toIntOrNull() ?: 1)),
                                        newSalePrice = editSalePrice.toDoubleOrNull() ?: (matchedProd?.salePrice ?: 0.0),
                                        newSupplier = editSupplier.trim(),
                                        newTimestamp = editExpenseTimestamp
                                    )
                                } else {
                                    val updatedDateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(editExpenseTimestamp))
                                    viewModel.updateExpense(
                                        exp.copy(
                                            description = editDescription.trim(),
                                            amount = parsed,
                                            category = editCategory,
                                            purchaseItemsDetails = if (editSupplier.isNotBlank()) "Proveedor: ${editSupplier.trim()}" else exp.purchaseItemsDetails,
                                            timestamp = editExpenseTimestamp,
                                            date = updatedDateStr
                                        )
                                    )
                                }
                                expenseToEdit = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Guardar Cambios", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (showEditExpenseDatePicker) {
            OmniDatePickerDialog(
                initialDateMillis = editExpenseTimestamp,
                onDateSelected = { selectedTime ->
                    editExpenseTimestamp = selectedTime
                    showEditExpenseDatePicker = false
                },
                onDismiss = { showEditExpenseDatePicker = false }
            )
        }
    }

    expenseToDelete?.let { exp ->
        AlertDialog(
            onDismissRequest = { expenseToDelete = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = RoseDanger)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Eliminar Gasto")
                }
            },
            text = {
                Text("¿Estás seguro de eliminar el gasto '${exp.description}' por ${currency.symbol} ${String.format(Locale.US, "%.2f", exp.amount)}? Esta acción afectará el balance contable.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteExpense(exp)
                        expenseToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseDanger)
                ) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
}
