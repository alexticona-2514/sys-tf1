package com.example.omnigestion.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.CurrencyType
import com.example.omnigestion.data.model.Expense
import com.example.omnigestion.data.model.Sale
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

enum class ChartType {
    SALES_TREND,
    CASH_FLOW
}

data class DayChartPoint(
    val dayLabel: String,
    val fullDateLabel: String,
    val timestamp: Long,
    val salesAmount: Double,
    val salesCount: Int,
    val expenseAmount: Double,
    val netCashFlow: Double
)

@Composable
fun RechartsDashboardCard(
    sales: List<Sale>,
    expenses: List<Expense>,
    currency: CurrencyType,
    modifier: Modifier = Modifier
) {
    var selectedChartType by remember { mutableStateOf(ChartType.SALES_TREND) }
    var selectedRangeDays by remember { mutableIntStateOf(7) }
    var selectedPointIndex by remember { mutableStateOf<Int?>(null) }

    val chartData = remember(sales, expenses, selectedRangeDays) {
        generateDailyChartData(sales, expenses, selectedRangeDays)
    }

    val totalSalesInRange = remember(chartData) { chartData.sumOf { it.salesAmount } }
    val totalExpenseInRange = remember(chartData) { chartData.sumOf { it.expenseAmount } }
    val netBalanceInRange = totalSalesInRange - totalExpenseInRange

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Análisis Interactivo",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "SYS-TF Analytics",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = if (selectedChartType == ChartType.SALES_TREND)
                            "Curva de ventas y tendencia diaria"
                        else
                            "Ingresos vs Gastos y Flujo de Caja",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Range Selector (7D / 14D / 30D)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    listOf(7 to "7D", 14 to "14D", 30 to "30D").forEach { (days, label) ->
                        val isSelected = selectedRangeDays == days
                        Surface(
                            onClick = {
                                selectedRangeDays = days
                                selectedPointIndex = null
                            },
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent,
                            shadowElevation = if (isSelected) 1.dp else 0.dp
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Chart Mode Selector Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    onClick = {
                        selectedChartType = ChartType.SALES_TREND
                        selectedPointIndex = null
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(9.dp),
                    color = if (selectedChartType == ChartType.SALES_TREND) MaterialTheme.colorScheme.primary else Color.Transparent
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                            contentDescription = null,
                            tint = if (selectedChartType == ChartType.SALES_TREND) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Tendencia Ventas",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedChartType == ChartType.SALES_TREND) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Surface(
                    onClick = {
                        selectedChartType = ChartType.CASH_FLOW
                        selectedPointIndex = null
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(9.dp),
                    color = if (selectedChartType == ChartType.CASH_FLOW) MaterialTheme.colorScheme.primary else Color.Transparent
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.BarChart,
                            contentDescription = null,
                            tint = if (selectedChartType == ChartType.CASH_FLOW) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Flujo de Caja",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedChartType == ChartType.CASH_FLOW) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tooltip preview
            val activePoint = selectedPointIndex?.let { chartData.getOrNull(it) }
            if (activePoint != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = activePoint.fullDateLabel,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${activePoint.salesCount} ventas realizadas",
                                color = SlateTextMuted,
                                fontSize = 11.sp
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Ventas", color = Color(0xFF34D399), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                Text("${currency.symbol} ${String.format(Locale.US, "%,.2f", activePoint.salesAmount)}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Gastos", color = Color(0xFFF87171), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                Text("${currency.symbol} ${String.format(Locale.US, "%,.2f", activePoint.expenseAmount)}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Flujo Neto", color = Color(0xFF60A5FA), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${if (activePoint.netCashFlow >= 0) "+" else ""}${currency.symbol} ${String.format(Locale.US, "%,.2f", activePoint.netCashFlow)}",
                                    color = if (activePoint.netCashFlow >= 0) Color(0xFF34D399) else Color(0xFFF87171),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.TouchApp, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Toca o arrastra el dedo sobre la gráfica para ver valores diarios.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Canvas Interactive Chart
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(8.dp)
            ) {
                if (selectedChartType == ChartType.SALES_TREND) {
                    RechartsSalesAreaCanvas(
                        data = chartData,
                        selectedIndex = selectedPointIndex,
                        onSelectIndex = { selectedPointIndex = it }
                    )
                } else {
                    RechartsCashFlowBarCanvas(
                        data = chartData,
                        selectedIndex = selectedPointIndex,
                        onSelectIndex = { selectedPointIndex = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Summary Metric Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricSummaryMiniCard(
                    title = "Ingresos Período",
                    value = "${currency.symbol} ${String.format(Locale.US, "%,.0f", totalSalesInRange)}",
                    color = EmeraldSuccess,
                    modifier = Modifier.weight(1f)
                )
                MetricSummaryMiniCard(
                    title = "Egresos Período",
                    value = "${currency.symbol} ${String.format(Locale.US, "%,.0f", totalExpenseInRange)}",
                    color = RoseDanger,
                    modifier = Modifier.weight(1f)
                )
                MetricSummaryMiniCard(
                    title = "Flujo Neto",
                    value = "${if (netBalanceInRange >= 0) "+" else ""}${currency.symbol} ${String.format(Locale.US, "%,.0f", netBalanceInRange)}",
                    color = if (netBalanceInRange >= 0) BlueAccent else RoseDanger,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricSummaryMiniCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(title, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
        }
    }
}

@Composable
private fun RechartsSalesAreaCanvas(
    data: List<DayChartPoint>,
    selectedIndex: Int?,
    onSelectIndex: (Int?) -> Unit
) {
    val maxVal = remember(data) { max(data.maxOfOrNull { it.salesAmount } ?: 100.0, 100.0) }
    val lineColor = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(data) {
                detectTapGestures(
                    onPress = { offset ->
                        val stepX = size.width / max(1, data.size - 1)
                        val idx = ((offset.x + stepX / 2) / stepX).toInt().coerceIn(0, data.size - 1)
                        onSelectIndex(idx)
                    }
                )
            }
            .pointerInput(data) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val stepX = size.width / max(1, data.size - 1)
                        val idx = ((offset.x + stepX / 2) / stepX).toInt().coerceIn(0, data.size - 1)
                        onSelectIndex(idx)
                    },
                    onDrag = { change, _ ->
                        val stepX = size.width / max(1, data.size - 1)
                        val idx = ((change.position.x + stepX / 2) / stepX).toInt().coerceIn(0, data.size - 1)
                        onSelectIndex(idx)
                    }
                )
            }
    ) {
        val width = size.width
        val height = size.height - 24.dp.toPx()
        val bottomY = height
        val n = data.size
        if (n < 2) return@Canvas
        val stepX = width / (n - 1)

        val gridLines = 4
        for (i in 0..gridLines) {
            val y = (height / gridLines) * i
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
            )
        }

        val points = data.mapIndexed { i, pt ->
            val x = i * stepX
            val ratio = (pt.salesAmount / maxVal).coerceIn(0.0, 1.0).toFloat()
            val y = bottomY - (ratio * (bottomY - 16.dp.toPx()))
            Offset(x, y)
        }

        val linePath = Path()
        val areaPath = Path()
        linePath.moveTo(points.first().x, points.first().y)
        areaPath.moveTo(points.first().x, bottomY)
        areaPath.lineTo(points.first().x, points.first().y)

        for (i in 0 until points.size - 1) {
            val p0 = points[i]
            val p1 = points[i + 1]
            val cx = (p0.x + p1.x) / 2f
            linePath.cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
            areaPath.cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
        }
        areaPath.lineTo(points.last().x, bottomY)
        areaPath.close()

        val areaGradient = Brush.verticalGradient(
            colors = listOf(
                lineColor.copy(alpha = 0.35f),
                lineColor.copy(alpha = 0.10f),
                Color.Transparent
            ),
            startY = 0f,
            endY = bottomY
        )
        drawPath(path = areaPath, brush = areaGradient)
        drawPath(
            path = linePath,
            color = lineColor,
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        points.forEachIndexed { i, p ->
            val isSelected = selectedIndex == i
            val dotRadius = if (isSelected) 6.dp.toPx() else 3.5.dp.toPx()
            if (isSelected) {
                drawCircle(
                    color = lineColor.copy(alpha = 0.3f),
                    radius = 11.dp.toPx(),
                    center = p
                )
            }
            drawCircle(
                color = Color.White,
                radius = dotRadius + 1.5.dp.toPx(),
                center = p
            )
            drawCircle(
                color = lineColor,
                radius = dotRadius,
                center = p
            )
        }

        selectedIndex?.let { idx ->
            val p = points.getOrNull(idx)
            if (p != null) {
                drawLine(
                    color = lineColor.copy(alpha = 0.6f),
                    start = Offset(p.x, 0f),
                    end = Offset(p.x, bottomY),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))
                )
            }
        }
    }
}

@Composable
private fun RechartsCashFlowBarCanvas(
    data: List<DayChartPoint>,
    selectedIndex: Int?,
    onSelectIndex: (Int?) -> Unit
) {
    val maxVal = remember(data) {
        max(
            data.maxOfOrNull { max(it.salesAmount, it.expenseAmount) } ?: 100.0,
            100.0
        )
    }
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(data) {
                detectTapGestures(
                    onPress = { offset ->
                        val slotWidth = size.width / data.size
                        val idx = (offset.x / slotWidth).toInt().coerceIn(0, data.size - 1)
                        onSelectIndex(idx)
                    }
                )
            }
            .pointerInput(data) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val slotWidth = size.width / data.size
                        val idx = (offset.x / slotWidth).toInt().coerceIn(0, data.size - 1)
                        onSelectIndex(idx)
                    },
                    onDrag = { change, _ ->
                        val slotWidth = size.width / data.size
                        val idx = ((change.position.x) / slotWidth).toInt().coerceIn(0, data.size - 1)
                        onSelectIndex(idx)
                    }
                )
            }
    ) {
        val width = size.width
        val height = size.height - 20.dp.toPx()
        val bottomY = height
        val n = data.size
        if (n == 0) return@Canvas

        val slotWidth = width / n
        val barWidth = (slotWidth * 0.32f).coerceIn(4f, 20f)
        val gap = barWidth * 0.2f

        for (i in 0..3) {
            val y = (height / 3) * i
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
            )
        }

        data.forEachIndexed { i, pt ->
            val centerX = i * slotWidth + (slotWidth / 2f)
            val isSelected = selectedIndex == i

            if (isSelected) {
                drawRoundRect(
                    color = Color.LightGray.copy(alpha = 0.25f),
                    topLeft = Offset(i * slotWidth, 0f),
                    size = Size(slotWidth, height),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                )
            }

            // Sales (Inflows) Bar (Green)
            val salesRatio = (pt.salesAmount / maxVal).coerceIn(0.0, 1.0).toFloat()
            val salesBarHeight = (salesRatio * (bottomY - 10.dp.toPx())).coerceAtLeast(3f)
            val salesLeft = centerX - barWidth - (gap / 2)
            val salesTop = bottomY - salesBarHeight

            drawRoundRect(
                color = EmeraldSuccess,
                topLeft = Offset(salesLeft, salesTop),
                size = Size(barWidth, salesBarHeight),
                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )

            // Expense (Outflows) Bar (Red)
            val expenseRatio = (pt.expenseAmount / maxVal).coerceIn(0.0, 1.0).toFloat()
            val expenseBarHeight = (expenseRatio * (bottomY - 10.dp.toPx())).coerceAtLeast(3f)
            val expenseLeft = centerX + (gap / 2)
            val expenseTop = bottomY - expenseBarHeight

            drawRoundRect(
                color = RoseDanger,
                topLeft = Offset(expenseLeft, expenseTop),
                size = Size(barWidth, expenseBarHeight),
                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
            )
        }

        selectedIndex?.let { idx ->
            val slotX = idx * slotWidth + (slotWidth / 2f)
            drawLine(
                color = Color.Gray.copy(alpha = 0.5f),
                start = Offset(slotX, 0f),
                end = Offset(slotX, bottomY),
                strokeWidth = 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))
            )
        }
    }
}

private fun generateDailyChartData(
    sales: List<Sale>,
    expenses: List<Expense>,
    days: Int
): List<DayChartPoint> {
    val sdfDay = SimpleDateFormat("EEE dd", Locale("es", "ES"))
    val sdfFull = SimpleDateFormat("EEEE dd MMMM", Locale("es", "ES"))
    val sdfKey = SimpleDateFormat("yyyyMMdd", Locale.getDefault())

    val validSales = sales.filter { it.paymentStatus != "ANULADO" }
    val salesByDay = validSales.groupBy { sale ->
        val c = Calendar.getInstance().apply { timeInMillis = sale.timestamp }
        sdfKey.format(c.time)
    }
    val expensesByDay = expenses.groupBy { exp ->
        val c = Calendar.getInstance().apply { timeInMillis = exp.timestamp }
        sdfKey.format(c.time)
    }

    val points = mutableListOf<DayChartPoint>()
    for (i in (days - 1) downTo 0) {
        val dayCal = Calendar.getInstance()
        dayCal.add(Calendar.DAY_OF_YEAR, -i)
        val key = sdfKey.format(dayCal.time)
        val daySales = salesByDay[key] ?: emptyList()
        val dayExpenses = expensesByDay[key] ?: emptyList()

        val salesSum = daySales.sumOf { it.totalAmount }
        val expensesSum = dayExpenses.sumOf { it.amount }

        points.add(
            DayChartPoint(
                dayLabel = sdfDay.format(dayCal.time).replace(".", "").replaceFirstChar { it.uppercase() },
                fullDateLabel = sdfFull.format(dayCal.time).replaceFirstChar { it.uppercase() },
                timestamp = dayCal.timeInMillis,
                salesAmount = salesSum,
                salesCount = daySales.size,
                expenseAmount = expensesSum,
                netCashFlow = salesSum - expensesSum
            )
        )
    }
    return points
}
