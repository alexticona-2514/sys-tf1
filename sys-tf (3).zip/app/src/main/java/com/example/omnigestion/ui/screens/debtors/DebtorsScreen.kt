package com.example.omnigestion.ui.screens.debtors

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.Customer
import com.example.omnigestion.data.model.PaymentMethod
import com.example.omnigestion.data.model.RoleType
import com.example.omnigestion.ui.components.omniTextFieldColors
import com.example.omnigestion.ui.viewmodel.OmniViewModel
import com.example.ui.theme.*
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DebtorsScreen(viewModel: OmniViewModel) {
    val debtorCustomers by viewModel.debtorCustomers.collectAsState()
    val allCustomers by viewModel.customers.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var selectedCustomerForPayment by remember { mutableStateOf<Customer?>(null) }
    var showAddEditCustomerDialog by remember { mutableStateOf(false) }
    var customerToEdit by remember { mutableStateOf<Customer?>(null) }
    var customerToDelete by remember { mutableStateOf<Customer?>(null) }
    var customerToClearDebt by remember { mutableStateOf<Customer?>(null) }
    var debtBlockedCustomer by remember { mutableStateOf<Customer?>(null) }

    val totalDeuda = remember(debtorCustomers) { debtorCustomers.sumOf { it.currentDebt } }

    val filteredCustomers = remember(allCustomers, searchQuery) {
        if (searchQuery.isBlank()) allCustomers else allCustomers.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.phone.contains(searchQuery) ||
                    it.email.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredDebtors = remember(debtorCustomers, searchQuery) {
        if (searchQuery.isBlank()) debtorCustomers else debtorCustomers.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.phone.contains(searchQuery)
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    customerToEdit = null
                    showAddEditCustomerDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Registrar Cliente")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(14.dp)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cuentas de Clientes (${allCustomers.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CreditScore, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Deudores (${debtorCustomers.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                )
            }
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(if (selectedTab == 0) "Buscar cliente por nombre, teléfono o dirección..." else "Buscar deudor...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = omniTextFieldColors(),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))

            when (selectedTab) {
                0 -> {
                    if (filteredCustomers.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.PersonOutline, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("No hay clientes registrados aún.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(filteredCustomers, key = { it.id }) { customer ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(14.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(42.dp)
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                                }
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Column {
                                                    Text(customer.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                                                    Text("Tel: ${customer.phone}", fontSize = 12.sp, color = BlueAccent, fontWeight = FontWeight.SemiBold)
                                                }
                                            }
                                            Row {
                                                IconButton(
                                                    onClick = {
                                                        customerToEdit = customer
                                                        showAddEditCustomerDialog = true
                                                    },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(Icons.Default.Edit, contentDescription = "Editar", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                                                }
                                                if (customer.currentDebt > 0.01) {
                                                    if (currentRole == RoleType.ADMIN) {
                                                        IconButton(
                                                            onClick = { customerToClearDebt = customer },
                                                            modifier = Modifier.size(32.dp)
                                                        ) {
                                                            Icon(
                                                                Icons.Default.DeleteSweep,
                                                                contentDescription = "Eliminar Deuda (Exclusivo Admin)",
                                                                tint = RoseDanger,
                                                                modifier = Modifier.size(20.dp)
                                                            )
                                                        }
                                                    }
                                                    IconButton(
                                                        onClick = { debtBlockedCustomer = customer },
                                                        modifier = Modifier.size(32.dp)
                                                    ) {
                                                        Icon(Icons.Default.Lock, contentDescription = "Bloqueado por deuda", tint = RoseDanger.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                                                    }
                                                } else {
                                                    IconButton(
                                                        onClick = { customerToDelete = customer },
                                                        modifier = Modifier.size(32.dp)
                                                    ) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = RoseDanger, modifier = Modifier.size(18.dp))
                                                    }
                                                }
                                            }
                                        }
                                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                if (customer.email.isNotBlank()) {
                                                    Text("Email: ${customer.email}", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                                if (customer.address.isNotBlank()) {
                                                    Text("Dirección: ${customer.address}", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                                Text("Límite crédito: ${currency.symbol} ${String.format(Locale.US, "%.2f", customer.creditLimit)}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("Deuda Actual", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text(
                                                    text = "${currency.symbol} ${String.format(Locale.US, "%.2f", customer.currentDebt)}",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = if (customer.currentDebt > 0) RoseDanger else EmeraldSuccess
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Total Deudas por Cobrar", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${currency.symbol} ${String.format(Locale.US, "%,.2f", totalDeuda)}",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = RoseDanger
                                )
                                Text("${debtorCustomers.size} clientes con saldo pendiente", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(RoseContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = RoseDanger, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    if (filteredDebtors.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("¡Excelente! No hay clientes con deudas pendientes.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(filteredDebtors, key = { it.id }) { customer ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(14.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(customer.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                                            Text("Tel: ${customer.phone} • Límite: Bs ${customer.creditLimit}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "${currency.symbol} ${String.format(Locale.US, "%.2f", customer.currentDebt)}",
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 16.sp,
                                                color = RoseDanger
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                if (currentRole == RoleType.ADMIN) {
                                                    OutlinedButton(
                                                        onClick = { customerToClearDebt = customer },
                                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = RoseDanger),
                                                        shape = RoundedCornerShape(8.dp),
                                                        border = androidx.compose.foundation.BorderStroke(1.dp, RoseDanger),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                                    ) {
                                                        Icon(Icons.Default.DeleteSweep, contentDescription = "Eliminar Deuda", modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Eliminar Deuda", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                                Button(
                                                    onClick = {
                                                        selectedCustomerForPayment = customer
                                                        showPaymentDialog = true
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                                    shape = RoundedCornerShape(8.dp),
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                                ) {
                                                    Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Abonar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddEditCustomerDialog) {
        var name by remember { mutableStateOf(customerToEdit?.name ?: "") }
        var phone by remember { mutableStateOf(customerToEdit?.phone ?: "") }
        var email by remember { mutableStateOf(customerToEdit?.email ?: "") }
        var address by remember { mutableStateOf(customerToEdit?.address ?: "") }
        var creditLimitText by remember { mutableStateOf(customerToEdit?.creditLimit?.toString() ?: "2000.0") }
        var notes by remember { mutableStateOf(customerToEdit?.notes ?: "") }

        AlertDialog(
            onDismissRequest = { showAddEditCustomerDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (customerToEdit == null) "Nuevo Cliente (CRM)" else "Editar Cliente", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nombre Completo / Razón Social *") },
                        singleLine = true,
                        colors = omniTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Teléfono / WhatsApp *") },
                        placeholder = { Text("ej. 70011223") },
                        singleLine = true,
                        colors = omniTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Correo Electrónico (Opcional)") },
                        singleLine = true,
                        colors = omniTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Dirección (Opcional)") },
                        singleLine = true,
                        colors = omniTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = creditLimitText,
                        onValueChange = { creditLimitText = it },
                        label = { Text("Límite de Crédito (${currency.symbol})") },
                        singleLine = true,
                        colors = omniTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notas / Observaciones") },
                        singleLine = true,
                        colors = omniTextFieldColors(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            val limit = creditLimitText.toDoubleOrNull() ?: 2000.0
                            val c = (customerToEdit ?: Customer(name = name.trim(), phone = phone.trim())).copy(
                                name = name.trim(),
                                phone = phone.trim(),
                                email = email.trim(),
                                address = address.trim(),
                                creditLimit = limit,
                                notes = notes.trim()
                            )
                            viewModel.saveCustomer(c)
                            showAddEditCustomerDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(if (customerToEdit == null) "Guardar Cliente" else "Actualizar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddEditCustomerDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    customerToDelete?.let { cust ->
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = RoseDanger)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Eliminar Cliente")
                }
            },
            text = {
                Text("¿Estás seguro de eliminar a '${cust.name}'? El cliente no posee ninguna deuda pendiente.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteCustomer(cust)
                        customerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseDanger)
                ) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    debtBlockedCustomer?.let { blockedCust ->
        AlertDialog(
            onDismissRequest = { debtBlockedCustomer = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = RoseDanger)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("No se puede eliminar", color = RoseDanger, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "El cliente '${blockedCust.name}' tiene una deuda activa pendiente de ${currency.symbol} ${String.format(Locale.US, "%.2f", blockedCust.currentDebt)}.",
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "Por política de seguridad y control financiero, no es posible eliminar a un cliente hasta que termine de pagar la totalidad de su deuda.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedCustomerForPayment = blockedCust
                        showPaymentDialog = true
                        debtBlockedCustomer = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Cobrar Deuda")
                }
            },
            dismissButton = {
                TextButton(onClick = { debtBlockedCustomer = null }) {
                    Text("Entendido")
                }
            }
        )
    }

    if (showPaymentDialog && selectedCustomerForPayment != null) {
        val cust = selectedCustomerForPayment!!
        var amountText by remember { mutableStateOf("") }
        var paymentMethod by remember { mutableStateOf(PaymentMethod.EFECTIVO) }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showPaymentDialog = false },
            title = { Text("Registrar Abono a Deuda", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Cliente: ${cust.name}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        "Saldo Pendiente: ${currency.symbol} ${String.format(Locale.US, "%.2f", cust.currentDebt)}",
                        color = RoseDanger,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Monto a Abonar (${currency.symbol})") },
                        singleLine = true,
                        colors = omniTextFieldColors()
                    )
                    Text("Método de Pago:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(PaymentMethod.EFECTIVO, PaymentMethod.QR_BANCARIO, PaymentMethod.TARJETA).forEach { m ->
                            val isSel = paymentMethod == m
                            Surface(
                                onClick = { paymentMethod = m },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.weight(1f).height(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = when(m) {
                                            PaymentMethod.EFECTIVO -> "Efectivo"
                                            PaymentMethod.QR_BANCARIO -> "QR"
                                            else -> "Tarjeta"
                                        },
                                        color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notas / Referencia (Opcional)") },
                        singleLine = true,
                        colors = omniTextFieldColors()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = amountText.toDoubleOrNull() ?: 0.0
                        if (amount > 0) {
                            viewModel.recordCustomerPayment(
                                customer = cust,
                                amount = amount,
                                method = paymentMethod,
                                notes = notes
                            )
                            showPaymentDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Text("Confirmar Pago")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPaymentDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    customerToClearDebt?.let { customer ->
        AlertDialog(
            onDismissRequest = { customerToClearDebt = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = RoseDanger)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Eliminar Deuda (Exclusivo Administrador)", fontWeight = FontWeight.Bold, color = RoseDanger, fontSize = 15.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "¿Confirmas eliminar y condonar por completo la deuda de ${customer.name}?",
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Surface(
                        color = RoseContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Monto a condonar:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "${currency.symbol} ${String.format(Locale.US, "%.2f", customer.currentDebt)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = RoseDanger
                            )
                        }
                    }
                    Text(
                        text = "Esta acción pondrá el saldo pendiente del cliente en 0.00 de forma inmediata y quedará asentado en el historial de auditoría del Administrador.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearCustomerDebt(customer.id)
                        customerToClearDebt = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseDanger)
                ) {
                    Text("Eliminar Deuda a 0.00", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { customerToClearDebt = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
