package com.example.omnigestion.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.RoleType

@Composable
fun OmniBottomNav(
    currentRoute: String,
    currentRole: RoleType,
    onNavigate: (String) -> Unit,
    onMoreClick: () -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("bottom_nav_bar")
    ) {
        when (currentRole) {
            RoleType.ADMIN -> {
                NavigationBarItem(
                    selected = currentRoute == "dashboard",
                    onClick = { onNavigate("dashboard") },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Panel") },
                    label = { Text("Panel", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = currentRoute == "pos",
                    onClick = { onNavigate("pos") },
                    icon = { Icon(Icons.Default.PointOfSale, contentDescription = "Ventas") },
                    label = { Text("Venta", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = currentRoute == "inventory",
                    onClick = { onNavigate("inventory") },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = "Inventario") },
                    label = { Text("Inventario", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = currentRoute == "finances",
                    onClick = { onNavigate("finances") },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Finanzas") },
                    label = { Text("Finanzas", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onMoreClick,
                    icon = { Icon(Icons.Default.Menu, contentDescription = "Más") },
                    label = { Text("Más", fontSize = 10.sp) }
                )
            }
            RoleType.EMPLEADO, RoleType.CAJERO -> {
                NavigationBarItem(
                    selected = currentRoute == "pos",
                    onClick = { onNavigate("pos") },
                    icon = { Icon(Icons.Default.PointOfSale, contentDescription = "Ventas") },
                    label = { Text("Vender", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = currentRoute == "inventory",
                    onClick = { onNavigate("inventory") },
                    icon = { Icon(Icons.Default.Inventory2, contentDescription = "Inventario") },
                    label = { Text("Inventario", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = currentRoute == "sales_history",
                    onClick = { onNavigate("sales_history") },
                    icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Historial") },
                    label = { Text("Historial", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = currentRoute == "debtors",
                    onClick = { onNavigate("debtors") },
                    icon = { Icon(Icons.Default.CreditScore, contentDescription = "Cobranzas") },
                    label = { Text("Cobranzas", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = currentRoute == "employees",
                    onClick = { onNavigate("employees") },
                    icon = { Icon(Icons.Default.AccessTime, contentDescription = "Turno") },
                    label = { Text("Turno", fontSize = 10.sp) }
                )
            }
            RoleType.CLIENTE -> {
                NavigationBarItem(
                    selected = currentRoute == "client_portal",
                    onClick = { onNavigate("client_portal") },
                    icon = { Icon(Icons.Default.Storefront, contentDescription = "Catálogo") },
                    label = { Text("Productos", fontSize = 10.sp) }
                )
                NavigationBarItem(
                    selected = currentRoute == "settings",
                    onClick = { onNavigate("settings") },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Mi Perfil") },
                    label = { Text("Perfil", fontSize = 10.sp) }
                )
            }
        }
    }
}
