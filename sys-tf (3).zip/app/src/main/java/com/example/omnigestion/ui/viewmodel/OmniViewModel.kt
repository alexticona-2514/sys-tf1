package com.example.omnigestion.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.omnigestion.data.ai.GeminiErpService
import com.example.omnigestion.data.firebase.FirestoreSyncManager
import com.example.omnigestion.data.firebase.FirestoreSyncStatus
import com.example.omnigestion.data.local.AppDatabase
import com.example.omnigestion.data.local.UserSessionManager
import com.example.omnigestion.data.model.*
import com.example.omnigestion.data.notifications.NotificationHelper
import com.example.omnigestion.data.pdf.PdfReportGenerator
import com.example.omnigestion.data.repository.OmniRepository
import com.example.omnigestion.data.util.InventoryFileExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

enum class AppScreen {
    LOGIN,
    DASHBOARD,
    POS,
    INVENTORY,
    RECOUNT_AUDIT,
    TRANSFERS,
    EMPLOYEES,
    DEBTORS,
    FINANCES,
    AUDIT_LOGS,
    SALES_HISTORY,
    REPORTS,
    CLIENT_PORTAL,
    SETTINGS
}

class OmniViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = OmniRepository(db)
    val userSessionManager = UserSessionManager(application)
    private val firestoreSync = FirestoreSyncManager(application, db, viewModelScope)
    val geminiService = GeminiErpService
    val notificationHelper = NotificationHelper

    // Current User & Session
    private val _currentUser = MutableStateFlow<Employee?>(null)
    val currentUser: StateFlow<Employee?> = _currentUser.asStateFlow()

    private val _currentRole = MutableStateFlow<RoleType>(RoleType.EMPLEADO)
    val currentRole: StateFlow<RoleType> = _currentRole.asStateFlow()

    // Feedback & Navigation
    private val _userFeedback = MutableStateFlow<String?>(null)
    val userFeedback: StateFlow<String?> = _userFeedback.asStateFlow()

    private val _navigationEvent = MutableSharedFlow<String>(replay = 0, extraBufferCapacity = 1)
    val navigationEvent: SharedFlow<String> = _navigationEvent.asSharedFlow()

    val firestoreSyncStatus: StateFlow<FirestoreSyncStatus> = firestoreSync.syncStatus

    // Settings
    val settings: StateFlow<BusinessSettings> = repository.businessSettings
        .map { it ?: BusinessSettings() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, BusinessSettings())

    // Database entities streams
    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockProducts: StateFlow<List<Product>> = repository.lowStockProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val warehouses: StateFlow<List<Warehouse>> = repository.allWarehouses
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _activeWarehouseId = MutableStateFlow("wh_central")
    val activeWarehouseId: StateFlow<String> = _activeWarehouseId.asStateFlow()

    val employees: StateFlow<List<Employee>> = repository.allEmployees
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val debtorCustomers: StateFlow<List<Customer>> = repository.debtorCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customerPayments: StateFlow<List<CustomerPayment>> = repository.allCustomerPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<Sale>> = repository.allSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val saleItems: StateFlow<List<SaleItem>> = repository.allSaleItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<Expense>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchaseOrders: StateFlow<List<PurchaseOrder>> = repository.allPurchaseOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transfers: StateFlow<List<StockTransfer>> = repository.allTransfers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val suppliers: StateFlow<List<Supplier>> = repository.allSuppliers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val attendances: StateFlow<List<Attendance>> = repository.allAttendances
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLog>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // POS State
    private val _cart = MutableStateFlow<Map<String, Int>>(emptyMap())
    val cart: StateFlow<Map<String, Int>> = _cart.asStateFlow()

    private val _cartCustomPrices = MutableStateFlow<Map<String, Double>>(emptyMap())
    val cartCustomPrices: StateFlow<Map<String, Double>> = _cartCustomPrices.asStateFlow()

    private val _selectedCustomerId = MutableStateFlow<String?>(null)
    val selectedCustomerId: StateFlow<String?> = _selectedCustomerId.asStateFlow()

    private val _selectedCurrency = MutableStateFlow(CurrencyType.BOB)
    val selectedCurrency: StateFlow<CurrencyType> = _selectedCurrency.asStateFlow()

    fun setCurrency(currency: CurrencyType) {
        _selectedCurrency.value = currency
    }

    private val _posPaymentMethod = MutableStateFlow(PaymentMethod.EFECTIVO)
    val posPaymentMethod: StateFlow<PaymentMethod> = _posPaymentMethod.asStateFlow()

    private val _isCashRegisterOpen = MutableStateFlow(true)
    val isCashRegisterOpen: StateFlow<Boolean> = _isCashRegisterOpen.asStateFlow()

    private val _cashRegisterStartingAmount = MutableStateFlow(0.0)
    val cashRegisterStartingAmount: StateFlow<Double> = _cashRegisterStartingAmount.asStateFlow()

    private val _activeQrSale = MutableStateFlow<Sale?>(null)
    val activeQrSale: StateFlow<Sale?> = _activeQrSale.asStateFlow()

    private val _lastCompletedReceipt = MutableStateFlow<Pair<Sale, List<SaleItem>>?>(null)
    val lastCompletedReceipt: StateFlow<Pair<Sale, List<SaleItem>>?> = _lastCompletedReceipt.asStateFlow()

    // Recount State
    private val _recountInputs = MutableStateFlow<Map<String, Int>>(emptyMap())
    val recountInputs: StateFlow<Map<String, Int>> = _recountInputs.asStateFlow()

    // Custom Categories
    private val _customCategories = MutableStateFlow<List<String>>(emptyList())
    val customCategories: StateFlow<List<String>> = _customCategories.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureDefaultAdmin()
            restoreSavedSession()
            restoreCartDraft()
            observeLowStock()
        }
    }

    private fun restoreSavedSession() {
        val saved = userSessionManager.getSavedEmployee()
        if (saved != null) {
            _currentUser.value = saved
            _currentRole.value = try {
                RoleType.valueOf(saved.role.uppercase())
            } catch (e: Exception) {
                RoleType.EMPLEADO
            }
        }
    }

    private fun restoreCartDraft() {
        val (cartStr, pricesStr, custId) = userSessionManager.getCartDraft()
        if (cartStr.isNotBlank()) {
            try {
                val map = cartStr.split(";")
                    .mapNotNull {
                        val parts = it.split(":")
                        if (parts.size == 2) parts[0] to parts[1].toInt() else null
                    }.toMap()
                _cart.value = map
            } catch (e: Exception) {
                Log.w("OmniViewModel", "Error restoring cart draft: ${e.message}")
            }
        }
        if (pricesStr.isNotBlank()) {
            try {
                val pMap = pricesStr.split(";")
                    .mapNotNull {
                        val parts = it.split(":")
                        if (parts.size == 2) parts[0] to parts[1].toDouble() else null
                    }.toMap()
                _cartCustomPrices.value = pMap
            } catch (e: Exception) {
                Log.w("OmniViewModel", "Error restoring custom prices draft: ${e.message}")
            }
        }
        if (custId.isNotBlank()) {
            _selectedCustomerId.value = custId
        }
    }

    private fun persistCartDraft() {
        val cartStr = _cart.value.entries.joinToString(";") { "${it.key}:${it.value}" }
        val priceStr = _cartCustomPrices.value.entries.joinToString(";") { "${it.key}:${it.value}" }
        userSessionManager.saveCartDraft(cartStr, priceStr, _selectedCustomerId.value)
    }

    private fun observeLowStock() {
        viewModelScope.launch {
            val app = getApplication<Application>()
            repository.lowStockProducts.collect { lowList ->
                if (lowList.isNotEmpty()) {
                    val first = lowList.first()
                    NotificationHelper.notifyLowStock(app, first.name, first.stockQuantity, first.minStock)
                }
            }
        }
    }

    fun showFeedback(msg: String) {
        _userFeedback.value = msg
    }

    fun clearFeedback() {
        _userFeedback.value = null
    }

    fun navigateTo(screen: AppScreen) {
        val route = com.example.omnigestion.ui.navigation.Routes.fromAppScreen(screen)
        _navigationEvent.tryEmit(route)
    }

    fun setCurrentScreenFromRoute(route: String) {
        // Keeps internal tracker in sync if needed
    }

    // --- Authentication ---
    fun login(identifier: String, pass: String, keepSession: Boolean = true): Boolean {
        val trimmedId = identifier.trim()
        val emps = employees.value

        val matched = emps.firstOrNull { emp ->
            (emp.email.equals(trimmedId, ignoreCase = true) || emp.phone.equals(trimmedId, ignoreCase = true)) &&
                    emp.password == pass.trim()
        }

        if (matched != null) {
            _currentUser.value = matched
            _currentRole.value = try {
                RoleType.valueOf(matched.role.uppercase())
            } catch (e: Exception) {
                RoleType.EMPLEADO
            }
            userSessionManager.saveSession(matched, keepSession)
            showFeedback("Bienvenido, ${matched.fullName}")
            return true
        } else {
            showFeedback("Credenciales incorrectas")
            return false
        }
    }

    fun registerUser(
        fullName: String,
        email: String,
        phone: String,
        address: String,
        role: RoleType,
        password: String,
        adminAuthKey: String = "",
        keepSession: Boolean = true
    ): Boolean = registerUser(fullName, email, phone, address, role.name, password, adminAuthKey, keepSession)

    fun registerUser(
        fullName: String,
        email: String,
        phone: String,
        address: String,
        role: String,
        password: String,
        adminAuthKey: String = "",
        keepSession: Boolean = true
    ): Boolean {
        if (role == RoleType.ADMIN.name && adminAuthKey != "1717") {
            showFeedback("Clave de autorización administrativa incorrecta")
            return false
        }
        val newEmp = Employee(
            id = UUID.randomUUID().toString(),
            fullName = fullName.trim(),
            email = email.trim(),
            phone = phone.trim(),
            address = address.trim(),
            role = role,
            password = password.trim()
        )
        viewModelScope.launch {
            repository.insertEmployee(newEmp, _currentUser.value)
            _currentUser.value = newEmp
            _currentRole.value = try {
                RoleType.valueOf(newEmp.role.uppercase())
            } catch (e: Exception) {
                RoleType.EMPLEADO
            }
            userSessionManager.saveSession(newEmp, keepSession)
            showFeedback("Usuario ${newEmp.fullName} registrado con éxito")
        }
        return true
    }

    fun logout() {
        _currentUser.value = null
        _currentRole.value = RoleType.EMPLEADO
        userSessionManager.clearSession()
        showFeedback("Sesión cerrada")
    }

    fun quickSwitchUser(emp: Employee) {
        _currentUser.value = emp
        _currentRole.value = try {
            RoleType.valueOf(emp.role.uppercase())
        } catch (e: Exception) {
            RoleType.EMPLEADO
        }
        userSessionManager.saveSession(emp, userSessionManager.isKeepSessionLoggedIn)
        showFeedback("Sesión cambiada a ${emp.fullName}")
    }

    fun triggerCloudSync() {
        viewModelScope.launch {
            firestoreSync.triggerFullSync()
            showFeedback("Sincronización en la nube iniciada")
        }
    }

    // --- Warehouses ---
    fun setActiveWarehouse(warehouseId: String) {
        _activeWarehouseId.value = warehouseId
    }

    fun addWarehouse(name: String, location: String) {
        viewModelScope.launch {
            val wh = Warehouse(
                id = UUID.randomUUID().toString(),
                name = name.trim(),
                location = location.trim(),
                isDefault = false
            )
            repository.insertWarehouse(wh)
            showFeedback("Sucursal ${wh.name} creada exitosamente")
        }
    }

    // --- POS & Cart ---
    fun addToCart(productId: String, quantity: Int = 1) {
        val prod = products.value.firstOrNull { it.id == productId }
        if (prod != null) {
            addToCart(prod, quantity)
        }
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        val current = _cart.value.toMutableMap()
        val currQty = current[product.id] ?: 0
        val newQty = currQty + quantity
        if (newQty <= product.stockQuantity) {
            current[product.id] = newQty
            _cart.value = current
            persistCartDraft()
        } else {
            showFeedback("Stock insuficiente. Disponible: ${product.stockQuantity}")
        }
    }

    fun removeFromCart(productId: String) {
        val current = _cart.value.toMutableMap()
        current.remove(productId)
        _cart.value = current
        val pMap = _cartCustomPrices.value.toMutableMap()
        pMap.remove(productId)
        _cartCustomPrices.value = pMap
        persistCartDraft()
    }

    fun updateCartQuantity(productId: String, newQty: Int) {
        val prod = products.value.firstOrNull { it.id == productId }
        if (newQty <= 0) {
            removeFromCart(productId)
            return
        }
        if (prod != null && newQty > prod.stockQuantity) {
            showFeedback("Stock insuficiente para ${prod.name}. Máx: ${prod.stockQuantity}")
            return
        }
        val current = _cart.value.toMutableMap()
        current[productId] = newQty
        _cart.value = current
        persistCartDraft()
    }

    fun clearCart() {
        _cart.value = emptyMap()
        _cartCustomPrices.value = emptyMap()
        _selectedCustomerId.value = null
        userSessionManager.clearCartDraft()
    }

    fun updateCartCustomPrice(productId: String, price: Double) {
        val current = _cartCustomPrices.value.toMutableMap()
        current[productId] = price
        _cartCustomPrices.value = current
        persistCartDraft()
    }

    fun removeCartCustomPrice(productId: String) {
        val current = _cartCustomPrices.value.toMutableMap()
        current.remove(productId)
        _cartCustomPrices.value = current
        persistCartDraft()
    }

    fun selectCustomer(customerId: String?) {
        _selectedCustomerId.value = customerId
        persistCartDraft()
    }

    fun setPosPaymentMethod(method: PaymentMethod) {
        _posPaymentMethod.value = method
    }

    fun processSale(notes: String = "", customTimestamp: Long? = null) {
        processSaleInternal(_posPaymentMethod.value, notes, customTimestamp, null)
    }

    fun processSale(
        paymentMethod: PaymentMethod,
        notes: String = "",
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        processSaleInternal(paymentMethod, notes, null, onComplete)
    }

    private fun processSaleInternal(
        paymentMethod: PaymentMethod,
        notes: String = "",
        customTimestamp: Long? = null,
        onComplete: ((Boolean) -> Unit)? = null
    ) {
        val currentCart = _cart.value
        if (currentCart.isEmpty()) {
            showFeedback("El carrito está vacío")
            onComplete?.invoke(false)
            return
        }

        val allProds = products.value.associateBy { it.id }
        val saleId = UUID.randomUUID().toString()
        val now = customTimestamp ?: System.currentTimeMillis()
        val saleNumber = "V-" + SimpleDateFormat("yyMMdd-HHmmss", Locale.getDefault()).format(Date(now))
        val currentEmp = _currentUser.value
        val empId = currentEmp?.id ?: "emp_default"
        val empName = currentEmp?.fullName ?: "Vendedor"
        val custId = _selectedCustomerId.value
        val cust = customers.value.firstOrNull { it.id == custId }
        val custName = cust?.name ?: "Cliente Mostrador"

        val saleItemsList = mutableListOf<SaleItem>()
        var totalAmount = 0.0

        for ((pId, qty) in currentCart) {
            val prod = allProds[pId] ?: continue
            val unitPrice = _cartCustomPrices.value[pId] ?: prod.salePrice
            val subtotal = unitPrice * qty
            totalAmount += subtotal
            saleItemsList.add(
                SaleItem(
                    id = UUID.randomUUID().toString(),
                    saleId = saleId,
                    productId = prod.id,
                    productName = prod.name,
                    quantity = qty,
                    unitPrice = unitPrice,
                    costPrice = prod.costPrice,
                    subtotal = subtotal
                )
            )
        }

        val paymentStatus = if (paymentMethod == PaymentMethod.CREDITO) "A_CREDITO" else "PAGADO"
        val sale = Sale(
            id = saleId,
            saleNumber = saleNumber,
            employeeId = empId,
            employeeName = empName,
            customerId = custId,
            customerName = custName,
            totalAmount = totalAmount,
            currency = _selectedCurrency.value.name,
            paymentMethod = paymentMethod.name,
            paymentStatus = paymentStatus,
            warehouseId = _activeWarehouseId.value,
            timestamp = now,
            notes = notes
        )

        viewModelScope.launch {
            try {
                repository.processSale(sale, saleItemsList, _currentUser.value)
                _lastCompletedReceipt.value = Pair(sale, saleItemsList)
                if (paymentMethod == PaymentMethod.QR_BANCARIO) {
                    _activeQrSale.value = sale
                }
                clearCart()
                showFeedback("¡Venta $saleNumber completada con éxito!")
                onComplete?.invoke(true)
            } catch (e: Exception) {
                showFeedback("Error al procesar la venta: ${e.message}")
                onComplete?.invoke(false)
            }
        }
    }

    fun confirmQrPaymentSuccess(saleId: String) {
        _activeQrSale.value = null
        showFeedback("Pago con QR bancario verificado")
    }

    fun dismissQrModal() {
        _activeQrSale.value = null
    }

    fun dismissReceiptModal() {
        _lastCompletedReceipt.value = null
    }

    fun placeClientOrder(
        orderedItems: Map<Product, Int>,
        deliveryNotes: String,
        paymentMethod: PaymentMethod
    ) {
        val map = orderedItems.mapKeys { it.key.id }
        placeClientOrderByIds(map, deliveryNotes, paymentMethod)
    }

    fun placeClientOrderByIds(
        orderedItems: Map<String, Int>,
        deliveryNotes: String,
        paymentMethod: PaymentMethod
    ) {
        viewModelScope.launch {
            val allProds = products.value.associateBy { it.id }
            val saleId = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val saleNumber = "PED-" + SimpleDateFormat("yyMMdd-HHmmss", Locale.getDefault()).format(Date(now))
            val client = _currentUser.value

            val items = orderedItems.mapNotNull { (pId, qty) ->
                val prod = allProds[pId] ?: return@mapNotNull null
                SaleItem(
                    id = UUID.randomUUID().toString(),
                    saleId = saleId,
                    productId = prod.id,
                    productName = prod.name,
                    quantity = qty,
                    unitPrice = prod.salePrice,
                    costPrice = prod.costPrice,
                    subtotal = prod.salePrice * qty
                )
            }
            val total = items.sumOf { it.subtotal }
            val sale = Sale(
                id = saleId,
                saleNumber = saleNumber,
                employeeId = client?.id ?: "portal_cliente",
                employeeName = client?.fullName ?: "Portal Cliente",
                customerId = client?.id,
                customerName = client?.fullName ?: "Cliente Web/Móvil",
                totalAmount = total,
                currency = _selectedCurrency.value.name,
                paymentMethod = paymentMethod.name,
                paymentStatus = if (paymentMethod == PaymentMethod.CREDITO) "A_CREDITO" else "PENDIENTE_ENTREGA",
                warehouseId = _activeWarehouseId.value,
                timestamp = now,
                notes = deliveryNotes
            )
            repository.processSale(sale, items, _currentUser.value)
            showFeedback("Pedido #$saleNumber registrado exitosamente")
        }
    }

    fun toggleCashRegister(open: Boolean = !_isCashRegisterOpen.value, startingAmount: Double = _cashRegisterStartingAmount.value) {
        _isCashRegisterOpen.value = open
        _cashRegisterStartingAmount.value = startingAmount
    }

    // --- Inventory Operations ---
    fun saveProduct(product: Product, onSuccess: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.insertProduct(product, _currentUser.value)
            showFeedback("Producto guardado correctamente")
            onSuccess?.invoke()
        }
    }

    fun deleteSingleProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product, _currentUser.value)
            showFeedback("Producto ${product.name} eliminado")
        }
    }

    fun deleteAllProducts() {
        viewModelScope.launch {
            val count = repository.deleteAllProducts(_currentUser.value)
            showFeedback("$count productos eliminados")
        }
    }

    fun deduplicateCatalog() {
        viewModelScope.launch {
            val removed = repository.deduplicateCatalog(_currentUser.value)
            showFeedback("Depuración completada. $removed duplicados eliminados")
        }
    }

    fun deduplicateInventory() = deduplicateCatalog()

    fun restoreDefaultCatalog() {
        viewModelScope.launch {
            val count = repository.restoreDefaultCatalog(_currentUser.value)
            showFeedback("Catálogo base restaurado con $count productos")
        }
    }

    fun adjustProductStock(productId: String, delta: Int, reason: String) {
        viewModelScope.launch {
            repository.adjustProductStock(productId, delta, reason, _currentUser.value)
            showFeedback("Stock ajustado correctamente")
        }
    }

    fun addCategory(cat: String) {
        val current = _customCategories.value.toMutableList()
        if (cat.isNotBlank() && !current.contains(cat.trim())) {
            current.add(cat.trim())
            _customCategories.value = current
        }
    }

    fun deleteCategory(cat: String) {
        val current = _customCategories.value.toMutableList()
        current.remove(cat)
        _customCategories.value = current
    }

    // --- Recount Audit ---
    fun setRecountCount(productId: String, count: Int) {
        val current = _recountInputs.value.toMutableMap()
        current[productId] = count
        _recountInputs.value = current
    }

    fun markRecountConforme(product: Product) {
        setRecountCount(product.id, product.stockQuantity)
    }

    fun markRecountConforme(productId: String) {
        val prod = products.value.firstOrNull { it.id == productId } ?: return
        markRecountConforme(prod)
    }

    fun applyRecountAdjustments() {
        val inputs = _recountInputs.value
        if (inputs.isEmpty()) return
        viewModelScope.launch {
            for ((pId, qty) in inputs) {
                repository.recountStock(pId, qty, _currentUser.value)
            }
            _recountInputs.value = emptyMap()
            showFeedback("Auditoría de conteo aplicada exitosamente")
        }
    }

    // --- Transfers ---
    fun executeStockTransfer(
        sourceWhId: String,
        sourceWhName: String,
        targetWhId: String,
        targetWhName: String,
        itemsToTransfer: List<Pair<Product, Int>>,
        notes: String
    ): Boolean {
        viewModelScope.launch {
            val transferId = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now))
            val transferNumber = "TR-" + SimpleDateFormat("yyMMdd-HHmmss", Locale.getDefault()).format(Date(now))
            val empName = _currentUser.value?.fullName ?: "Administrador"

            val transferItems = itemsToTransfer.map { (prod, qty) ->
                StockTransferItem(
                    id = UUID.randomUUID().toString(),
                    transferId = transferId,
                    productId = prod.id,
                    productName = prod.name,
                    quantity = qty
                )
            }

            val transfer = StockTransfer(
                id = transferId,
                transferNumber = transferNumber,
                timestamp = now,
                dateStr = dateStr,
                sourceWarehouseId = sourceWhId,
                sourceWarehouseName = sourceWhName,
                targetWarehouseId = targetWhId,
                targetWarehouseName = targetWhName,
                itemsCount = transferItems.size,
                totalUnits = transferItems.sumOf { it.quantity },
                performedByEmployeeName = empName,
                notes = notes,
                status = "COMPLETADO"
            )

            repository.executeTransfer(transfer, transferItems, _currentUser.value)
            showFeedback("Traspaso Nº $transferNumber registrado exitosamente hacia $targetWhName")
        }
        return true
    }

    // --- Customers & Debtors ---
    fun saveCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.saveCustomer(customer, _currentUser.value)
            showFeedback("Cliente guardado correctamente")
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            val ok = repository.deleteCustomer(customer, _currentUser.value)
            if (ok) showFeedback("Cliente eliminado") else showFeedback("No se puede eliminar un cliente con deuda pendiente")
        }
    }

    fun recordCustomerPayment(
        customer: Customer,
        amount: Double,
        method: PaymentMethod = PaymentMethod.EFECTIVO,
        notes: String = ""
    ) {
        viewModelScope.launch {
            repository.recordCustomerPayment(
                customer = customer,
                amount = amount,
                paymentMethod = method.name,
                employee = _currentUser.value,
                notes = notes
            )
            showFeedback("Abono de $amount registrado con éxito")
        }
    }

    fun recordCustomerPayment(customerId: String, amount: Double, method: String, notes: String) {
        val cust = customers.value.firstOrNull { it.id == customerId } ?: return
        val payMethod = try { PaymentMethod.valueOf(method) } catch (e: Exception) { PaymentMethod.EFECTIVO }
        recordCustomerPayment(cust, amount, payMethod, notes)
    }

    fun clearCustomerDebt(customerId: String) {
        viewModelScope.launch {
            repository.clearCustomerDebt(customerId, _currentUser.value)
            showFeedback("Deuda condonada/saldada en su totalidad")
        }
    }

    // --- Finances & Expenses ---
    fun recordEnhancedExpense(
        category: ExpenseCategory,
        description: String,
        amount: Double,
        supplierName: String = "",
        receiptVoucher: String = "",
        paymentMethod: String = PaymentMethod.EFECTIVO.name,
        customTimestamp: Long? = null,
        multiProductItems: List<PurchaseOrderItemInput> = emptyList()
    ) {
        viewModelScope.launch {
            val emp = _currentUser.value
            val now = customTimestamp ?: System.currentTimeMillis()
            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now))
            val isPurchase = category == ExpenseCategory.COMPRAS_PRODUCTOS
            val details = if (multiProductItems.isNotEmpty()) {
                multiProductItems.joinToString("; ") { "${it.product.name} (${it.quantity} x ${it.purchasePrice})" }
            } else if (supplierName.isNotBlank()) "Proveedor: $supplierName" else ""

            val expense = Expense(
                id = UUID.randomUUID().toString(),
                category = category.title,
                description = description,
                amount = amount,
                date = dateStr,
                timestamp = now,
                employeeId = emp?.id ?: "emp_default",
                employeeName = emp?.fullName ?: "Administrador",
                isProductPurchase = isPurchase,
                purchaseItemsDetails = details,
                receiptUrl = if (receiptVoucher.isNotBlank()) receiptVoucher else null
            )

            val purchasedPairs = multiProductItems.map { Pair(it.product, it.quantity) }
            repository.insertExpense(expense, purchasedPairs, emp)
            showFeedback("Gasto de $amount registrado exitosamente")
        }
    }

    fun recordEnhancedExpense(
        category: ExpenseCategory,
        description: String,
        amount: Double,
        supplierName: String = "",
        receiptVoucher: String = "",
        paymentMethod: PaymentMethod,
        customTimestamp: Long? = null,
        multiProductItems: List<PurchaseOrderItemInput> = emptyList()
    ) = recordEnhancedExpense(
        category = category,
        description = description,
        amount = amount,
        supplierName = supplierName,
        receiptVoucher = receiptVoucher,
        paymentMethod = paymentMethod.name,
        customTimestamp = customTimestamp,
        multiProductItems = multiProductItems
    )

    fun recordEnhancedExpense(
        category: String,
        description: String,
        amount: Double,
        isPurchase: Boolean = false,
        purchaseDetails: String = "",
        receiptUri: String? = null
    ) {
        val catEnum = ExpenseCategory.entries.firstOrNull { it.title.equals(category, ignoreCase = true) || it.name.equals(category, ignoreCase = true) }
            ?: ExpenseCategory.OTROS_GASTOS
        recordEnhancedExpense(
            category = catEnum,
            description = description,
            amount = amount,
            receiptVoucher = receiptUri ?: "",
            multiProductItems = emptyList()
        )
    }

    fun updateExpense(expense: Expense) {
        viewModelScope.launch {
            repository.updateExpense(expense, _currentUser.value)
            showFeedback("Gasto actualizado")
        }
    }

    fun deleteExpense(expense: Expense) {
        viewModelScope.launch {
            repository.deleteExpense(expense, _currentUser.value)
            showFeedback("Gasto eliminado")
        }
    }

    // --- Employees ---
    fun saveEmployee(employee: Employee) {
        viewModelScope.launch {
            repository.insertEmployee(employee, _currentUser.value)
            showFeedback("Colaborador guardado exitosamente")
        }
    }

    fun deleteEmployee(employee: Employee) {
        viewModelScope.launch {
            repository.deleteEmployee(employee, _currentUser.value)
            showFeedback("Colaborador eliminado")
        }
    }

    fun clockInAttendance(employee: Employee? = null, notes: String = "") {
        val target = employee ?: _currentUser.value ?: return
        viewModelScope.launch {
            repository.clockIn(target, notes)
            showFeedback("Turno iniciado para ${target.fullName}")
        }
    }

    fun clockOutAttendance(employee: Employee? = null, notes: String = "") {
        val target = employee ?: _currentUser.value ?: return
        viewModelScope.launch {
            val att = repository.clockOut(target, notes)
            if (att != null) {
                showFeedback("Turno finalizado: ${att.hoursWorked} hrs trabajadas")
            } else {
                showFeedback("No había turno activo para finalizar")
            }
        }
    }

    // --- Purchase Orders & Stock Intake ---
    fun createPurchaseOrder(
        supplierName: String,
        supplierPhone: String,
        items: List<PurchaseOrderItemInput>,
        notes: String = ""
    ) {
        viewModelScope.launch {
            val orderId = UUID.randomUUID().toString()
            val now = System.currentTimeMillis()
            val orderNumber = "OC-" + SimpleDateFormat("yyMMdd-HHmmss", Locale.getDefault()).format(Date(now))
            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now))
            val empName = _currentUser.value?.fullName ?: "Administrador"

            val orderItems = items.map { input ->
                PurchaseOrderItem(
                    id = UUID.randomUUID().toString(),
                    orderId = orderId,
                    productId = input.product.id,
                    productName = input.product.name,
                    quantity = input.quantity,
                    estimatedUnitCost = input.purchasePrice,
                    subtotal = input.purchasePrice * input.quantity
                )
            }

            val order = PurchaseOrder(
                id = orderId,
                orderNumber = orderNumber,
                supplierName = supplierName,
                supplierPhone = supplierPhone,
                timestamp = now,
                dateStr = dateStr,
                itemsCount = orderItems.size,
                totalUnits = orderItems.sumOf { it.quantity },
                estimatedTotalCost = orderItems.sumOf { it.subtotal },
                status = "PENDIENTE",
                createdByEmployeeName = empName,
                notes = notes
            )

            repository.createPurchaseOrder(order, orderItems, _currentUser.value)
            showFeedback("Orden de compra Nº $orderNumber creada exitosamente")
        }
    }

    fun receivePurchaseOrder(orderId: String, registerExpense: Boolean = true) {
        viewModelScope.launch {
            repository.receivePurchaseOrder(orderId, _currentUser.value, registerExpense)
            showFeedback("Orden de compra recibida y stock actualizado")
        }
    }

    fun createAndReceivePurchase(
        supplierName: String,
        supplierPhone: String,
        items: List<PurchaseOrderItemInput>,
        lotDescription: String = "",
        costMethod: CostUpdateMethod = CostUpdateMethod.WEIGHTED_AVERAGE,
        notes: String = "",
        customTimestamp: Long? = null
    ) {
        viewModelScope.launch {
            val orderId = UUID.randomUUID().toString()
            val now = customTimestamp ?: System.currentTimeMillis()
            val orderNumber = "OC-" + SimpleDateFormat("yyMMdd-HHmmss", Locale.getDefault()).format(Date(now))
            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now))
            val empName = _currentUser.value?.fullName ?: "Administrador"

            val orderItems = items.map { input ->
                PurchaseOrderItem(
                    id = UUID.randomUUID().toString(),
                    orderId = orderId,
                    productId = input.product.id,
                    productName = input.product.name,
                    quantity = input.quantity,
                    estimatedUnitCost = input.purchasePrice,
                    subtotal = input.purchasePrice * input.quantity
                )
            }

            val order = PurchaseOrder(
                id = orderId,
                orderNumber = orderNumber,
                supplierName = supplierName,
                supplierPhone = supplierPhone,
                timestamp = now,
                dateStr = dateStr,
                itemsCount = orderItems.size,
                totalUnits = orderItems.sumOf { it.quantity },
                estimatedTotalCost = orderItems.sumOf { it.subtotal },
                status = "PENDIENTE",
                createdByEmployeeName = empName,
                notes = if (lotDescription.isNotBlank()) "$lotDescription • $notes" else notes
            )

            repository.createPurchaseOrder(order, orderItems, _currentUser.value)
            repository.receivePurchaseOrder(orderId, _currentUser.value, true)
            showFeedback("Compra y recepción directa completada exitosamente")
        }
    }

    fun modifyProductPurchase(
        expenseId: String?,
        productId: String?,
        newQuantity: Int,
        newPurchasePrice: Double,
        newSalePrice: Double,
        newSupplier: String,
        newTimestamp: Long? = null
    ) {
        viewModelScope.launch {
            repository.modifyProductPurchase(
                expenseId = expenseId,
                productId = productId,
                newQuantity = newQuantity,
                newPurchasePrice = newPurchasePrice,
                newSalePrice = newSalePrice,
                newSupplier = newSupplier,
                newTimestamp = newTimestamp,
                user = _currentUser.value
            )
            showFeedback("Compra modificada y stock recalculado")
        }
    }

    fun deletePurchaseOrder(order: PurchaseOrder) {
        viewModelScope.launch {
            repository.deletePurchaseOrder(order, _currentUser.value)
            showFeedback("Orden de compra eliminada")
        }
    }

    // --- Sales History Management ---
    suspend fun getSaleItems(saleId: String): List<SaleItem> {
        return repository.getSaleItems(saleId)
    }

    fun voidSale(saleId: String) {
        viewModelScope.launch {
            repository.voidSale(saleId, _currentUser.value)
            showFeedback("Venta anulada y stock devuelto")
        }
    }

    fun deleteSalePermanent(saleId: String) {
        viewModelScope.launch {
            repository.deleteSalePermanent(saleId, _currentUser.value)
            showFeedback("Registro de venta eliminado definitivamente")
        }
    }

    fun updateSale(sale: Sale, items: List<SaleItem>) {
        viewModelScope.launch {
            repository.updateSale(sale, items, _currentUser.value)
            showFeedback("Venta actualizada")
        }
    }

    // --- PDF & File Export ---
    fun exportSaleReceiptPdf(context: Context, sale: Sale, items: List<SaleItem>): File {
        return PdfReportGenerator.generateSaleReceiptPdf(
            context = context,
            sale = sale,
            items = items,
            settings = settings.value
        )
    }

    fun exportSaleReceiptPdf(sale: Sale): File? {
        val app = getApplication<Application>()
        val items = runCatching {
            kotlinx.coroutines.runBlocking { repository.getSaleItems(sale.id) }
        }.getOrDefault(emptyList())
        return exportSaleReceiptPdf(app, sale, items)
    }

    fun exportCatalogCsv(context: Context? = null): File? {
        val app = context ?: getApplication<Application>()
        return InventoryFileExporter.exportToCsv(
            context = app,
            products = products.value,
            currencySymbol = selectedCurrency.value.symbol
        )
    }

    fun exportCatalogExcel(context: Context? = null): File? {
        val app = context ?: getApplication<Application>()
        return InventoryFileExporter.exportToExcelXml(
            context = app,
            products = products.value,
            currencySymbol = selectedCurrency.value.symbol
        )
    }

    fun saveCsvToUri(context: Context, uri: Uri): Boolean {
        val csv = InventoryFileExporter.generateCsvContent(products.value)
        return InventoryFileExporter.writeContentToUri(context, uri, csv, isUtf8Bom = true)
    }

    fun saveCsvToUri(uri: Uri): Boolean = saveCsvToUri(getApplication(), uri)

    fun saveExcelToUri(context: Context, uri: Uri): Boolean {
        val content = InventoryFileExporter.generateExcelHtmlContent(products.value, selectedCurrency.value.symbol)
        return InventoryFileExporter.writeContentToUri(context, uri, content, isUtf8Bom = true)
    }

    fun saveExcelToUri(uri: Uri): Boolean = saveExcelToUri(getApplication(), uri)

    fun importCatalogCsv(csvText: String, replaceAll: Boolean = false) {
        viewModelScope.launch {
            val res = repository.importCsvProducts(csvText, replaceAll, _currentUser.value)
            showFeedback("Importación finalizada: ${res.totalProcessed} procesados (${res.createdCount} nuevos, ${res.updatedCount} actualizados)")
        }
    }

    fun updateSettings(newSettings: BusinessSettings) {
        viewModelScope.launch {
            repository.updateSettings(newSettings, _currentUser.value)
            showFeedback("Configuración de empresa actualizada")
        }
    }

    fun wipeAllBusinessData(keyword: String): Boolean {
        var success = false
        kotlinx.coroutines.runBlocking {
            success = repository.wipeAllBusinessData(keyword, _currentUser.value)
        }
        if (success) {
            clearCart()
            showFeedback("Todos los datos de la empresa han sido eliminados con éxito")
        } else {
            showFeedback("Clave de seguridad incorrecta")
        }
        return success
    }
}
