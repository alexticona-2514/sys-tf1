package com.example.omnigestion.data.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat

object NotificationHelper {
    const val CHANNEL_SALES = "channel_sales"
    const val CHANNEL_PURCHASES = "channel_purchases"
    const val CHANNEL_STAFF = "channel_staff"
    const val CHANNEL_STOCK_ALERTS = "channel_stock_alerts"

    fun initChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            val salesChannel = NotificationChannel(
                CHANNEL_SALES,
                "Ventas y Cobros SYS-TF",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Notificaciones de cobros y ventas realizadas" }
            
            val purchasesChannel = NotificationChannel(
                CHANNEL_PURCHASES,
                "Compras y Gastos SYS-TF",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Notificaciones de compras de mercadería y gastos" }
            
            val staffChannel = NotificationChannel(
                CHANNEL_STAFF,
                "Personal y Turnos SYS-TF",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Notificaciones de entradas y salidas de colaboradores" }
            
            val stockChannel = NotificationChannel(
                CHANNEL_STOCK_ALERTS,
                "Alertas de Stock e Inventario SYS-TF",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Alertas inmediatas de existencias bajas o agotadas" }
            
            notificationManager.createNotificationChannels(listOf(salesChannel, purchasesChannel, staffChannel, stockChannel))
        }
    }

    private fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun notifyLowStock(context: Context, productName: String, remainingStock: Int, minStock: Int) {
        if (!hasNotificationPermission(context)) return
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notification = NotificationCompat.Builder(context, CHANNEL_STOCK_ALERTS)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("⚠️ Stock Bajo: $productName")
                .setContentText("Quedan solo $remainingStock unidades en almacén (Mínimo requerido: $minStock).")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            notificationManager.notify((productName.hashCode() and 0x7FFFFFFF), notification)
        } catch (_: Exception) {}
    }

    fun notifySale(context: Context, saleNumber: String, amount: Double, customer: String) {
        if (!hasNotificationPermission(context)) return
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notification = NotificationCompat.Builder(context, CHANNEL_SALES)
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle("✅ Nueva Venta Registrada! | $saleNumber")
                .setContentText("Total: Bs ${String.format(java.util.Locale.US, "%.2f", amount)} a $customer")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            notificationManager.notify(System.currentTimeMillis().toInt(), notification)
        } catch (_: Exception) {}
    }

    fun notifyPurchase(context: Context, description: String, amount: Double) {
        if (!hasNotificationPermission(context)) return
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notification = NotificationCompat.Builder(context, CHANNEL_PURCHASES)
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle("Compra / Gasto Registrado")
                .setContentText("$description - Bs ${String.format(java.util.Locale.US, "%.2f", amount)}")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            notificationManager.notify(System.currentTimeMillis().toInt(), notification)
        } catch (_: Exception) {}
    }

    fun notifyStaffShift(context: Context, employeeName: String, isClockIn: Boolean) {
        if (!hasNotificationPermission(context)) return
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notification = NotificationCompat.Builder(context, CHANNEL_STAFF)
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle(if (isClockIn) "Turno Iniciado" else "Turno Concluido")
                .setContentText("$employeeName ha marcado ${if (isClockIn) "su Entrada" else "su Salida"}.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            notificationManager.notify(System.currentTimeMillis().toInt(), notification)
        } catch (_: Exception) {}
    }
}
