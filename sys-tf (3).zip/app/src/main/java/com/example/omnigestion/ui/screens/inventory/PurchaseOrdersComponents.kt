package com.example.omnigestion.ui.screens.inventory

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.omnigestion.data.model.CostUpdateMethod
import com.example.omnigestion.data.model.CurrencyType
import com.example.omnigestion.data.model.Product
import com.example.omnigestion.data.model.PurchaseOrder
import com.example.omnigestion.data.model.PurchaseOrderItemInput
import com.example.omnigestion.data.model.Supplier
import com.example.omnigestion.ui.components.OmniDatePickerDialog
import com.example.omnigestion.ui.components.ProductImageView
import com.example.omnigestion.ui.components.omniTextFieldColors
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MakePurchaseOrderDialog(
    products: List<Product>,
    currency: CurrencyType,
    suppliers: List<Supplier> = emptyList(),
    onDismiss: () -> Unit,
    onCreateOrder: (
        supplierName: String,
        supplierPhone: String,
        items: List<PurchaseOrderItemInput>,
        lotDescription: String,
        costUpdateMethod: CostUpdateMethod,
        notes: String,
        autoReceive: Boolean,
        customTimestamp: Long?
    ) -> Unit
) {
    val context = LocalContext.current
    var supplierName by remember { mutableStateOf("Distribuidora Autorizada") }
    var supplierPhone by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var lotDescription by remember { mutableStateOf("") }
    var costUpdateMethod by remember { mutableStateOf(CostUpdateMethod.WEIGHTED_AVERAGE) }
    var customPurchaseTimestamp by remember { mutableStateOf<Long?>(null) }
    var showPurchaseDatePicker by remember { mutableStateOf(false) }

    var itemQtyTextMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var itemCostTextMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var itemSaleTextMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var selectedProductIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var productSearchQuery by remember { mutableStateOf("") }
    var showProductPicker by remember { mutableStateOf(false) }
    var showBulkTools by remember { mutableStateOf(false) }

    fun autoLoadLowStock() {
        val lowStockItems = products.filter { it.stockQuantity <= it.minStock }
        val newIds = selectedProductIds.toMutableSet()
        val qMap = itemQtyTextMap.toMutableMap()
        val cMap = itemCostTextMap.toMutableMap()
        val sMap = itemSaleTextMap.toMutableMap()
        lowStockItems.forEach { prod ->
            newIds.add(prod.id)
            val needed = max(5, (prod.minStock * 2) - prod.stockQuantity)
            if (!qMap.containsKey(prod.id)) qMap[prod.id] = needed.toString()
            if (!cMap.containsKey(prod.id)) cMap[prod.id] = if (prod.costPrice > 0) String.format(Locale.US, "%.2f", prod.costPrice) else "0.00"
            if (!sMap.containsKey(prod.id)) sMap[prod.id] = if (prod.salePrice > 0) String.format(Locale.US, "%.2f", prod.salePrice) else "0.00"
        }
        selectedProductIds = newIds
        itemQtyTextMap = qMap
        itemCostTextMap = cMap
        itemSaleTextMap = sMap
    }

    fun addOrUpdateProduct(prod: Product, defaultQty: Int = 5) {
        val newIds = selectedProductIds + prod.id
        val curQ = itemQtyTextMap[prod.id]?.toIntOrNull() ?: 0
        val targetQ = if (curQ > 0) curQ + defaultQty else defaultQty
        selectedProductIds = newIds
        itemQtyTextMap = itemQtyTextMap + (prod.id to targetQ.toString())
        if (!itemCostTextMap.containsKey(prod.id)) {
            itemCostTextMap = itemCostTextMap + (prod.id to if (prod.costPrice > 0) String.format(Locale.US, "%.2f", prod.costPrice) else "0.00")
        }
        if (!itemSaleTextMap.containsKey(prod.id)) {
            itemSaleTextMap = itemSaleTextMap + (prod.id to if (prod.salePrice > 0) String.format(Locale.US, "%.2f", prod.salePrice) else "0.00")
        }
    }

    fun removeProduct(prodId: String) {
        selectedProductIds = selectedProductIds - prodId
        itemQtyTextMap = itemQtyTextMap - prodId
        itemCostTextMap = itemCostTextMap - prodId
        itemSaleTextMap = itemSaleTextMap - prodId
    }

    fun adjustQty(prodId: String, delta: Int) {
        val curQ = itemQtyTextMap[prodId]?.toIntOrNull() ?: 1
        val newQ = max(1, curQ + delta)
        itemQtyTextMap = itemQtyTextMap + (prodId to newQ.toString())
    }

    fun applyMarginToAll(marginPercent: Double) {
        val sMap = itemSaleTextMap.toMutableMap()
        for (id in selectedProductIds) {
            val prod = products.firstOrNull { it.id == id }
            val c = itemCostTextMap[id]?.replace(',', '.')?.toDoubleOrNull() ?: (prod?.costPrice ?: 0.0)
            if (c > 0) {
                val newSale = c * (1.0 + marginPercent / 100.0)
                sMap[id] = String.format(Locale.US, "%.2f", newSale)
            }
        }
        itemSaleTextMap = sMap
    }

    fun applyQuantityToAll(fixedQty: Int) {
        val qMap = itemQtyTextMap.toMutableMap()
        for (id in selectedProductIds) {
            qMap[id] = fixedQty.toString()
        }
        itemQtyTextMap = qMap
    }

    fun addQuantityToAll(delta: Int) {
        val qMap = itemQtyTextMap.toMutableMap()
        for (id in selectedProductIds) {
            val cur = qMap[id]?.toIntOrNull() ?: 1
            qMap[id] = max(1, cur + delta).toString()
        }
        itemQtyTextMap = qMap
    }

    val selectedProductsList = remember(selectedProductIds, itemQtyTextMap, itemCostTextMap, itemSaleTextMap, products) {
        selectedProductIds.mapNotNull { prodId ->
            products.firstOrNull { it.id == prodId }?.let { prod ->
                val qty = itemQtyTextMap[prodId]?.toIntOrNull() ?: 1
                val unitCost = itemCostTextMap[prodId]?.replace(',', '.')?.toDoubleOrNull() ?: prod.costPrice
                val unitSale = itemSaleTextMap[prodId]?.replace(',', '.')?.toDoubleOrNull() ?: prod.salePrice
                PurchaseOrderItemInput(prod, qty, unitCost, unitSale)
            }
        }
    }

    val totalCost = remember(selectedProductsList) {
        selectedProductsList.sumOf { it.purchasePrice * it.quantity }
    }
    val totalUnits = remember(selectedProductsList) {
        selectedProductsList.sumOf { it.quantity }
    }

    fun shareViaWhatsApp() {
        val sb = StringBuilder()
        sb.append("📋 *PEDIDO DE MERCADERÍA - SYS-TF*\n")
        sb.append("🏢 Proveedor: $supplierName\n")
        if (supplierPhone.isNotBlank()) sb.append("📞 Teléfono: $supplierPhone\n")
        sb.append("------------------------------------\n")
        selectedProductsList.forEach { item ->
            sb.append("📦 *${item.quantity}x* ${item.product.name} (Código: ${item.product.sku})\n")
            sb.append("   P. Compra: ${currency.symbol} ${String.format(Locale.US, "%.2f", item.purchasePrice)} | P. Venta: ${currency.symbol} ${String.format(Locale.US, "%.2f", item.salePrice)} | Subtotal: ${currency.symbol} ${String.format(Locale.US, "%.2f", item.purchasePrice * item.quantity)}\n")
        }
        sb.append("------------------------------------\n")
        sb.append("📊 Total Unidades: $totalUnits\n")
        sb.append("💰 Monto Total Estimado: ${currency.symbol} ${String.format(Locale.US, "%.2f", totalCost)}\n")
        if (lotDescription.isNotBlank()) sb.append("🏷️ Lote: $lotDescription\n")
        if (notes.isNotBlank()) sb.append("📝 Notas: $notes\n")
        sb.append("\n_Generado automáticamente desde Sistema SYS-TF_")

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, sb.toString())
        }
        context.startActivity(Intent.createChooser(intent, "Enviar Pedido de Mercadería"))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AddShoppingCart, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Nuevo Pedido a Proveedor", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("Reabastecimiento de inventario SYS-TF", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Cerrar")
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Datos del Proveedor", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                OutlinedTextField(
                                    value = supplierName,
                                    onValueChange = { supplierName = it },
                                    label = { Text("Nombre del Proveedor / Distribuidor") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = omniTextFieldColors()
                                )
                                OutlinedTextField(
                                    value = supplierPhone,
                                    onValueChange = { supplierPhone = it },
                                    label = { Text("Teléfono / WhatsApp de contacto") },
                                    placeholder = { Text("ej. 70011223") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = omniTextFieldColors()
                                )
                                OutlinedTextField(
                                    value = notes,
                                    onValueChange = { notes = it },
                                    label = { Text("Notas de Entrega / Condiciones") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = omniTextFieldColors()
                                )
                                Spacer(modifier = Modifier.height(4.dp))

                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f)),
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(28.dp)
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(MaterialTheme.colorScheme.primary),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        Icons.Default.CalendarMonth,
                                                        contentDescription = null,
                                                        tint = Color.White,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    "FECHA DE LA COMPRA / PEDIDO",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (customPurchaseTimestamp != null) AmberContainer else EmeraldContainer
                                            ) {
                                                Text(
                                                    text = if (customPurchaseTimestamp != null) "Personalizada" else "Hoy",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (customPurchaseTimestamp != null) AmberAccent else EmeraldSuccess,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.surface,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    val displayTime = customPurchaseTimestamp ?: System.currentTimeMillis()
                                                    Text(
                                                        text = SimpleDateFormat("EEEE, dd 'de' MMMM 'de' yyyy", Locale("es", "ES")).format(Date(displayTime)).replaceFirstChar { it.uppercase() },
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Text(
                                                        text = "Hora: " + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(displayTime)),
                                                        fontSize = 10.5.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                    if (customPurchaseTimestamp != null) {
                                                        OutlinedButton(
                                                            onClick = { customPurchaseTimestamp = null },
                                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                            shape = RoundedCornerShape(8.dp),
                                                            modifier = Modifier.height(32.dp)
                                                        ) {
                                                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.error)
                                                            Spacer(modifier = Modifier.width(3.dp))
                                                            Text("Hoy", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                                        }
                                                    }
                                                    Button(
                                                        onClick = { showPurchaseDatePicker = true },
                                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                                        shape = RoundedCornerShape(8.dp),
                                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                                        modifier = Modifier.height(32.dp)
                                                    ) {
                                                        Icon(Icons.Default.EditCalendar, contentDescription = null, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Cambiar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        val lowStockCount = products.count { it.stockQuantity <= it.minStock }
                        Surface(
                            onClick = { autoLoadLowStock() },
                            shape = RoundedCornerShape(12.dp),
                            color = AmberContainer,
                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberAccent.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = AmberAccent)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("⚡ Cargar $lowStockCount productos con stock bajo o agotados", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AmberAccent)
                                    Text("Calcula automáticamente unidades recomendadas de reposición", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Productos en el Pedido (${selectedProductsList.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                            TextButton(onClick = { showProductPicker = !showProductPicker }) {
                                Icon(if (showProductPicker) Icons.Default.ExpandLess else Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (showProductPicker) "Ocultar Catálogo" else "Agregar Productos", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (selectedProductsList.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.ProductionQuantityLimits, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("No has seleccionado productos aún.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    } else {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Modificar Datos de los ${selectedProductsList.size} Productos", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                        TextButton(
                                            onClick = { showBulkTools = !showBulkTools },
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(if (showBulkTools) "Ocultar" else "Ajustar en Lote", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Icon(if (showBulkTools) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    if (showBulkTools) {
                                        HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                                        Text("Margen de Venta para todos (sobre el Costo):", fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            listOf(20.0, 30.0, 40.0, 50.0).forEach { pct ->
                                                Surface(
                                                    onClick = { applyMarginToAll(pct) },
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = EmeraldContainer,
                                                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f))
                                                ) {
                                                    Text("+${pct.toInt()}% margen", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text("Cantidad de reposición para todos:", fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Surface(
                                                onClick = { addQuantityToAll(5) },
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                            ) {
                                                Text("+5 a todos", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                                            }
                                            Surface(
                                                onClick = { addQuantityToAll(10) },
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                            ) {
                                                Text("+10 a todos", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                                            }
                                            Surface(
                                                onClick = { applyQuantityToAll(10) },
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                            ) {
                                                Text("Fijar 10", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                                            }
                                            Surface(
                                                onClick = { applyQuantityToAll(20) },
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                            ) {
                                                Text("Fijar 20", fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        items(selectedProductsList, key = { it.product.id }) { item ->
                            val prod = item.product
                            val pId = prod.id
                            val qty = item.quantity
                            val pCost = item.purchasePrice
                            val pSale = item.salePrice
                            val rawCostStr = itemCostTextMap[pId] ?: String.format(Locale.US, "%.2f", pCost)
                            val rawSaleStr = itemSaleTextMap[pId] ?: String.format(Locale.US, "%.2f", pSale)
                            val rawQtyStr = itemQtyTextMap[pId] ?: qty.toString()

                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(12.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        ProductImageView(
                                            imageUrl = prod.imageUrl,
                                            contentDescription = prod.name,
                                            modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(prod.name, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                                            Text("Código: ${prod.sku} • Stock actual: ${prod.stockQuantity} unid.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        IconButton(
                                            onClick = { removeProduct(pId) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Eliminar", tint = RoseDanger, modifier = Modifier.size(18.dp))
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1.1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(
                                                    onClick = { adjustQty(pId, -1) },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Default.Remove, contentDescription = "Menos", modifier = Modifier.size(14.dp))
                                                }
                                                OutlinedTextField(
                                                    value = rawQtyStr,
                                                    onValueChange = { newQ ->
                                                        if (newQ.isEmpty() || newQ.all { it.isDigit() }) {
                                                            itemQtyTextMap = itemQtyTextMap + (pId to newQ)
                                                        }
                                                    },
                                                    label = { Text("Cant.", fontSize = 9.sp) },
                                                    singleLine = true,
                                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                    modifier = Modifier.weight(1f),
                                                    colors = omniTextFieldColors()
                                                )
                                                IconButton(
                                                    onClick = { adjustQty(pId, 1) },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Default.Add, contentDescription = "Más", modifier = Modifier.size(14.dp))
                                                }
                                            }
                                        }

                                        OutlinedTextField(
                                            value = rawCostStr,
                                            onValueChange = { newC ->
                                                val sanitized = newC.replace(',', '.')
                                                if (sanitized.isEmpty() || (sanitized.count { it == '.' } <= 1 && sanitized.all { it.isDigit() || it == '.' })) {
                                                    itemCostTextMap = itemCostTextMap + (pId to newC)
                                                }
                                            },
                                            label = { Text("P. Compra", fontSize = 9.sp) },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                            modifier = Modifier.weight(1f),
                                            colors = omniTextFieldColors()
                                        )

                                        OutlinedTextField(
                                            value = rawSaleStr,
                                            onValueChange = { newS ->
                                                val sanitized = newS.replace(',', '.')
                                                if (sanitized.isEmpty() || (sanitized.count { it == '.' } <= 1 && sanitized.all { it.isDigit() || it == '.' })) {
                                                    itemSaleTextMap = itemSaleTextMap + (pId to newS)
                                                }
                                            },
                                            label = { Text("P. Venta", fontSize = 9.sp) },
                                            singleLine = true,
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                            modifier = Modifier.weight(1f),
                                            colors = omniTextFieldColors()
                                        )
                                    }

                                    val margin = if (pSale > 0 && pCost > 0) ((pSale - pCost) / pSale) * 100.0 else 0.0
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                onClick = { adjustQty(pId, 5) },
                                                shape = RoundedCornerShape(4.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant
                                            ) {
                                                Text("+5 un.", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                            }
                                            Surface(
                                                onClick = {
                                                    val c = rawCostStr.replace(',', '.').toDoubleOrNull() ?: pCost
                                                    if (c > 0) {
                                                        itemSaleTextMap = itemSaleTextMap + (pId to String.format(Locale.US, "%.2f", c * 1.30))
                                                    }
                                                },
                                                shape = RoundedCornerShape(4.dp),
                                                color = EmeraldContainer
                                            ) {
                                                Text("+30% venta", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                            }
                                        }
                                        Text(
                                            text = "Margen: ${String.format(Locale.US, "%.1f", margin)}% • Subtotal: ${currency.symbol} ${String.format(Locale.US, "%.2f", pCost * qty)}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (showProductPicker) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Catálogo: Buscar y Agregar Productos", fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = productSearchQuery,
                                onValueChange = { productSearchQuery = it },
                                placeholder = { Text("Buscar artículo para agregar...") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                colors = omniTextFieldColors()
                            )
                        }

                        val availableToAdd = products.filter {
                            it.name.contains(productSearchQuery, ignoreCase = true) || it.sku.contains(productSearchQuery, ignoreCase = true) || it.category.contains(productSearchQuery, ignoreCase = true)
                        }

                        items(availableToAdd.take(25), key = { it.id }) { p ->
                            val currentQty = itemQtyTextMap[p.id]?.toIntOrNull() ?: 0
                            val isSelected = selectedProductIds.contains(p.id) && currentQty > 0
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ProductImageView(
                                        imageUrl = p.imageUrl,
                                        contentDescription = p.name,
                                        modifier = Modifier.size(54.dp).clip(RoundedCornerShape(8.dp))
                                    )
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(p.name, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Surface(shape = RoundedCornerShape(4.dp), color = MaterialTheme.colorScheme.surface) {
                                                Text("SKU: ${p.sku}", fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                            }
                                            Text(
                                                text = if (p.stockQuantity <= p.minStock) "Stock: ${p.stockQuantity} (Bajo)" else "Stock: ${p.stockQuantity}",
                                                fontSize = 9.5.sp,
                                                color = if (p.stockQuantity <= p.minStock) AmberAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontWeight = if (p.stockQuantity <= p.minStock) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("Costo: ${currency.symbol} ${String.format(Locale.US, "%.2f", p.costPrice)}", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            Text("•", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text("Venta: ${currency.symbol} ${String.format(Locale.US, "%.2f", p.salePrice)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (isSelected) {
                                            IconButton(
                                                onClick = {
                                                    if (currentQty <= 1) removeProduct(p.id) else adjustQty(p.id, -1)
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Menos", tint = RoseDanger, modifier = Modifier.size(20.dp))
                                            }
                                            Text("$currentQty", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 4.dp))
                                        }
                                        IconButton(
                                            onClick = {
                                                addOrUpdateProduct(p, if (isSelected) 5 else 1)
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                if (isSelected) Icons.Default.AddCircleOutline else Icons.Default.AddShoppingCart,
                                                contentDescription = "Más",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = lotDescription,
                            onValueChange = { lotDescription = it },
                            label = { Text("Características específicas del lote / producto (Opcional)") },
                            placeholder = { Text("ej. Lote #2026-A • Vencimiento: Dic/2028") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = omniTextFieldColors()
                        )
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = NavyDark),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Total del Pedido (Gasto Automático)", fontSize = 11.sp, color = SlateTextMuted)
                                    Text(
                                        text = "${currency.symbol} ${String.format(Locale.US, "%,.2f", totalCost)}",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF38BDF8)
                                    )
                                }
                                Text(
                                    text = "$totalUnits unidades ($totalUnits items)",
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { shareViaWhatsApp() },
                        enabled = selectedProductsList.isNotEmpty(),
                        modifier = Modifier.weight(1f).height(44.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp), tint = EmeraldSuccess)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldSuccess)
                    }
                    Button(
                        onClick = {
                            onCreateOrder(supplierName, supplierPhone, selectedProductsList, lotDescription, costUpdateMethod, notes, false, customPurchaseTimestamp)
                            onDismiss()
                        },
                        enabled = selectedProductsList.isNotEmpty(),
                        modifier = Modifier.weight(1.2f).height(44.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Guardar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = {
                            onCreateOrder(supplierName, supplierPhone, selectedProductsList, lotDescription, costUpdateMethod, notes, true, customPurchaseTimestamp)
                            onDismiss()
                        },
                        enabled = selectedProductsList.isNotEmpty(),
                        modifier = Modifier.weight(1.3f).height(44.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Recibir Stock", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showPurchaseDatePicker) {
        OmniDatePickerDialog(
            initialDateMillis = customPurchaseTimestamp ?: System.currentTimeMillis(),
            onDateSelected = { selectedTime ->
                customPurchaseTimestamp = selectedTime
            },
            onDismiss = { showPurchaseDatePicker = false }
        )
    }
}

@Composable
fun ViewPurchaseOrdersDialog(
    orders: List<PurchaseOrder>,
    currency: CurrencyType,
    onDismiss: () -> Unit,
    onReceiveOrder: (orderId: String) -> Unit,
    onDeleteOrder: (order: PurchaseOrder) -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Historial de Pedidos (${orders.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            if (orders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No hay pedidos de stock registrados.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(orders) { o ->
                        val isReceived = o.status == "RECIBIDO"
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(o.orderNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (isReceived) EmeraldContainer else AmberContainer
                                        ) {
                                            Text(
                                                text = o.status,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isReceived) EmeraldSuccess else AmberAccent,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(o.dateStr, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("Proveedor: ${o.supplierName}", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                                Text("Artículos: ${o.itemsCount} tipos • ${o.totalUnits} unidades en total", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    "Costo Total: ${currency.symbol} ${String.format(Locale.US, "%,.2f", o.estimatedTotalCost)}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = EmeraldSuccess
                                )
                                HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (!isReceived) {
                                        Button(
                                            onClick = { onReceiveOrder(o.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Recibir en Stock", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            val text = "Pedido #${o.orderNumber} - Proveedor: ${o.supplierName} - Total: ${currency.symbol} ${String.format(Locale.US, "%.2f", o.estimatedTotalCost)}"
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, text)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Compartir Pedido"))
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Compartir", tint = BlueAccent, modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(
                                        onClick = { onDeleteOrder(o) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = RoseDanger, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
    )
}
