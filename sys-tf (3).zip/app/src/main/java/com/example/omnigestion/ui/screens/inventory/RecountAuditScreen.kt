package com.example.omnigestion.ui.screens.inventory

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.Product
import com.example.omnigestion.ui.components.ProductImageView
import com.example.omnigestion.ui.components.omniTextFieldColors
import com.example.omnigestion.ui.viewmodel.OmniViewModel
import com.example.ui.theme.*

enum class RecountFilter {
    ALL,
    WITH_DIFF,
    CONFORME
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecountAuditScreen(viewModel: OmniViewModel) {
    val products by viewModel.products.collectAsState()
    val recountInputs by viewModel.recountInputs.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var activeFilter by remember { mutableStateOf(RecountFilter.ALL) }

    val diffCount = remember(products, recountInputs) {
        products.count { p ->
            val counted = recountInputs[p.id] ?: p.stockQuantity
            counted != p.stockQuantity
        }
    }
    val conformeCount = remember(products, recountInputs) {
        products.count { p ->
            val counted = recountInputs[p.id] ?: p.stockQuantity
            counted == p.stockQuantity
        }
    }

    val filteredProducts = remember(products, searchQuery, activeFilter, recountInputs) {
        products.filter { p ->
            val matchesSearch = searchQuery.isBlank() ||
                    p.name.contains(searchQuery, ignoreCase = true) ||
                    p.sku.contains(searchQuery, ignoreCase = true) ||
                    p.category.contains(searchQuery, ignoreCase = true)
            val counted = recountInputs[p.id] ?: p.stockQuantity
            val matchesFilter = when (activeFilter) {
                RecountFilter.ALL -> true
                RecountFilter.WITH_DIFF -> counted != p.stockQuantity
                RecountFilter.CONFORME -> counted == p.stockQuantity
            }
            matchesSearch && matchesFilter
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F8FC))
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E4EC)),
            shadowElevation = 1.dp
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.FactCheck, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Auditoría y Conteo Físico", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("Verifica y ajusta el stock real en almacén", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Button(
                        onClick = { viewModel.applyRecountAdjustments() },
                        enabled = recountInputs.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Guardar Ajustes", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar por nombre, código o categoría...", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Limpiar", modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine = true,
            colors = omniTextFieldColors(),
            shape = RoundedCornerShape(12.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                FilterChip(
                    selected = activeFilter == RecountFilter.ALL,
                    onClick = { activeFilter = RecountFilter.ALL },
                    label = { Text("Todos (${products.size})", fontSize = 11.5.sp) },
                    shape = RoundedCornerShape(8.dp)
                )
            }
            item {
                FilterChip(
                    selected = activeFilter == RecountFilter.WITH_DIFF,
                    onClick = { activeFilter = RecountFilter.WITH_DIFF },
                    label = { Text("Con Diferencias ($diffCount)", fontSize = 11.5.sp) },
                    leadingIcon = if (diffCount > 0) {
                        { Icon(Icons.Default.Warning, contentDescription = null, tint = RoseDanger, modifier = Modifier.size(14.dp)) }
                    } else null,
                    shape = RoundedCornerShape(8.dp)
                )
            }
            item {
                FilterChip(
                    selected = activeFilter == RecountFilter.CONFORME,
                    onClick = { activeFilter = RecountFilter.CONFORME },
                    label = { Text("Conformes ($conformeCount)", fontSize = 11.5.sp) },
                    leadingIcon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp)) },
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))

        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Inventory, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No se encontraron artículos para el filtro actual.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 70.dp)
            ) {
                items(filteredProducts, key = { it.id }) { product ->
                    val countedQty = recountInputs[product.id] ?: product.stockQuantity
                    val diff = countedQty - product.stockQuantity
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(
                            1.2.dp,
                            when {
                                diff > 0 -> Color(0xFF38BDF8)
                                diff < 0 -> RoseDanger.copy(alpha = 0.6f)
                                else -> Color(0xFFE2E4EC)
                            }
                        ),
                        shadowElevation = 1.dp
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E4EC)),
                                    modifier = Modifier.size(60.dp)
                                ) {
                                    ProductImageView(
                                        imageUrl = product.imageUrl,
                                        contentDescription = product.name,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = product.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        lineHeight = 20.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(5.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(5.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = "Código: ${product.sku}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(5.dp),
                                            color = PalettePurple.copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = product.category,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = PalettePurple,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = Color(0xFFF1F3F9))
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFFF8FAFC),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("Stock en Sistema", fontSize = 10.5.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Medium)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text("${product.stockQuantity} unid.", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                                    }
                                }

                                Surface(
                                    modifier = Modifier.weight(1.5f),
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                                    border = androidx.compose.foundation.BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("Físico Contado", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            IconButton(
                                                onClick = { viewModel.setRecountCount(product.id, maxOf(0, countedQty - 1)) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.RemoveCircle, contentDescription = "Restar 1", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                                            }
                                            var textValue by remember(countedQty) { mutableStateOf("$countedQty") }
                                            OutlinedTextField(
                                                value = textValue,
                                                onValueChange = {
                                                    textValue = it
                                                    val parsed = it.toIntOrNull()
                                                    if (parsed != null && parsed >= 0) {
                                                        viewModel.setRecountCount(product.id, parsed)
                                                    }
                                                },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                textStyle = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 16.sp),
                                                modifier = Modifier.width(62.dp).height(46.dp),
                                                colors = omniTextFieldColors()
                                            )
                                            IconButton(
                                                onClick = { viewModel.setRecountCount(product.id, countedQty + 1) },
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.AddCircle, contentDescription = "Sumar 1", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = when {
                                        diff == 0 -> EmeraldContainer
                                        diff > 0 -> Color(0xFFE0F2FE)
                                        else -> RoseContainer
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = when {
                                                diff == 0 -> Icons.Default.CheckCircle
                                                diff > 0 -> Icons.Default.ArrowUpward
                                                else -> Icons.Default.ArrowDownward
                                            },
                                            contentDescription = null,
                                            tint = when {
                                                diff == 0 -> EmeraldSuccess
                                                diff > 0 -> Color(0xFF0284C7)
                                                else -> RoseDanger
                                            },
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = when {
                                                diff == 0 -> "Conforme (Sin diferencia)"
                                                diff > 0 -> "Sobrante: +$diff unidades"
                                                else -> "Faltante: $diff unidades"
                                            },
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when {
                                                diff == 0 -> EmeraldSuccess
                                                diff > 0 -> Color(0xFF0284C7)
                                                else -> RoseDanger
                                            }
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = { viewModel.markRecountConforme(product) },
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = if (diff == 0) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Marcar Conforme", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
