package com.example.omnigestion.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MoreMenuModal(
    onDismiss: () -> Unit,
    onNavigate: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Módulos de Gestión SYS-TF",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Selecciona una opción del sistema:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                NavigationMenuItem(
                    icon = Icons.Default.People,
                    title = "Personal y Asistencias",
                    subtitle = "Control de empleados, sueldos y turnos"
                ) {
                    onDismiss()
                    onNavigate("employees")
                }
                NavigationMenuItem(
                    icon = Icons.Default.ReceiptLong,
                    title = "Historial de Ventas",
                    subtitle = "Facturación, reimpresión y anulación"
                ) {
                    onDismiss()
                    onNavigate("sales_history")
                }
                NavigationMenuItem(
                    icon = Icons.Default.SwapHoriz,
                    title = "Traspasos entre Sucursales",
                    subtitle = "Envío y recepción de stock con PDF"
                ) {
                    onDismiss()
                    onNavigate("transfers")
                }
                NavigationMenuItem(
                    icon = Icons.Default.FactCheck,
                    title = "Conteo Físico de Inventario",
                    subtitle = "Auditoría física y ajuste de stock"
                ) {
                    onDismiss()
                    onNavigate("recount_audit")
                }
                NavigationMenuItem(
                    icon = Icons.Default.ContactPhone,
                    title = "Cuentas de Clientes",
                    subtitle = "Directorio y datos de clientes, teléfonos, direcciones y deudas"
                ) {
                    onDismiss()
                    onNavigate("debtors")
                }
                NavigationMenuItem(
                    icon = Icons.Default.Storefront,
                    title = "Proveedores de Mercadería",
                    subtitle = "Directorio de proveedores, teléfonos y compras"
                ) {
                    onDismiss()
                    onNavigate("finances")
                }
                NavigationMenuItem(
                    icon = Icons.Default.CreditScore,
                    title = "Cuentas por Cobrar (Deudas)",
                    subtitle = "Saldos pendientes de clientes y pagos"
                ) {
                    onDismiss()
                    onNavigate("debtors")
                }
                NavigationMenuItem(
                    icon = Icons.Default.Assessment,
                    title = "Reportes Ejecutivos",
                    subtitle = "Previsualización y descarga en PDF"
                ) {
                    onDismiss()
                    onNavigate("reports")
                }
                NavigationMenuItem(
                    icon = Icons.Default.HistoryEdu,
                    title = "Registro de Auditoría",
                    subtitle = "Trazabilidad de cambios y correcciones"
                ) {
                    onDismiss()
                    onNavigate("audit_logs")
                }
                NavigationMenuItem(
                    icon = Icons.Default.Settings,
                    title = "Configuración del Negocio",
                    subtitle = "Logo, datos fiscales, QR y cuentas"
                ) {
                    onDismiss()
                    onNavigate("settings")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cerrar", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun NavigationMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
