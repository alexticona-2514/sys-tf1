package com.example.omnigestion.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.BusinessSettings
import com.example.omnigestion.data.model.Employee
import com.example.omnigestion.ui.viewmodel.MainViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsState()
    val employees by viewModel.employees.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var businessName by remember(settings) { mutableStateOf(settings.businessName) }
    var taxId by remember(settings) { mutableStateOf(settings.taxId) }
    var phone by remember(settings) { mutableStateOf(settings.phone) }
    var address by remember(settings) { mutableStateOf(settings.address) }
    var slogan by remember(settings) { mutableStateOf(settings.slogan) }
    var currencySymbol by remember(settings) { mutableStateOf(settings.currencySymbol) }
    var qrHolderName by remember(settings) { mutableStateOf(settings.qrHolderName) }
    var bankAccount by remember(settings) { mutableStateOf(settings.bankAccount) }

    var isSavedSnackbar by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Configuración y Empresa", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // App Branding & Logo
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "SYS\nTF",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.primary,
                                lineHeight = 14.sp
                            )
                        }

                        Spacer(Modifier.width(16.dp))

                        Column {
                            Text(
                                text = "SYS-TF",
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White
                            )
                            Text(
                                text = "Sistema de Gestión, Inventario y POS",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                            Text(
                                text = "Propietario: Alex Ticona Flores",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }

            // Active User / Switch Role
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Usuario Activo en Sesión", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(EmeraldContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldSuccess)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(currentUser.name, fontWeight = FontWeight.SemiBold)
                                    Text("Rol: ${currentUser.role}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }

                        HorizontalDivider()

                        Text("Cambiar de Usuario:", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            employees.forEach { emp ->
                                FilterChip(
                                    selected = currentUser.id == emp.id,
                                    onClick = { viewModel.switchUser(emp) },
                                    label = { Text("${emp.name} (${emp.role})", fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // Datos de la Empresa
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Datos de la Empresa / Negocio", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                        OutlinedTextField(value = businessName, onValueChange = { businessName = it }, label = { Text("Nombre Comercial") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = slogan, onValueChange = { slogan = it }, label = { Text("Eslogan / Subtítulo") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = taxId, onValueChange = { taxId = it }, label = { Text("NIT / Identificación Fiscal") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Teléfono de Contacto") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Dirección del Local") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = currencySymbol, onValueChange = { currencySymbol = it }, label = { Text("Símbolo de Moneda (Ej: Bs, $, S/)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                        Text("Datos de Pago por Transferencia / QR:", style = MaterialTheme.typography.labelMedium)
                        OutlinedTextField(value = qrHolderName, onValueChange = { qrHolderName = it }, label = { Text("Titular de la Cuenta QR") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = bankAccount, onValueChange = { bankAccount = it }, label = { Text("Nº Cuenta Bancaria") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                        Button(
                            onClick = {
                                viewModel.updateSettings(
                                    settings.copy(
                                        businessName = businessName,
                                        slogan = slogan,
                                        taxId = taxId,
                                        phone = phone,
                                        address = address,
                                        currencySymbol = currencySymbol,
                                        qrHolderName = qrHolderName,
                                        bankAccount = bankAccount
                                    )
                                )
                                isSavedSnackbar = true
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_settings_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Guardar Cambios de Configuración")
                        }

                        if (isSavedSnackbar) {
                            Surface(
                                color = EmeraldContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "✓ Configuración guardada correctamente.",
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
