package com.example.omnigestion.ui.screens.inventory

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.omnigestion.data.model.Product
import com.example.omnigestion.data.model.StockTransferItem
import com.example.omnigestion.data.pdf.PdfReportGenerator
import com.example.omnigestion.ui.components.omniTextFieldColors
import com.example.omnigestion.ui.viewmodel.OmniViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StockTransferScreen(viewModel: OmniViewModel) {
    val context = LocalContext.current
    val warehouses by viewModel.warehouses.collectAsState()
    val products by viewModel.products.collectAsState()
    val transfers by viewModel.transfers.collectAsState()
    val settings by viewModel.settings.collectAsState()

    var showNewTransferDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(14.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = TealSecondary, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Traslados de Mercadería", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("Transfiere stock entre almacenes y genera actas PDF.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Button(
                    onClick = { showNewTransferDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = TealSecondary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Nuevo", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(modifier = Modifier.height(14.dp))

        Text("Historial de Traspasos Registrados:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(8.dp))

        if (transfers.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.LocalShipping, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Aún no se han registrado traspasos.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 60.dp)
            ) {
                items(transfers, key = { it.id }) { tr ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(tr.transferNumber, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                                Surface(shape = RoundedCornerShape(6.dp), color = EmeraldContainer) {
                                    Text(
                                        text = tr.status,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSuccess,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("De: ${tr.sourceWarehouseName} → A: ${tr.targetWarehouseName}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            Text("Fecha: ${tr.dateStr} • Responsable: ${tr.performedByEmployeeName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Total: ${tr.totalUnits} unidades (${tr.itemsCount} productos)", fontSize = 12.sp, color = EmeraldSuccess, fontWeight = FontWeight.Bold)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                OutlinedButton(
                                    onClick = {
                                        val dummyItems = listOf(StockTransferItem(transferId = tr.id, productId = "p", productName = "Mercadería Transferida", quantity = tr.totalUnits))
                                        PdfReportGenerator.generateTransferReportPdf(context, settings, tr, dummyItems)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Descargar Acta PDF", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewTransferDialog) {
        var sourceWhId by remember { mutableStateOf(warehouses.firstOrNull()?.id ?: "wh_central") }
        var targetWhId by remember { mutableStateOf(warehouses.getOrNull(1)?.id ?: "wh_sucursal1") }
        var selectedProduct by remember { mutableStateOf<Product?>(products.firstOrNull()) }
        var transferQty by remember { mutableStateOf("1") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNewTransferDialog = false },
            title = { Text("Registrar Traspaso de Stock", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Selecciona almacén origen y destino:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    var expSource by remember { mutableStateOf(false) }
                    val sourceWh = warehouses.firstOrNull { it.id == sourceWhId }
                    Surface(
                        onClick = { expSource = true },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Origen: ${sourceWh?.name ?: "Seleccionar"}", fontSize = 13.sp)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                    }
                    DropdownMenu(expanded = expSource, onDismissRequest = { expSource = false }) {
                        warehouses.forEach { wh ->
                            DropdownMenuItem(text = { Text(wh.name) }, onClick = { sourceWhId = wh.id; expSource = false })
                        }
                    }

                    var expTarget by remember { mutableStateOf(false) }
                    val targetWh = warehouses.firstOrNull { it.id == targetWhId }
                    Surface(
                        onClick = { expTarget = true },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Destino: ${targetWh?.name ?: "Seleccionar"}", fontSize = 13.sp)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                    }
                    DropdownMenu(expanded = expTarget, onDismissRequest = { expTarget = false }) {
                        warehouses.forEach { wh ->
                            DropdownMenuItem(text = { Text(wh.name) }, onClick = { targetWhId = wh.id; expTarget = false })
                        }
                    }

                    var expProd by remember { mutableStateOf(false) }
                    Surface(
                        onClick = { expProd = true },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(selectedProduct?.name?.take(25) ?: "Seleccionar Producto", fontSize = 13.sp)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                    }
                    DropdownMenu(expanded = expProd, onDismissRequest = { expProd = false }) {
                        products.forEach { prod ->
                            DropdownMenuItem(
                                text = { Text("${prod.name} (Stock: ${prod.stockQuantity})") },
                                onClick = { selectedProduct = prod; expProd = false }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = transferQty,
                        onValueChange = { transferQty = it },
                        label = { Text("Cantidad a Traspasar") },
                        singleLine = true,
                        colors = omniTextFieldColors()
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Motivo / Observaciones") },
                        singleLine = true,
                        colors = omniTextFieldColors()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val prod = selectedProduct
                        val qty = transferQty.toIntOrNull() ?: 1
                        if (prod != null && qty > 0) {
                            val ok = viewModel.executeStockTransfer(
                                sourceWhId = sourceWhId,
                                sourceWhName = warehouses.firstOrNull { it.id == sourceWhId }?.name ?: "Origen",
                                targetWhId = targetWhId,
                                targetWhName = warehouses.firstOrNull { it.id == targetWhId }?.name ?: "Destino",
                                itemsToTransfer = listOf(Pair(prod, qty)),
                                notes = notes
                            )
                            if (ok) showNewTransferDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TealSecondary)
                ) {
                    Text("Confirmar Traspaso")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewTransferDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
