package com.example.omnigestion.data.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.omnigestion.data.model.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfReportGenerator {
    /**
     * Decodifica imágenes optimizadas en tamaño y formato de color (RGB_565)
     * para evitar OutOfMemoryError y cierres inesperados al generar PDFs.
     */
    private fun decodeSampledBitmap(
        context: Context,
        imagePathOrUri: String,
        reqWidth: Int,
        reqHeight: Int
    ): Bitmap? {
        try {
            if (imagePathOrUri.isBlank()) return null
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            var hasBounds = false
            if (imagePathOrUri.startsWith("/")) {
                val f = File(imagePathOrUri)
                if (f.exists()) {
                    BitmapFactory.decodeFile(f.absolutePath, options)
                    hasBounds = true
                }
            } else if (imagePathOrUri.startsWith("content://") || imagePathOrUri.startsWith("file://")) {
                context.contentResolver.openInputStream(Uri.parse(imagePathOrUri))?.use { input ->
                    BitmapFactory.decodeStream(input, null, options)
                    hasBounds = true
                }
            }
            if (!hasBounds || options.outWidth <= 0 || options.outHeight <= 0) return null
            var inSampleSize = 1
            val halfHeight = options.outHeight / 2
            val halfWidth = options.outWidth / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply {
                this.inSampleSize = maxOf(1, inSampleSize)
                this.inPreferredConfig = Bitmap.Config.RGB_565
                this.inDither = true
            }
            if (imagePathOrUri.startsWith("/")) {
                val f = File(imagePathOrUri)
                if (f.exists()) {
                    return BitmapFactory.decodeFile(f.absolutePath, decodeOpts)
                }
            } else if (imagePathOrUri.startsWith("content://") || imagePathOrUri.startsWith("file://")) {
                context.contentResolver.openInputStream(Uri.parse(imagePathOrUri))?.use { input ->
                    return BitmapFactory.decodeStream(input, null, decodeOpts)
                }
            }
        } catch (_: Throwable) {}
        return null
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isBlank()) return emptyList()
        val words = text.trim().split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var currentLine = ""
        for (word in words) {
            val candidate = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(candidate) <= maxWidth) {
                currentLine = candidate
            } else {
                if (currentLine.isNotEmpty()) lines.add(currentLine)
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) lines.add(currentLine)
        return lines
    }

    /**
     * Dibuja el logo oficial de la empresa o de SYS-TF en la cabecera del documento PDF
     * adaptándose proporcionalmente sin deformar la imagen.
     */
    private fun drawCompanyLogo(
        canvas: android.graphics.Canvas,
        context: Context,
        settings: BusinessSettings?,
        x: Float = 470f,
        y: Float = 20f,
        maxWidth: Float = 85f,
        maxHeight: Float = 60f
    ) {
        try {
            var bmp: Bitmap? = null
            if (!settings?.logoUrl.isNullOrBlank()) {
                bmp = decodeSampledBitmap(context, settings!!.logoUrl, maxWidth.toInt(), maxHeight.toInt())
            }
            if (bmp == null) {
                try {
                    val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
                    bmp = BitmapFactory.decodeResource(context.resources, com.example.R.drawable.img_app_logo, opts)
                } catch (_: Throwable) {}
            }
            if (bmp != null) {
                val bmpW = bmp.width.toFloat()
                val bmpH = bmp.height.toFloat()
                if (bmpW > 0 && bmpH > 0) {
                    val scale = minOf(maxWidth / bmpW, maxHeight / bmpH)
                    val drawW = bmpW * scale
                    val drawH = bmpH * scale
                    val drawX = x + (maxWidth - drawW) / 2f
                    val drawY = y + (maxHeight - drawH) / 2f
                    val destRect = RectF(drawX, drawY, drawX + drawW, drawY + drawH)
                    canvas.drawBitmap(bmp, null, destRect, null)
                }
            }
        } catch (_: Throwable) {}
    }

    /**
     * Guarda físicamente el PDF generado en la carpeta Descargas (Downloads) del almacenamiento del dispositivo.
     */
    fun savePdfToDownloads(context: Context, sourceFile: File, fileName: String): File {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        sourceFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    }
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        try {
                            android.widget.Toast.makeText(
                                context,
                                "Guardado en Descargas: $fileName",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        } catch (_: Throwable) {}
                    }
                    return sourceFile
                }
            }
            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            if (downloadsDir != null) {
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val destFile = File(downloadsDir, fileName)
                sourceFile.copyTo(destFile, overwrite = true)
                android.media.MediaScannerConnection.scanFile(
                    context,
                    arrayOf(destFile.absolutePath),
                    arrayOf("application/pdf"),
                    null
                )
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        android.widget.Toast.makeText(
                            context,
                            "Guardado en Descargas: ${destFile.name}",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    } catch (_: Throwable) {}
                }
                return destFile
            }
        } catch (_: Throwable) {}
        return sourceFile
    }

    fun openOrSharePdf(context: Context, file: File, title: String) {
        try {
            runCatching { savePdfToDownloads(context, file, file.name) }
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(shareIntent, "Descargar / Compartir: $title").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Throwable) {
            e.printStackTrace()
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                try {
                    android.widget.Toast.makeText(
                        context,
                        "PDF generado correctamente: ${file.name}",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                } catch (_: Throwable) {}
            }
        }
    }

    fun generateSaleReceiptPdf(
        context: Context,
        settings: BusinessSettings,
        sale: Sale,
        items: List<SaleItem>
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        drawCompanyLogo(canvas, context, settings, 485f, 25f, 60f)

        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 20f
            isFakeBoldText = true
        }
        val subPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            textSize = 10.5f
        }
        val textPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11.5f
        }
        val boldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11.5f
            isFakeBoldText = true
        }
        val headerPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 11f
            isFakeBoldText = true
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 1.5f
        }

        var y = 45f
        canvas.drawText(settings.businessName, 40f, y, titlePaint)
        y += 18f
        canvas.drawText("Comprobante de Venta Electrónico", 40f, y, subPaint)
        y += 15f
        canvas.drawText("${settings.taxId} • Tel: ${settings.phone}", 40f, y, subPaint)
        y += 15f
        canvas.drawText(settings.address, 40f, y, subPaint)
        y += 20f
        canvas.drawLine(40f, y, 555f, y, linePaint)

        y += 20f
        canvas.drawText("Nº Comprobante: ${sale.saleNumber}", 40f, y, boldPaint)
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(sale.timestamp))
        canvas.drawText("Fecha y Hora: $dateStr", 340f, y, textPaint)
        y += 18f
        canvas.drawText("Cliente: ${sale.customerName}", 40f, y, textPaint)
        canvas.drawText("Cajero: ${sale.employeeName}", 340f, y, textPaint)
        y += 18f
        canvas.drawText("Método de Pago: ${sale.paymentMethod}", 40f, y, textPaint)
        canvas.drawText("Estado: ${sale.paymentStatus}", 340f, y, boldPaint)
        y += 22f
        canvas.drawLine(40f, y, 555f, y, linePaint)

        y += 18f
        canvas.drawText("CANT", 40f, y, headerPaint)
        canvas.drawText("DESCRIPCIÓN DEL PRODUCTO", 90f, y, headerPaint)
        canvas.drawText("P. UNIT", 410f, y, headerPaint)
        canvas.drawText("SUBTOTAL", 490f, y, headerPaint)
        y += 8f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 18f

        for (item in items) {
            canvas.drawText("${item.quantity}", 45f, y, textPaint)
            val name = if (item.productName.length > 38) item.productName.take(36) + "..." else item.productName
            canvas.drawText(name, 90f, y, textPaint)
            canvas.drawText(String.format(Locale.US, "%.2f", item.unitPrice), 410f, y, textPaint)
            canvas.drawText(String.format(Locale.US, "%.2f", item.subtotal), 490f, y, boldPaint)
            y += 19f
        }

        y += 10f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 24f

        val totalPaint = Paint().apply {
            color = Color.rgb(5, 150, 105)
            textSize = 17f
            isFakeBoldText = true
        }
        canvas.drawText("TOTAL A PAGAR: ${sale.currency} ${String.format(Locale.US, "%.2f", sale.totalAmount)}", 290f, y, totalPaint)

        y += 35f
        canvas.drawText("¡Gracias por su preferencia! - Sistema ${settings.businessName}", 130f, y, subPaint)

        document.finishPage(page)
        val file = File(context.cacheDir, "Comprobante_${sale.saleNumber}.pdf")
        FileOutputStream(file).use { out ->
            document.writeTo(out)
        }
        document.close()
        return file
    }

    fun generateFinancialReportPdf(
        context: Context,
        settings: BusinessSettings,
        sales: List<Sale>,
        expenses: List<Expense>,
        currency: CurrencyType
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        drawCompanyLogo(canvas, context, settings, 485f, 25f, 60f)

        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 20f
            isFakeBoldText = true
        }
        val subPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            textSize = 10f
        }
        val sectionPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 13f
            isFakeBoldText = true
        }
        val boldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11f
            isFakeBoldText = true
        }
        val textPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 11f
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 1.2f
        }

        var y = 45f
        canvas.drawText(settings.businessName, 40f, y, titlePaint)
        y += 18f
        canvas.drawText("Informe Financiero Oficial • Balance General y Flujo de Caja", 40f, y, subPaint)
        y += 15f
        val nowStr = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        canvas.drawText("Fecha de Emisión: $nowStr • ${settings.taxId}", 40f, y, subPaint)
        y += 18f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 22f

        val activeSales = sales.filter { it.paymentStatus != "ANULADO" }
        val totalVentas = activeSales.sumOf { it.totalAmount }
        val totalGastos = expenses.sumOf { it.amount }
        val balanceNeto = totalVentas - totalGastos

        canvas.drawText("1. RESUMEN EJECUTIVO DE BALANCE", 40f, y, sectionPaint)
        y += 18f
        canvas.drawText("Ingresos Brutos por Ventas:", 50f, y, textPaint)
        canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%,.2f", totalVentas)} (${activeSales.size} transacciones)", 320f, y, boldPaint)
        y += 18f
        canvas.drawText("Egresos Totales (Compras + Gastos):", 50f, y, textPaint)
        canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%,.2f", totalGastos)} (${expenses.size} registros)", 320f, y, boldPaint)
        y += 22f

        val netPaint = Paint().apply {
            color = if (balanceNeto >= 0) Color.rgb(5, 150, 105) else Color.rgb(225, 29, 72)
            textSize = 15f
            isFakeBoldText = true
        }
        canvas.drawText("Balance Neto / Utilidad Operativa:", 50f, y, netPaint)
        canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%,.2f", balanceNeto)}", 320f, y, netPaint)
        y += 25f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 20f

        canvas.drawText("2. DESGLOSE DE GASTOS Y COMPRAS OPERATIVAS", 40f, y, sectionPaint)
        y += 18f

        val expensesByCategory = expenses.groupBy { it.category }
        if (expensesByCategory.isEmpty()) {
            canvas.drawText("No se registran gastos en este período.", 50f, y, subPaint)
            y += 18f
        } else {
            for ((category, list) in expensesByCategory) {
                val sum = list.sumOf { it.amount }
                val pct = if (totalGastos > 0) (sum / totalGastos) * 100.0 else 0.0
                canvas.drawText("• $category:", 50f, y, textPaint)
                canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%,.2f", sum)} (${String.format(Locale.US, "%.1f", pct)}%)", 320f, y, boldPaint)
                y += 16f
            }
        }

        y += 12f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 20f
        canvas.drawText("3. VENTAS POR MÉTODO DE COBRO", 40f, y, sectionPaint)
        y += 18f

        val salesByMethod = activeSales.groupBy { it.paymentMethod }
        for ((method, list) in salesByMethod) {
            val sum = list.sumOf { it.totalAmount }
            val count = list.size
            canvas.drawText("• $method:", 50f, y, textPaint)
            canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%,.2f", sum)} ($count ventas)", 320f, y, boldPaint)
            y += 16f
        }

        y += 25f
        canvas.drawText("Documento generado digitalmente por el Sistema ERP ${settings.businessName}", 110f, y, subPaint)

        document.finishPage(page)
        val file = File(context.cacheDir, "Reporte_Financiero_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()
        return file
    }

    fun generateInventoryReportPdf(
        context: Context,
        settings: BusinessSettings,
        products: List<Product>,
        currency: CurrencyType
    ): File {
        val document = PdfDocument()
        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 19f
            isFakeBoldText = true
        }
        val subPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            textSize = 10f
        }
        val boldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10.5f
            isFakeBoldText = true
        }
        val headerPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 10f
            isFakeBoldText = true
        }
        val textPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 10f
        }
        val alertPaint = Paint().apply {
            color = Color.rgb(220, 38, 38)
            textSize = 9.5f
            isFakeBoldText = true
        }
        val okPaint = Paint().apply {
            color = Color.rgb(5, 150, 105)
            textSize = 9.5f
            isFakeBoldText = true
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 1.2f
        }

        val totalCost = products.sumOf { it.costPrice * it.stockQuantity }
        val totalSale = products.sumOf { it.salePrice * it.stockQuantity }
        val totalUnits = products.sumOf { it.stockQuantity }
        val lowStockCount = products.count { it.stockQuantity <= it.minStock }

        val itemsPerPage = 16
        val chunks = products.chunked(itemsPerPage).ifEmpty { listOf(emptyList()) }
        val totalPages = chunks.size

        chunks.forEachIndexed { pageIndex, pageProducts ->
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageIndex + 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            drawCompanyLogo(canvas, context, settings, 470f, 15f, 85f, 55f)

            var y = 40f
            canvas.drawText(settings.businessName, 40f, y, titlePaint)
            y += 18f
            canvas.drawText("Reporte Oficial de Inventario, Existencias y Valoración de Mercadería", 40f, y, subPaint)
            y += 14f
            val nowStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            canvas.drawText("Emisión: $nowStr • Página ${pageIndex + 1} de $totalPages", 40f, y, subPaint)
            y += 16f
            canvas.drawLine(40f, y, 555f, y, linePaint)
            y += 18f

            if (pageIndex == 0) {
                canvas.drawText("RESUMEN DE VALORACIÓN GENERAL DE INVENTARIO", 40f, y, boldPaint)
                y += 16f
                canvas.drawText("• Costo Total Invertido: ${currency.symbol} ${String.format(Locale.US, "%,.2f", totalCost)}", 40f, y, textPaint)
                canvas.drawText("• Valor Venta Potencial: ${currency.symbol} ${String.format(Locale.US, "%,.2f", totalSale)}", 300f, y, textPaint)
                y += 15f
                val margin = if (totalSale > 0) ((totalSale - totalCost) / totalSale) * 100.0 else 0.0
                canvas.drawText("• Margen Proyectado: ${currency.symbol} ${String.format(Locale.US, "%,.2f", totalSale - totalCost)} (${String.format(Locale.US, "%.1f", margin)}%)", 40f, y, textPaint)
                canvas.drawText("• Total Unidades en Stock: $totalUnits unidades", 300f, y, textPaint)
                y += 15f
                canvas.drawText("• Artículos en Catálogo: ${products.size} productos", 40f, y, textPaint)
                if (lowStockCount > 0) {
                    canvas.drawText("• Alerta Stock Bajo: $lowStockCount producto(s)", 300f, y, alertPaint)
                } else {
                    canvas.drawText("• Estado de Stock: Todos óptimos", 300f, y, okPaint)
                }
                y += 18f
                canvas.drawLine(40f, y, 555f, y, linePaint)
                y += 18f
            }

            canvas.drawText("CÓDIGO", 40f, y, headerPaint)
            canvas.drawText("DESCRIPCIÓN", 120f, y, headerPaint)
            canvas.drawText("CATEGORÍA", 270f, y, headerPaint)
            canvas.drawText("P. COSTO", 370f, y, headerPaint)
            canvas.drawText("P. VENTA", 435f, y, headerPaint)
            canvas.drawText("STOCK", 500f, y, headerPaint)
            y += 6f
            canvas.drawLine(40f, y, 555f, y, linePaint)
            y += 15f

            for (p in pageProducts) {
                canvas.drawText(p.sku.take(12), 40f, y, textPaint)
                canvas.drawText(p.name.take(28), 120f, y, boldPaint)
                canvas.drawText(p.category.take(16), 270f, y, textPaint)
                canvas.drawText(String.format(Locale.US, "%.2f", p.costPrice), 370f, y, textPaint)
                canvas.drawText(String.format(Locale.US, "%.2f", p.salePrice), 435f, y, textPaint)
                val stockStr = "${p.stockQuantity}"
                if (p.stockQuantity <= p.minStock) {
                    canvas.drawText("$stockStr (!)", 500f, y, alertPaint)
                } else {
                    canvas.drawText(stockStr, 500f, y, textPaint)
                }
                if (p.description.isNotBlank()) {
                    val descLines = wrapText(p.description, subPaint, 240f)
                    for (dl in descLines) {
                        y += 11f
                        canvas.drawText(dl, 120f, y, subPaint)
                    }
                }
                y += 17f
            }

            y = 810f
            canvas.drawLine(40f, y, 555f, y, linePaint)
            y += 14f
            canvas.drawText("Sistema ERP ${settings.businessName} • Reporte Oficial de Inventario • Página ${pageIndex + 1}/$totalPages", 100f, y, subPaint)
            document.finishPage(page)
        }

        val file = File(context.cacheDir, "Reporte_Inventario_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()
        return file
    }

    fun generateSalesReportPdf(
        context: Context,
        settings: BusinessSettings,
        sales: List<Sale>,
        currency: CurrencyType
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        drawCompanyLogo(canvas, context, settings, 485f, 25f, 60f)

        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 20f
            isFakeBoldText = true
        }
        val subPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            textSize = 10f
        }
        val boldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11f
            isFakeBoldText = true
        }
        val textPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 10.5f
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 1.2f
        }

        var y = 45f
        canvas.drawText(settings.businessName, 40f, y, titlePaint)
        y += 18f
        canvas.drawText("Reporte Comercial de Ventas y Facturación", 40f, y, subPaint)
        y += 15f
        val nowStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        canvas.drawText("Fecha de Generación: $nowStr • ${settings.taxId}", 40f, y, subPaint)
        y += 18f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 20f

        val activeSales = sales.filter { it.paymentStatus != "ANULADO" }
        val totalAmount = activeSales.sumOf { it.totalAmount }
        val qrCount = activeSales.count { it.paymentMethod == "QR_BANCARIO" }
        val cashCount = activeSales.count { it.paymentMethod == "EFECTIVO" }
        val creditCount = activeSales.count { it.paymentMethod == "CREDITO" }

        canvas.drawText("RESUMEN DE FACTURACIÓN Y VENTAS", 40f, y, boldPaint)
        y += 18f
        canvas.drawText("• Total Facturado: ${currency.symbol} ${String.format(Locale.US, "%,.2f", totalAmount)}", 40f, y, textPaint)
        canvas.drawText("• Ventas Realizadas: ${activeSales.size} transacciones", 300f, y, textPaint)
        y += 16f
        canvas.drawText("• Cobros por QR Bancario: $qrCount ventas", 40f, y, textPaint)
        canvas.drawText("• Cobros en Efectivo: $cashCount ventas", 300f, y, textPaint)
        y += 16f
        canvas.drawText("• Ventas a Crédito: $creditCount ventas", 40f, y, textPaint)
        canvas.drawText("• Ventas Anuladas: ${sales.size - activeSales.size}", 300f, y, textPaint)
        y += 20f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 20f

        canvas.drawText("DETALLE DE COMPROBANTES DE VENTA", 40f, y, boldPaint)
        y += 18f
        canvas.drawText("Nº VENTA", 40f, y, boldPaint)
        canvas.drawText("FECHA", 110f, y, boldPaint)
        canvas.drawText("CLIENTE", 200f, y, boldPaint)
        canvas.drawText("MÉTODO", 360f, y, boldPaint)
        canvas.drawText("TOTAL", 480f, y, boldPaint)
        y += 6f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 18f

        for (s in activeSales.take(22)) {
            canvas.drawText(s.saleNumber, 40f, y, textPaint)
            val dStr = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(s.timestamp))
            canvas.drawText(dStr, 110f, y, textPaint)
            val cName = if (s.customerName.length > 20) s.customerName.take(18) + ".." else s.customerName
            canvas.drawText(cName, 200f, y, textPaint)
            canvas.drawText(s.paymentMethod, 360f, y, textPaint)
            canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%.2f", s.totalAmount)}", 480f, y, boldPaint)
            y += 18f
        }

        y = 810f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 14f
        canvas.drawText("Reporte Comercial emitido por Sistema ERP ${settings.businessName}", 120f, y, subPaint)

        document.finishPage(page)
        val file = File(context.cacheDir, "Reporte_Ventas_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()
        return file
    }

    fun generateTransferReportPdf(
        context: Context,
        settings: BusinessSettings,
        transfer: StockTransfer,
        items: List<StockTransferItem>
    ): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        drawCompanyLogo(canvas, context, settings, 485f, 25f, 60f)

        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 20f
            isFakeBoldText = true
        }
        val subPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            textSize = 10f
        }
        val boldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 11f
            isFakeBoldText = true
        }
        val textPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 10.5f
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 1.2f
        }

        var y = 45f
        canvas.drawText(settings.businessName, 40f, y, titlePaint)
        y += 18f
        canvas.drawText("Acta Oficial de Transferencia de Mercadería entre Almacenes", 40f, y, subPaint)
        y += 15f
        canvas.drawText("Transferencia Nº: ${transfer.transferNumber} • Fecha: ${transfer.dateStr}", 40f, y, subPaint)
        y += 18f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 20f

        canvas.drawText("Origen: ${transfer.sourceWarehouseName}", 40f, y, boldPaint)
        canvas.drawText("Destino: ${transfer.targetWarehouseName}", 300f, y, boldPaint)
        y += 18f
        canvas.drawText("Responsable: ${transfer.performedByEmployeeName}", 40f, y, textPaint)
        canvas.drawText("Estado: ${transfer.status}", 300f, y, boldPaint)
        y += 18f
        canvas.drawText("Total Unidades: ${transfer.totalUnits} un. (${transfer.itemsCount} productos)", 40f, y, textPaint)
        if (transfer.notes.isNotBlank()) {
            y += 18f
            canvas.drawText("Notas: ${transfer.notes}", 40f, y, textPaint)
        }
        y += 20f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 20f

        canvas.drawText("DETALLE DE ARTÍCULOS TRANSFERIDOS", 40f, y, boldPaint)
        y += 18f
        canvas.drawText("PRODUCTO", 40f, y, boldPaint)
        canvas.drawText("CANTIDAD", 470f, y, boldPaint)
        y += 6f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 18f

        for (item in items) {
            canvas.drawText(item.productName, 40f, y, textPaint)
            canvas.drawText("${item.quantity} unidades", 470f, y, boldPaint)
            y += 18f
        }

        y = 810f
        canvas.drawLine(40f, y, 555f, y, linePaint)
        y += 14f
        canvas.drawText("Acta generada por el Sistema ERP ${settings.businessName}", 130f, y, subPaint)

        document.finishPage(page)
        val file = File(context.cacheDir, "Acta_Transferencia_${transfer.transferNumber}.pdf")
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()
        openOrSharePdf(context, file, "Acta ${transfer.transferNumber}")
        return file
    }

    fun generateInventoryReportPdfWithImages(
        context: Context,
        settings: BusinessSettings,
        products: List<Product>,
        currency: CurrencyType
    ): File {
        val document = PdfDocument()
        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 18f
            isFakeBoldText = true
        }
        val subPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            textSize = 9f
        }
        val headerPaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            textSize = 10f
            isFakeBoldText = true
        }
        val boldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10f
            isFakeBoldText = true
        }
        val textPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 9.5f
        }
        val alertPaint = Paint().apply {
            color = Color.rgb(220, 38, 38)
            textSize = 9.5f
            isFakeBoldText = true
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 1f
        }
        val imgBorderPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }

        val defaultPlaceholderBmp: Bitmap? = try {
            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.RGB_565
                inSampleSize = 2
            }
            BitmapFactory.decodeResource(context.resources, com.example.R.drawable.img_app_logo, opts)
        } catch (_: Throwable) { null }

        var currentPageNumber = 1
        var currentPage: PdfDocument.Page? = null
        var canvas: android.graphics.Canvas? = null
        var y = 0f

        fun startNewPage() {
            currentPage?.let {
                canvas?.drawLine(40f, 815f, 555f, 815f, linePaint)
                canvas?.drawText("Sistema ERP ${settings.businessName} • Catálogo Oficial con Imágenes • Pág. $currentPageNumber", 100f, 827f, subPaint)
                document.finishPage(it)
            }
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, currentPageNumber).create()
            val newPage = document.startPage(pageInfo)
            currentPage = newPage
            val c = newPage.canvas
            canvas = c

            drawCompanyLogo(c, context, settings, 470f, 15f, 85f, 55f)
            var curY = 32f
            c.drawText(settings.businessName, 40f, curY, titlePaint)
            curY += 15f
            c.drawText("Catálogo e Inventario Oficial Ilustrado con Fotografías de Producto", 40f, curY, subPaint)
            curY += 13f
            val nowStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            c.drawText("Emisión: $nowStr • ${settings.taxId} • Pág. $currentPageNumber", 40f, curY, subPaint)
            curY += 14f
            c.drawLine(40f, curY, 555f, curY, linePaint)
            curY += 15f

            c.drawText("FOTO", 40f, curY, headerPaint)
            c.drawText("CÓDIGO", 90f, curY, headerPaint)
            c.drawText("PRODUCTO / DESCRIPCIÓN COMPLETA", 160f, curY, headerPaint)
            c.drawText("CATEGORÍA", 355f, curY, headerPaint)
            c.drawText("PRECIO", 445f, curY, headerPaint)
            c.drawText("STOCK", 512f, curY, headerPaint)
            curY += 5f
            c.drawLine(40f, curY, 555f, curY, linePaint)
            curY += 12f
            y = curY
            currentPageNumber++
        }

        startNewPage()

        for (p in products) {
            val nameLines = wrapText(p.name, boldPaint, 185f).ifEmpty { listOf(p.name) }
            val descLines = if (p.description.isNotBlank()) wrapText(p.description, subPaint, 185f) else emptyList()
            val textBlockHeight = (nameLines.size * 11.5f) + (descLines.size * 10f) + 6f
            val rowHeight = maxOf(46f, textBlockHeight)

            if (y + rowHeight > 805f) {
                startNewPage()
            }

            val c = canvas ?: continue
            val rowTop = y - 4f
            val imgSize = 38f
            val imgRect = RectF(40f, rowTop, 40f + imgSize, rowTop + imgSize)

            var prodBmp: Bitmap? = null
            if (p.imageUrl.isNotBlank()) {
                prodBmp = decodeSampledBitmap(context, p.imageUrl, 80, 80)
            }
            if (prodBmp == null) {
                prodBmp = defaultPlaceholderBmp
            }
            if (prodBmp != null) {
                val pW = prodBmp.width.toFloat()
                val pH = prodBmp.height.toFloat()
                if (pW > 0 && pH > 0) {
                    val s = minOf(imgSize / pW, imgSize / pH)
                    val dW = pW * s
                    val dH = pH * s
                    val dX = 40f + (imgSize - dW) / 2f
                    val dY = rowTop + (imgSize - dH) / 2f
                    c.drawBitmap(prodBmp, null, RectF(dX, dY, dX + dW, dY + dH), null)
                }
            }
            c.drawRect(imgRect, imgBorderPaint)

            c.drawText(p.sku.take(11), 90f, y + 10f, textPaint)
            var lineY = y + 8f
            for (nl in nameLines) {
                c.drawText(nl, 160f, lineY, boldPaint)
                lineY += 11.5f
            }
            for (dl in descLines) {
                c.drawText(dl, 160f, lineY, subPaint)
                lineY += 10f
            }
            c.drawText(p.category.take(14), 355f, y + 10f, textPaint)
            c.drawText("${currency.symbol} ${String.format(Locale.US, "%.2f", p.salePrice)}", 445f, y + 10f, boldPaint)
            val stockText = "${p.stockQuantity} un."
            c.drawText(stockText, 512f, y + 10f, if (p.stockQuantity <= p.minStock) alertPaint else textPaint)

            y += rowHeight + 4f
            c.drawLine(40f, y - 2f, 555f, y - 2f, linePaint)
        }

        currentPage?.let {
            canvas?.drawLine(40f, 815f, 555f, 815f, linePaint)
            canvas?.drawText("Sistema ERP ${settings.businessName} • Catálogo Oficial con Imágenes", 100f, 827f, subPaint)
            document.finishPage(it)
        }

        val file = File(context.cacheDir, "Catalogo_Inventario_Imagenes_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()
        runCatching { savePdfToDownloads(context, file, file.name) }
        return file
    }

    fun generateProductProfitsReportPdf(
        context: Context,
        settings: BusinessSettings,
        profitStats: List<ProductProfitStat>,
        periodLabel: String,
        currency: CurrencyType
    ): File {
        val document = PdfDocument()
        val titlePaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 17f
            isFakeBoldText = true
        }
        val subPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            textSize = 9.5f
        }
        val boldPaint = Paint().apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10f
            isFakeBoldText = true
        }
        val textPaint = Paint().apply {
            color = Color.rgb(51, 65, 85)
            textSize = 9f
        }
        val headerPaint = Paint().apply {
            color = Color.rgb(71, 85, 105)
            textSize = 8.5f
            isFakeBoldText = true
        }
        val profitPaint = Paint().apply {
            color = Color.rgb(16, 149, 93) // Emerald
            textSize = 9f
            isFakeBoldText = true
        }
        val lossPaint = Paint().apply {
            color = Color.rgb(225, 29, 72) // Rose
            textSize = 9f
            isFakeBoldText = true
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 1f
        }
        val cardBgPaint = Paint().apply {
            color = Color.rgb(248, 250, 252)
        }
        val cardBorderPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }

        val totalUnits = profitStats.sumOf { it.quantitySold }
        val totalRevenue = profitStats.sumOf { it.totalRevenue }
        val totalCost = profitStats.sumOf { it.totalCost }
        val totalProfit = profitStats.sumOf { it.totalProfit }
        val globalMargin = if (totalRevenue > 0) (totalProfit / totalRevenue) * 100.0 else 0.0

        val itemsPerPageFirst = 14
        val itemsPerPageSubsequent = 24
        val pagesList = mutableListOf<List<ProductProfitStat>>()
        if (profitStats.isEmpty()) {
            pagesList.add(emptyList())
        } else {
            var cursor = 0
            val firstChunk = profitStats.take(itemsPerPageFirst)
            pagesList.add(firstChunk)
            cursor += firstChunk.size
            while (cursor < profitStats.size) {
                val nextChunk = profitStats.drop(cursor).take(itemsPerPageSubsequent)
                pagesList.add(nextChunk)
                cursor += nextChunk.size
            }
        }
        val totalPages = pagesList.size
        val nowStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

        pagesList.forEachIndexed { pageIndex, pageItems ->
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, pageIndex + 1).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            drawCompanyLogo(canvas, context, settings, 470f, 15f, 85f, 55f)
            var y = 40f
            canvas.drawText(settings.businessName, 35f, y, titlePaint)
            y += 16f
            canvas.drawText("REPORTE OFICIAL DE PRODUCTOS VENDIDOS Y GANANCIAS", 35f, y, boldPaint)
            y += 13f
            canvas.drawText("Período: $periodLabel • Emisión: $nowStr • Pág. ${pageIndex + 1}/$totalPages", 35f, y, subPaint)
            y += 14f
            canvas.drawLine(35f, y, 560f, y, linePaint)
            y += 14f

            if (pageIndex == 0) {
                val boxRect = RectF(35f, y, 560f, y + 80f)
                canvas.drawRoundRect(boxRect, 8f, 8f, cardBgPaint)
                canvas.drawRoundRect(boxRect, 8f, 8f, cardBorderPaint)
                var ky = y + 15f
                canvas.drawText("RESUMEN DE RENTABILIDAD DEL PERÍODO", 48f, ky, boldPaint)
                ky += 16f
                canvas.drawText("• Artículos Distintos Vendidos: ${profitStats.size} productos", 48f, ky, textPaint)
                canvas.drawText("• Unidades Totales Vendidas: $totalUnits unidades", 300f, ky, textPaint)
                ky += 15f
                canvas.drawText("• Total Facturado (Ventas): ${currency.symbol} ${String.format(Locale.US, "%,.2f", totalRevenue)}", 48f, ky, textPaint)
                canvas.drawText("• Costo de Mercadería Vendida: ${currency.symbol} ${String.format(Locale.US, "%,.2f", totalCost)}", 300f, ky, textPaint)
                ky += 16f
                canvas.drawText("• GANANCIA NETA TOTAL: ${currency.symbol} ${String.format(Locale.US, "%,.2f", totalProfit)}", 48f, ky, profitPaint)
                canvas.drawText("• Margen Comercial Global: ${String.format(Locale.US, "%.1f%%", globalMargin)}", 300f, ky, boldPaint)
                y += 94f
            }

            canvas.drawText("#", 35f, y, headerPaint)
            canvas.drawText("PRODUCTO / CÓDIGO", 58f, y, headerPaint)
            canvas.drawText("CANT.", 248f, y, headerPaint)
            canvas.drawText("P. PROM.", 290f, y, headerPaint)
            canvas.drawText("INGRESOS", 352f, y, headerPaint)
            canvas.drawText("COSTO", 412f, y, headerPaint)
            canvas.drawText("GANANCIA", 468f, y, headerPaint)
            canvas.drawText("%MARG", 528f, y, headerPaint)
            y += 5f
            canvas.drawLine(35f, y, 560f, y, linePaint)
            y += 14f

            if (pageItems.isEmpty()) {
                canvas.drawText("No se registraron ventas en el período seleccionado.", 140f, y + 25f, subPaint)
            } else {
                val startIdx = if (pageIndex == 0) 1 else (itemsPerPageFirst + (pageIndex - 1) * itemsPerPageSubsequent + 1)
                pageItems.forEachIndexed { idx, p ->
                    val rowNumber = startIdx + idx
                    canvas.drawText("$rowNumber", 35f, y, textPaint)
                    canvas.drawText(p.productName.take(26), 58f, y, boldPaint)
                    canvas.drawText("${p.quantitySold}", 248f, y, textPaint)
                    canvas.drawText(String.format(Locale.US, "%.2f", p.averageUnitPrice), 290f, y, textPaint)
                    canvas.drawText(String.format(Locale.US, "%.2f", p.totalRevenue), 352f, y, textPaint)
                    canvas.drawText(String.format(Locale.US, "%.2f", p.totalCost), 412f, y, textPaint)
                    val profitStr = String.format(Locale.US, "%.2f", p.totalProfit)
                    canvas.drawText(profitStr, 468f, y, if (p.totalProfit >= 0) profitPaint else lossPaint)
                    val marginStr = "${String.format(Locale.US, "%.1f", p.profitMarginPercent)}%"
                    canvas.drawText(marginStr, 528f, y, textPaint)

                    val subMeta = listOfNotNull(
                        if (p.sku.isNotBlank()) "SKU: ${p.sku}" else null,
                        if (p.category.isNotBlank()) p.category else null
                    ).joinToString(" • ")
                    if (subMeta.isNotBlank()) {
                        y += 10f
                        canvas.drawText(subMeta.take(34), 58f, y, subPaint)
                    }
                    y += 14f
                    canvas.drawLine(35f, y - 2f, 560f, y - 2f, linePaint)
                }
            }

            if (pageIndex == totalPages - 1 && profitStats.isNotEmpty()) {
                y += 6f
                canvas.drawRect(35f, y, 560f, y + 22f, cardBgPaint)
                canvas.drawRect(35f, y, 560f, y + 22f, cardBorderPaint)
                val totY = y + 15f
                canvas.drawText("TOTALES:", 45f, totY, boldPaint)
                canvas.drawText("$totalUnits", 248f, totY, boldPaint)
                canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%.2f", totalRevenue)}", 352f, totY, boldPaint)
                canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%.2f", totalCost)}", 412f, totY, boldPaint)
                canvas.drawText("${currency.symbol} ${String.format(Locale.US, "%.2f", totalProfit)}", 468f, totY, profitPaint)
                canvas.drawText("${String.format(Locale.US, "%.1f%%", globalMargin)}", 528f, totY, boldPaint)

                val sigY = 770f
                canvas.drawLine(70f, sigY, 230f, sigY, linePaint)
                canvas.drawText("Firma Responsable / Gerencia", 85f, sigY + 12f, subPaint)
                canvas.drawLine(360f, sigY, 520f, sigY, linePaint)
                canvas.drawText("Firma Auditoría / Contabilidad", 375f, sigY + 12f, subPaint)
            }

            canvas.drawLine(35f, 810f, 560f, 810f, linePaint)
            canvas.drawText(
                "Sistema ERP ${settings.businessName} • Reporte de Productos y Ganancias • Período: $periodLabel • Pág. ${pageIndex + 1} de $totalPages",
                45f,
                822f,
                subPaint
            )
            document.finishPage(page)
        }

        val file = File(context.cacheDir, "Reporte_Ganancias_Productos_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use { out -> document.writeTo(out) }
        document.close()
        runCatching { savePdfToDownloads(context, file, file.name) }
        return file
    }
}
