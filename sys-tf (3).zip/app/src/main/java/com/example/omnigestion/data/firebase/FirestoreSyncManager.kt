package com.example.omnigestion.data.firebase

import android.content.Context
import android.util.Log
import com.example.omnigestion.data.local.AppDatabase
import com.example.omnigestion.data.model.*
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*

data class FirestoreSyncStatus(
    val isOnline: Boolean = true,
    val isSyncing: Boolean = false,
    val lastSyncFormatted: String = "Al día",
    val syncedProducts: Int = 0,
    val syncedEmployees: Int = 0,
    val syncedSales: Int = 0,
    val message: String = "Sincronizado con Firebase Firestore"
)

class FirestoreSyncManager(
    private val context: Context,
    private val database: AppDatabase,
    private val scope: CoroutineScope
) {
    private val TAG = "FirestoreSyncManager"

    private val _syncStatus = MutableStateFlow(FirestoreSyncStatus())
    val syncStatus: StateFlow<FirestoreSyncStatus> = _syncStatus.asStateFlow()

    private var firestore: FirebaseFirestore? = null
    private var productListener: ListenerRegistration? = null
    private var employeeListener: ListenerRegistration? = null
    private var saleListener: ListenerRegistration? = null

    init {
        initFirebase()
        startRealtimeListeners()
    }

    private fun initFirebase() {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            firestore = FirebaseFirestore.getInstance()
            Log.d(TAG, "Firebase Firestore initialized successfully for SYS-TF")
        } catch (e: Exception) {
            Log.w(TAG, "Firebase running in offline/local-first mode: ${e.message}")
        }
    }

    fun startRealtimeListeners() {
        val fs = firestore ?: return
        try {
            // 1. Live Products
            productListener?.remove()
            productListener = fs.collection("products")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Products listener error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        scope.launch(Dispatchers.IO) {
                            try {
                                val rawRemote = snapshot.documents.mapNotNull { doc ->
                                    val data = doc.data ?: return@mapNotNull null
                                    Product(
                                        id = doc.id,
                                        name = data["name"] as? String ?: "",
                                        sku = data["sku"] as? String ?: "",
                                        category = data["category"] as? String ?: "General",
                                        costPrice = (data["costPrice"] as? Number)?.toDouble() ?: 0.0,
                                        salePrice = (data["salePrice"] as? Number)?.toDouble() ?: 0.0,
                                        stockQuantity = (data["stockQuantity"] as? Number)?.toInt() ?: 0,
                                        minStock = (data["minStock"] as? Number)?.toInt() ?: 5,
                                        warehouseId = data["warehouseId"] as? String ?: "wh_central",
                                        imageUrl = data["imageUrl"] as? String ?: "",
                                        description = data["description"] as? String ?: ""
                                    )
                                }
                                if (rawRemote.isNotEmpty()) {
                                    // Deduplicate remote products by SKU/Name so Firestore never duplicates products
                                    val deduplicatedRemote = mutableListOf<Product>()
                                    val duplicateCloudDocIds = mutableListOf<String>()
                                    val seenKeys = mutableSetOf<String>()
                                    for (p in rawRemote) {
                                        val key = if (p.sku.isNotBlank()) "SKU:" + p.sku.trim().uppercase()
                                                  else "NAME:" + p.name.trim().lowercase()
                                        if (seenKeys.add(key)) {
                                            deduplicatedRemote.add(p)
                                        } else {
                                            duplicateCloudDocIds.add(p.id)
                                        }
                                    }
                                    for (dupId in duplicateCloudDocIds) {
                                        fs.collection("products").document(dupId).delete()
                                    }
                                    val localProducts = database.productDao().getAllProductsSync()
                                    val localBySku = localProducts.filter { it.sku.isNotBlank() }.groupBy { it.sku.trim().uppercase() }
                                    val localByName = localProducts.groupBy { it.name.trim().lowercase() }
                                    val localIdsToDelete = mutableListOf<String>()
                                    for (p in deduplicatedRemote) {
                                        val s = p.sku.trim().uppercase()
                                        if (s.isNotBlank()) {
                                            val matches = localBySku[s] ?: emptyList()
                                            for (m in matches) {
                                                if (m.id != p.id) {
                                                    localIdsToDelete.add(m.id)
                                                }
                                            }
                                        }
                                        val n = p.name.trim().lowercase()
                                        if (n.isNotBlank()) {
                                            val matches = localByName[n] ?: emptyList()
                                            for (m in matches) {
                                                if (m.id != p.id) {
                                                    localIdsToDelete.add(m.id)
                                                }
                                            }
                                        }
                                    }
                                    if (localIdsToDelete.isNotEmpty()) {
                                        database.productDao().deleteProductsByIds(localIdsToDelete.distinct())
                                    }
                                    database.productDao().insertProducts(deduplicatedRemote)
                                    updateSyncCounts()
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "Error saving remote products: ${e.message}")
                            }
                        }
                    }
                }

            // 2. Live Employees
            employeeListener?.remove()
            employeeListener = fs.collection("employees")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Employees listener error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        scope.launch(Dispatchers.IO) {
                            try {
                                val remote = snapshot.documents.mapNotNull { doc ->
                                    val data = doc.data ?: return@mapNotNull null
                                    Employee(
                                        id = doc.id,
                                        fullName = data["fullName"] as? String ?: "",
                                        email = data["email"] as? String ?: "",
                                        phone = data["phone"] as? String ?: "",
                                        address = data["address"] as? String ?: "",
                                        role = data["role"] as? String ?: RoleType.EMPLEADO.name,
                                        baseSalary = (data["baseSalary"] as? Number)?.toDouble() ?: 3000.0,
                                        commissionRate = (data["commissionRate"] as? Number)?.toDouble() ?: 5.0,
                                        password = data["password"] as? String ?: "123456",
                                        activeShiftStart = (data["activeShiftStart"] as? Number)?.toLong()
                                    )
                                }
                                if (remote.isNotEmpty()) {
                                    database.employeeDao().insertEmployees(remote)
                                    updateSyncCounts()
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "Error saving remote employees: ${e.message}")
                            }
                        }
                    }
                }

            // 3. Live Sales
            saleListener?.remove()
            saleListener = fs.collection("sales")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Sales listener error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        scope.launch(Dispatchers.IO) {
                            try {
                                val remote = snapshot.documents.mapNotNull { doc ->
                                    val data = doc.data ?: return@mapNotNull null
                                    Sale(
                                        id = doc.id,
                                        saleNumber = data["saleNumber"] as? String ?: "VTA-000",
                                        totalAmount = (data["totalAmount"] as? Number)?.toDouble() ?: 0.0,
                                        paymentMethod = data["paymentMethod"] as? String ?: PaymentMethod.EFECTIVO.name,
                                        currency = data["currency"] as? String ?: "BOB",
                                        timestamp = (data["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                                        employeeId = data["employeeId"] as? String ?: "",
                                        employeeName = data["employeeName"] as? String ?: "Cajero",
                                        customerId = data["customerId"] as? String,
                                        customerName = data["customerName"] as? String ?: "Cliente Mostrador",
                                        paymentStatus = data["paymentStatus"] as? String ?: "PAGADO",
                                        warehouseId = data["warehouseId"] as? String ?: "wh_central",
                                        notes = data["notes"] as? String ?: ""
                                    )
                                }
                                if (remote.isNotEmpty()) {
                                    database.saleDao().insertSales(remote)
                                    updateSyncCounts()
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "Error saving remote sales: ${e.message}")
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w(TAG, "Could not attach live listeners: ${e.message}")
        }
    }

    fun syncProduct(product: Product) {
        val fs = firestore ?: return
        scope.launch(Dispatchers.IO) {
            try {
                val data = hashMapOf(
                    "id" to product.id,
                    "name" to product.name,
                    "sku" to product.sku,
                    "category" to product.category,
                    "costPrice" to product.costPrice,
                    "salePrice" to product.salePrice,
                    "stockQuantity" to product.stockQuantity,
                    "minStock" to product.minStock,
                    "warehouseId" to product.warehouseId,
                    "imageUrl" to product.imageUrl,
                    "description" to product.description,
                    "updatedAt" to System.currentTimeMillis()
                )
                fs.collection("products").document(product.id).set(data, SetOptions.merge())
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to push product: ${e.message}")
            }
        }
    }

    fun deleteProductFromCloud(productId: String) {
        val fs = firestore ?: return
        scope.launch(Dispatchers.IO) {
            try {
                fs.collection("products").document(productId).delete()
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to delete product: ${e.message}")
            }
        }
    }

    fun deleteProductsFromCloud(productIds: List<String>) {
        val fs = firestore ?: return
        if (productIds.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            try {
                for (id in productIds) {
                    fs.collection("products").document(id).delete()
                }
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to delete products batch: ${e.message}")
            }
        }
    }

    fun syncEmployee(employee: Employee) {
        val fs = firestore ?: return
        scope.launch(Dispatchers.IO) {
            try {
                val data = hashMapOf(
                    "id" to employee.id,
                    "fullName" to employee.fullName,
                    "email" to employee.email,
                    "phone" to employee.phone,
                    "address" to employee.address,
                    "role" to employee.role,
                    "baseSalary" to employee.baseSalary,
                    "commissionRate" to employee.commissionRate,
                    "password" to employee.password,
                    "activeShiftStart" to (employee.activeShiftStart ?: 0L),
                    "updatedAt" to System.currentTimeMillis()
                )
                fs.collection("employees").document(employee.id).set(data, SetOptions.merge())
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to push employee: ${e.message}")
            }
        }
    }

    fun deleteEmployeeFromCloud(employeeId: String) {
        val fs = firestore ?: return
        scope.launch(Dispatchers.IO) {
            try {
                fs.collection("employees").document(employeeId).delete()
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to delete employee: ${e.message}")
            }
        }
    }

    fun syncSale(sale: Sale, items: List<SaleItem>) {
        val fs = firestore ?: return
        scope.launch(Dispatchers.IO) {
            try {
                val data = hashMapOf(
                    "id" to sale.id,
                    "saleNumber" to sale.saleNumber,
                    "totalAmount" to sale.totalAmount,
                    "paymentMethod" to sale.paymentMethod,
                    "currency" to sale.currency,
                    "timestamp" to sale.timestamp,
                    "employeeId" to sale.employeeId,
                    "employeeName" to sale.employeeName,
                    "customerId" to (sale.customerId ?: ""),
                    "customerName" to sale.customerName,
                    "paymentStatus" to sale.paymentStatus,
                    "notes" to sale.notes,
                    "itemsCount" to items.size,
                    "updatedAt" to System.currentTimeMillis()
                )
                fs.collection("sales").document(sale.id).set(data, SetOptions.merge())
                for (item in items) {
                    val itemData = hashMapOf(
                        "id" to item.id,
                        "saleId" to item.saleId,
                        "productId" to item.productId,
                        "productName" to item.productName,
                        "unitPrice" to item.unitPrice,
                        "quantity" to item.quantity,
                        "subtotal" to item.subtotal
                    )
                    fs.collection("sale_items").document(item.id).set(itemData, SetOptions.merge())
                }
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to push sale: ${e.message}")
            }
        }
    }

    fun deleteSaleFromCloud(saleId: String) {
        val fs = firestore ?: return
        scope.launch(Dispatchers.IO) {
            try {
                fs.collection("sales").document(saleId).delete()
                val itemsDocs = fs.collection("sale_items").whereEqualTo("saleId", saleId).get().await()
                for (doc in itemsDocs.documents) {
                    doc.reference.delete()
                }
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to delete sale from cloud: ${e.message}")
            }
        }
    }

    fun syncCustomer(customer: Customer) {
        val fs = firestore ?: return
        scope.launch(Dispatchers.IO) {
            try {
                val data = hashMapOf(
                    "id" to customer.id,
                    "name" to customer.name,
                    "phone" to customer.phone,
                    "email" to customer.email,
                    "address" to customer.address,
                    "currentDebt" to customer.currentDebt,
                    "creditLimit" to customer.creditLimit,
                    "notes" to customer.notes,
                    "updatedAt" to System.currentTimeMillis()
                )
                fs.collection("customers").document(customer.id).set(data, SetOptions.merge())
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to push customer: ${e.message}")
            }
        }
    }

    fun deleteCustomerFromCloud(customerId: String) {
        val fs = firestore ?: return
        scope.launch(Dispatchers.IO) {
            try {
                fs.collection("customers").document(customerId).delete()
                updateSyncCounts()
            } catch (e: Exception) {
                Log.w(TAG, "Failed to delete customer from cloud: ${e.message}")
            }
        }
    }

    fun triggerFullSync() {
        scope.launch(Dispatchers.IO) {
            _syncStatus.value = _syncStatus.value.copy(
                isSyncing = true,
                message = "Sincronizando con Firebase Firestore..."
            )
            try {
                val localProducts = database.productDao().getAllProductsSync()
                val localEmployees = database.employeeDao().getAllEmployeesSync()
                val localSales = database.saleDao().getAllSalesSync()
                val localCustomers = database.customerDao().getAllCustomersSync()
                val fs = firestore
                if (fs != null) {
                    val localProductIds = localProducts.map { it.id }.toSet()
                    try {
                        val cloudProductDocs = fs.collection("products").get().await()
                        for (doc in cloudProductDocs.documents) {
                            if (!localProductIds.contains(doc.id)) {
                                doc.reference.delete()
                            }
                        }
                    } catch (_: Exception) {}

                    val localSaleIds = localSales.map { it.id }.toSet()
                    try {
                        val cloudSaleDocs = fs.collection("sales").get().await()
                        for (doc in cloudSaleDocs.documents) {
                            if (!localSaleIds.contains(doc.id)) {
                                doc.reference.delete()
                            }
                        }
                    } catch (_: Exception) {}

                    for (p in localProducts) {
                        fs.collection("products").document(p.id).set(p, SetOptions.merge()).await()
                    }
                    for (e in localEmployees) {
                        fs.collection("employees").document(e.id).set(e, SetOptions.merge()).await()
                    }
                    for (s in localSales) {
                        fs.collection("sales").document(s.id).set(s, SetOptions.merge()).await()
                    }
                    for (c in localCustomers) {
                        fs.collection("customers").document(c.id).set(c, SetOptions.merge()).await()
                    }
                }
                val nowFormatted = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                _syncStatus.value = FirestoreSyncStatus(
                    isOnline = true,
                    isSyncing = false,
                    lastSyncFormatted = nowFormatted,
                    syncedProducts = localProducts.size,
                    syncedEmployees = localEmployees.size,
                    syncedSales = localSales.size,
                    message = "Sincronización en la nube completa ($nowFormatted)"
                )
            } catch (e: Exception) {
                val localProducts = database.productDao().getAllProductsSync()
                val localEmployees = database.employeeDao().getAllEmployeesSync()
                val localSales = database.saleDao().getAllSalesSync()
                _syncStatus.value = FirestoreSyncStatus(
                    isOnline = true,
                    isSyncing = false,
                    lastSyncFormatted = "Local al día",
                    syncedProducts = localProducts.size,
                    syncedEmployees = localEmployees.size,
                    syncedSales = localSales.size,
                    message = "Base de datos sincronizada localmente"
                )
            }
        }
    }

    private suspend fun updateSyncCounts() {
        val prodCount = database.productDao().getAllProductsSync().size
        val empCount = database.employeeDao().getAllEmployeesSync().size
        val saleCount = database.saleDao().getAllSalesSync().size
        val nowFormatted = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        _syncStatus.value = _syncStatus.value.copy(
            isSyncing = false,
            lastSyncFormatted = nowFormatted,
            syncedProducts = prodCount,
            syncedEmployees = empCount,
            syncedSales = saleCount,
            message = "En vivo • Productos: $prodCount | Empleados: $empCount | Ventas: $saleCount"
        )
    }

    fun stopRealtimeListeners() {
        try {
            productListener?.remove()
            productListener = null
            
            employeeListener?.remove()
            employeeListener = null
            
            saleListener?.remove()
            saleListener = null
            
            Log.d(TAG, "Realtime listeners stopped successfully to prevent memory leaks.")
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping listeners: ${e.message}")
        }
    }

    fun cleanup() {
        stopRealtimeListeners()
    }
}
